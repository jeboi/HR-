/* Consolidated new-hire-onboarding module scripts */

/* Source: submodules/contract-management.js */
/**
 * Contract Management Submodule
 * Professional Legal Document Workflow
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrContracts';

    // Helper: Initialize or fetch data
    const getContracts = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Mock Data for Medical Contracts
        return [
            { id: "CON-2026-001", name: "Dr. Aris Thorne", type: "Full-Time Physician", status: "Executed", date: "2026-03-01" },
            { id: "CON-2026-002", name: "Sarah Jenkins", type: "Nursing Head", status: "Sent for Signature", date: "2026-03-05" },
            { id: "CON-2026-003", name: "James Miller", type: "Radiology Tech", status: "Drafting", date: "2026-03-06" }
        ];
    };

    function ensureContractModalHost() {
        if (document.getElementById('contractManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="contractManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="contractManagementModalTitle">Contract Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="contractManagementModalBody"></div>',
            '      <div class="modal-footer" id="contractManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showContractInfo(title, message) {
        const modalEl = document.getElementById('contractManagementModal');
        const titleEl = document.getElementById('contractManagementModalTitle');
        const bodyEl = document.getElementById('contractManagementModalBody');
        const footerEl = document.getElementById('contractManagementModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderContractManagement = function (container) {
        ensureContractModalHost();

        const contracts = getContracts();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-file-signature text-primary me-2"></i>Contract Lifecycle</h6>
                        <small class="text-muted">Manage employment agreements and legal terms</small>
                    </div>
                    <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.createNewContract()">
                        <i class="fas fa-plus me-1"></i> New Contract
                    </button>
                </div>

                <div class="row g-3">
                    ${contracts.map(con => `
                        <div class="col-xl-4 col-md-6">
                            <div class="contract-card p-3 border rounded-3 bg-white h-100 position-relative">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted extra-small fw-bold">${con.id}</span>
                                    <span class="badge-status ${con.status.replace(/\s+/g, '-').toLowerCase()}">${con.status}</span>
                                </div>
                                
                                <h6 class="fw-bold text-dark text-truncate mb-1" title="${con.name}">${con.name}</h6>
                                <p class="text-primary small mb-3">${con.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="text-muted" style="font-size: 11px;">Updated: ${con.date}</span>
                                    <div class="action-btns">
                                        ${con.status === 'Drafting' ? 
                                            `<button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateContractStatus('${con.id}', 'Sent for Signature')">Send</button>` : 
                                            `<button class="btn btn-xs btn-light text-primary" onclick="window.HRSubmodules.viewContract('${con.id}')"><i class="fas fa-eye"></i></button>`
                                        }
                                        ${con.status === 'Sent for Signature' ? 
                                            `<button class="btn btn-xs btn-success" onclick="window.HRSubmodules.updateContractStatus('${con.id}', 'Executed')">Mark Signed</button>` : ''
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateContractStatus = function(id, newStatus) {
        let contracts = getContracts();
        const idx = contracts.findIndex(c => c.id === id);
        if (idx !== -1) {
            const candidateName = contracts[idx].name;
            contracts[idx].status = newStatus;
            contracts[idx].date = new Date().toLocaleDateString();
            localStorage.setItem(STORAGE_KEY, JSON.stringify(contracts));
            this.renderContractManagement(document.getElementById('roleModuleOverviewBody'));
            showContractInfo('Contract Updated', candidateName + ' contract is now marked as ' + newStatus + '.');
        }
    };

    window.HRSubmodules.createNewContract = function() {
        const modalEl = document.getElementById('contractManagementModal');
        const titleEl = document.getElementById('contractManagementModalTitle');
        const bodyEl = document.getElementById('contractManagementModalBody');
        const footerEl = document.getElementById('contractManagementModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Create New Contract';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Candidate Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="contractCandidateName" placeholder="e.g. John Doe">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Agreement Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="contractAgreementType" value="Standard Employment Agreement">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="contractCreateConfirm">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('contractCreateConfirm');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('contractCandidateName').value || '').trim();
                const type = (document.getElementById('contractAgreementType').value || '').trim() || 'Standard Employment Agreement';
                if (!name) {
                    return;
                }

                let contracts = getContracts();
                contracts.unshift({
                    id: 'CON-2026-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    type: type,
                    status: 'Drafting',
                    date: new Date().toLocaleDateString()
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(contracts));
                window.HRSubmodules.renderContractManagement(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showContractInfo('Contract Created', 'New contract draft has been created for ' + name + '.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewContract = function(id) {
        const contracts = getContracts();
        const target = contracts.find(function (contract) {
            return contract.id === id;
        });

        if (!target) {
            return;
        }

        showContractInfo('Contract Preview', target.name + ' - ' + target.type + ' (' + target.status + ').');
    };

})();

/* Source: submodules/document-submission.js */
/**
 * Document Submission Submodule
 * Handles Digital Onboarding Files & Integration
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrDocumentSubmissions';
    const CONTRACT_KEY = 'hospitalHrContracts'; // Integration Key

    // Helper: Initialize or fetch data
    const getDocs = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        return [
            { id: "DOC-001", name: "Dr. Aris Thorne", type: "PRC License", status: "Verified", date: "2026-03-01" },
            { id: "DOC-002", name: "Sarah Jenkins", type: "PHTLS Certification", status: "Pending", date: "-" },
            { id: "DOC-003", name: "Sarah Jenkins", type: "Drug Test Result", status: "Uploaded", date: "2026-03-04" }
        ];
    };

    function ensureDocumentModalHost() {
        if (document.getElementById('documentSubmissionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="documentSubmissionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="documentSubmissionModalTitle">Document Submission</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="documentSubmissionModalBody"></div>',
            '      <div class="modal-footer" id="documentSubmissionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showDocumentInfo(title, message) {
        const modalEl = document.getElementById('documentSubmissionModal');
        const titleEl = document.getElementById('documentSubmissionModalTitle');
        const bodyEl = document.getElementById('documentSubmissionModalBody');
        const footerEl = document.getElementById('documentSubmissionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderDocumentSubmission = function (container) {
        ensureDocumentModalHost();

        const docs = getDocs();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-info">
                        <h6 class="fw-bold mb-0 text-dark">Document Repository</h6>
                        <small class="text-muted">Digital verification of professional credentials</small>
                    </div>
                    <button class="btn btn-sm btn-primary px-3 shadow-sm" onclick="window.HRSubmodules.triggerFileUpload()">
                        <i class="fas fa-upload me-2"></i>Upload New
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-doc-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 30%">Candidate / Staff</th>
                                <th style="width: 25%">Document Type</th>
                                <th style="width: 20%">Status</th>
                                <th class="text-end pe-4" style="width: 25%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${docs.map(doc => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate">${doc.name}</div>
                                        <div class="text-muted extra-small">ID: ${doc.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-secondary fw-medium">${doc.type}</div>
                                    </td>
                                    <td>
                                        <span class="status-indicator ${doc.status.toLowerCase()}">
                                            ${doc.status}
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            ${doc.status === 'Pending' ? 
                                                `<button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateDocStatus('${doc.id}', 'Uploaded')">Upload</button>` : 
                                                (doc.status === 'Uploaded' ? 
                                                    `<button class="btn btn-xs btn-success" onclick="window.HRSubmodules.updateDocStatus('${doc.id}', 'Verified')">Verify</button>` :
                                                    `<span class="text-muted small">${doc.date}</span>`
                                                )
                                            }
                                            <button class="btn btn-link btn-sm p-0 text-decoration-none" title="View File" onclick="window.HRSubmodules.viewDocument('${doc.id}')">
                                                <i class="fas fa-eye text-muted ms-2"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateDocStatus = function(id, newStatus) {
        let docs = getDocs();
        const idx = docs.findIndex(d => d.id === id);
        
        if (idx !== -1) {
            docs[idx].status = newStatus;
            docs[idx].date = new Date().toISOString().split('T')[0];
            localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));

            // INTEGRATION LOGIC:
            // If the document is marked 'Verified', we trigger the Contract phase
            if (newStatus === 'Verified') {
                this.triggerContractWorkflow(docs[idx]);
            }

            // Sync with Dashboard
            window.dispatchEvent(new Event('storage'));
            this.renderDocumentSubmission(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.triggerContractWorkflow = function(docEntry) {
        let contracts = JSON.parse(localStorage.getItem(CONTRACT_KEY)) || [];
        
        // Prevent duplicate contracts for the same person
        const exists = contracts.find(c => c.name === docEntry.name);
        
        if (!exists) {
            contracts.unshift({
                id: "CON-" + Math.floor(1000 + Math.random() * 9000),
                name: docEntry.name,
                type: "Employment Agreement",
                status: "Drafting",
                date: new Date().toLocaleDateString()
            });
            localStorage.setItem(CONTRACT_KEY, JSON.stringify(contracts));
            console.log("Integration: Contract Drafted for " + docEntry.name);
        }
    };

    window.HRSubmodules.triggerFileUpload = function() {
        const modalEl = document.getElementById('documentSubmissionModal');
        const titleEl = document.getElementById('documentSubmissionModalTitle');
        const bodyEl = document.getElementById('documentSubmissionModalBody');
        const footerEl = document.getElementById('documentSubmissionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Upload New Document';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="docUploadName" placeholder="e.g. Sarah Jenkins">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Document Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="docUploadType" placeholder="e.g. PRC License">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="docUploadConfirm">Add Document</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const confirmBtn = document.getElementById('docUploadConfirm');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                const name = (document.getElementById('docUploadName').value || '').trim();
                const type = (document.getElementById('docUploadType').value || '').trim();
                if (!name || !type) {
                    return;
                }

                let docs = getDocs();
                docs.unshift({
                    id: 'DOC-' + Math.floor(1000 + Math.random() * 9000),
                    name: name,
                    type: type,
                    status: 'Pending',
                    date: '-'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderDocumentSubmission(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showDocumentInfo('Document Logged', type + ' for ' + name + ' has been added to the repository.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewDocument = function(id) {
        const docs = getDocs();
        const target = docs.find(function (item) {
            return item.id === id;
        });

        if (!target) {
            return;
        }

        showDocumentInfo('Document Preview', target.type + ' for ' + target.name + ' is currently marked as ' + target.status + '.');
    };

})();

/* Source: submodules/orientation-scheduling.js */
/**
 * Orientation Scheduling Submodule
 * Professional Induction & Training Coordinator
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrOrientations';

    const getSessions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Professional Orientation Schedule
        return [
            { id: "ORI-101", title: "General Hospital Induction", date: "2026-03-10", time: "09:00 AM", venue: "Main Conference Hall", facilitator: "Director Maria Santos", status: "Scheduled" },
            { id: "ORI-102", title: "Nurse Protocol Training", date: "2026-03-12", time: "01:30 PM", venue: "Training Room B", facilitator: "Head Nurse Sarah J.", status: "Confirmed" }
        ];
    };

    function ensureOrientationModalHost() {
        if (document.getElementById('orientationSchedulingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="orientationSchedulingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="orientationSchedulingModalTitle">Orientation Scheduling</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="orientationSchedulingModalBody"></div>',
            '      <div class="modal-footer" id="orientationSchedulingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showOrientationInfo(title, message) {
        const modalEl = document.getElementById('orientationSchedulingModal');
        const titleEl = document.getElementById('orientationSchedulingModalTitle');
        const bodyEl = document.getElementById('orientationSchedulingModalBody');
        const footerEl = document.getElementById('orientationSchedulingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderOrientationScheduling = function (container) {
        ensureOrientationModalHost();

        const sessions = getSessions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-calendar-alt text-primary me-2"></i>Induction Schedule</h6>
                        <small class="text-muted">Coordinate orientation dates for newly onboarded staff</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.addNewOrientation()">
                        <i class="fas fa-plus me-1"></i> Schedule Session
                    </button>
                </div>

                <div class="row g-3">
                    ${sessions.map(session => `
                        <div class="col-12">
                            <div class="orientation-card p-3 border rounded-3 bg-white shadow-sm">
                                <div class="row align-items-center">
                                    <div class="col-md-2 border-end text-center">
                                        <div class="fw-bold text-primary mb-0">${session.date.split('-')[2]} ${new Date(session.date).toLocaleString('default', { month: 'short' })}</div>
                                        <div class="small text-muted">${session.time}</div>
                                    </div>
                                    
                                    <div class="col-md-7 ps-md-4">
                                        <h6 class="fw-bold mb-1 text-dark">${session.title}</h6>
                                        <div class="d-flex gap-3 flex-wrap">
                                            <span class="small text-muted"><i class="fas fa-map-marker-alt me-1 text-danger"></i> ${session.venue}</span>
                                            <span class="small text-muted"><i class="fas fa-user-tie me-1 text-info"></i> ${session.facilitator}</span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3 text-end">
                                        <span class="badge-status ${session.status.toLowerCase()} mb-2 d-inline-block">${session.status}</span>
                                        <div class="d-flex justify-content-end gap-2">
                                            <button class="btn btn-xs btn-outline-secondary" onclick="window.HRSubmodules.sendOrientationInvite('${session.id}')"><i class="fas fa-envelope"></i> Invite</button>
                                            <button class="btn btn-xs btn-outline-danger" onclick="window.HRSubmodules.deleteOrientation('${session.id}')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewOrientation = function() {
        const modalEl = document.getElementById('orientationSchedulingModal');
        const titleEl = document.getElementById('orientationSchedulingModalTitle');
        const bodyEl = document.getElementById('orientationSchedulingModalBody');
        const footerEl = document.getElementById('orientationSchedulingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Schedule Orientation Session';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Session Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="oriSessionTitle" placeholder="e.g. Safety Orientation">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Date</label>',
            '  <input type="date" class="form-control form-control-sm" id="oriSessionDate">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Venue</label>',
            '  <input type="text" class="form-control form-control-sm" id="oriSessionVenue" value="To Be Announced">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="oriSessionCreateBtn">Create Session</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('oriSessionCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const sessionTitle = (document.getElementById('oriSessionTitle').value || '').trim();
                const sessionDate = (document.getElementById('oriSessionDate').value || '').trim();
                const sessionVenue = (document.getElementById('oriSessionVenue').value || '').trim() || 'To Be Announced';

                if (!sessionTitle || !sessionDate) {
                    return;
                }

                let sessions = getSessions();
                sessions.push({
                    id: 'ORI-' + Math.floor(Math.random() * 900),
                    title: sessionTitle,
                    date: sessionDate,
                    time: '09:00 AM',
                    venue: sessionVenue,
                    facilitator: 'HR Coordinator',
                    status: 'Scheduled'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
                window.HRSubmodules.renderOrientationScheduling(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showOrientationInfo('Session Scheduled', 'Orientation session "' + sessionTitle + '" was added successfully.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.deleteOrientation = function(id) {
        const sessions = getSessions();
        const target = sessions.find(function (session) {
            return session.id === id;
        });

        if (!target) {
            return;
        }

        const modalEl = document.getElementById('orientationSchedulingModal');
        const titleEl = document.getElementById('orientationSchedulingModalTitle');
        const bodyEl = document.getElementById('orientationSchedulingModalBody');
        const footerEl = document.getElementById('orientationSchedulingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Cancel Session';
        bodyEl.innerHTML = '<p class="mb-0">Cancel orientation session <strong>' + target.title + '</strong> scheduled on ' + target.date + '?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">No</button>',
            '<button type="button" class="btn btn-danger" id="oriDeleteConfirmBtn">Yes, Cancel</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('oriDeleteConfirmBtn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                const updated = getSessions().filter(function (session) {
                    return session.id !== id;
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
                window.HRSubmodules.renderOrientationScheduling(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.sendOrientationInvite = function(id) {
        const sessions = getSessions();
        const target = sessions.find(function (session) {
            return session.id === id;
        });

        if (!target) {
            return;
        }

        showOrientationInfo('Invite Sent', 'Invitation has been queued for "' + target.title + '" at ' + target.time + '.');
    };

})();

/* Source: submodules/pre-employment-requirements.js */
/**
 * Pre-Employment Requirements Submodule
 * Professional Onboarding & Compliance Checklist
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const CANDIDATE_KEY = 'hrCandidates';

    // Internal Helper: Get only those marked as 'Hired' or 'Approved'
    const getOnboardingQueue = () => {
        const stored = localStorage.getItem(CANDIDATE_KEY);
        const all = stored ? JSON.parse(stored) : [];
        return all.filter(c => c.stage === 'Hired' || c.stage === 'Approved');
    };

    function ensurePreEmploymentModal() {
        if (document.getElementById('preEmploymentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="preEmploymentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="preEmploymentModalTitle">Onboarding Status</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="preEmploymentModalBody"></div>',
            '      <div class="modal-footer">',
            '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPreEmploymentModal(title, message) {
        const modalEl = document.getElementById('preEmploymentModal');
        const titleEl = document.getElementById('preEmploymentModalTitle');
        const bodyEl = document.getElementById('preEmploymentModalBody');

        if (!modalEl || !titleEl || !bodyEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderPreEmployment = function (container) {
        ensurePreEmploymentModal();

        const hired = getOnboardingQueue();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-primary me-2"></i>Compliance Checklist</h6>
                        <p class="text-muted small mb-0">Verify mandatory documents for incoming medical personnel</p>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-light text-primary border px-3">${hired.length} Total In-Progress</span>
                    </div>
                </div>

                <div class="row g-3">
                    ${hired.length > 0 ? hired.map(person => {
                        const progress = calculateProgress(person.requirements);
                        return `
                        <div class="col-xl-6">
                            <div class="compliance-card p-3 border rounded-3 bg-white h-100">
                                <div class="d-flex justify-content-between align-items-start mb-3 border-bottom pb-2">
                                    <div class="user-meta overflow-hidden">
                                        <h6 class="fw-bold mb-0 text-truncate" title="${person.name}">${person.name}</h6>
                                        <small class="text-primary fw-medium">${person.role || 'General Staff'}</small>
                                    </div>
                                    <div class="progress-pill ${progress === 100 ? 'complete' : ''}">
                                        ${progress}% Ready
                                    </div>
                                </div>

                                <div class="checklist-grid mt-2">
                                    ${renderCheckItems(person)}
                                </div>

                                <div class="mt-3 pt-2 border-top d-flex justify-content-end">
                                    <button class="btn btn-sm ${progress === 100 ? 'btn-success' : 'btn-light border'} px-4" 
                                            onclick="window.HRSubmodules.finalizeOnboarding('${person.id}')"
                                            ${progress === 100 ? '' : 'disabled'}>
                                        ${progress === 100 ? '<i class="fas fa-user-plus me-1"></i> Ready to Deploy' : 'Awaiting Docs'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    `}).join('') : `
                        <div class="col-12 text-center py-5 bg-white border rounded-3">
                            <h6 class="text-muted">No candidates currently in the onboarding queue.</h6>
                        </div>
                    `}
                </div>
            </div>
        `;
    };

    function renderCheckItems(person) {
        const reqs = person.requirements || { medical: false, nbi: false, contract: false, diploma: false };
        const items = [
            { key: 'medical', label: 'Medical Clearance' },
            { key: 'nbi', label: 'NBI / Police Clearance' },
            { key: 'contract', label: 'Signed Contract' },
            { key: 'diploma', label: 'Academic Credentials' }
        ];

        return items.map(item => `
            <div class="form-check mb-1">
                <input class="form-check-input" type="checkbox" 
                       id="${item.key}-${person.id}" 
                       ${reqs[item.key] ? 'checked' : ''} 
                       onchange="window.HRSubmodules.updateReqStatus('${person.id}', '${item.key}')">
                <label class="form-check-label small text-dark ms-1" for="${item.key}-${person.id}">
                    ${item.label}
                </label>
            </div>
        `).join('');
    }

    function calculateProgress(reqs) {
        if (!reqs) return 0;
        const total = Object.keys(reqs).length;
        const done = Object.values(reqs).filter(v => v === true).length;
        return Math.round((done / total) * 100);
    }

    window.HRSubmodules.updateReqStatus = function(id, key) {
        let candidates = JSON.parse(localStorage.getItem(CANDIDATE_KEY)) || [];
        const idx = candidates.findIndex(c => c.id === id);
        
        if (idx !== -1) {
            if (!candidates[idx].requirements) {
                candidates[idx].requirements = { medical: false, nbi: false, contract: false, diploma: false };
            }
            candidates[idx].requirements[key] = !candidates[idx].requirements[key];
            
            localStorage.setItem(CANDIDATE_KEY, JSON.stringify(candidates));
            // Trigger local re-render
            this.renderPreEmployment(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.finalizeOnboarding = function(id) {
        const candidates = JSON.parse(localStorage.getItem(CANDIDATE_KEY)) || [];
        const target = candidates.find(function (candidate) {
            return candidate.id === id;
        });

        const personName = target ? target.name : 'Selected candidate';
        showPreEmploymentModal('Deployment Ready', personName + ' is now cleared for hospital duties. Deployment protocols have been initiated.');
        // Future logic for Dashboard integration goes here
    };

})();

