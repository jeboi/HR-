/* Consolidated learning-management module scripts */

/* Source: submodules/assigned-courses.js */
/**
 * Assigned Courses Submodule
 * Professional Enrollment & Progress Tracking
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrAssignedCourses';

    const getAssignments = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Enrollment Data
        return [
            { id: "ENR-001", name: "Dr. Aris Thorne", course: "Advanced Life Support", progress: 75, deadline: "2026-04-01", status: "In Progress" },
            { id: "ENR-002", name: "Sarah Jenkins", course: "Patient Privacy & HIPAA", progress: 100, deadline: "2026-03-15", status: "Completed" },
            { id: "ENR-003", name: "James Miller", course: "Radiology Safety", progress: 10, deadline: "2026-03-20", status: "Overdue" }
        ];
    };

    function ensureAssignedCoursesModalHost() {
        if (document.getElementById('assignedCoursesModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="assignedCoursesModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="assignedCoursesModalTitle">Training Assignments</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="assignedCoursesModalBody"></div>',
            '      <div class="modal-footer" id="assignedCoursesModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showAssignedCoursesInfo(title, message) {
        const modalEl = document.getElementById('assignedCoursesModal');
        const titleEl = document.getElementById('assignedCoursesModalTitle');
        const bodyEl = document.getElementById('assignedCoursesModalBody');
        const footerEl = document.getElementById('assignedCoursesModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderAssignedCourses = function (container) {
        ensureAssignedCoursesModalHost();

        const data = getAssignments();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-warning me-2"></i>Training Assignments</h6>
                        <small class="text-muted">Monitor employee enrollment and completion rates</small>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-dark btn-sm" onclick="window.HRSubmodules.exportEnrollment()">
                            <i class="fas fa-download me-1"></i> Export
                        </button>
                        <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.assignNewCourse()">
                            <i class="fas fa-user-plus me-1"></i> Assign Course
                        </button>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-assign-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Employee</th>
                                <th style="width: 25%">Course Title</th>
                                <th style="width: 30%">Progress</th>
                                <th class="text-end pe-4" style="width: 20%">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-dark small fw-medium">${item.course}</div>
                                        <div class="extra-small text-muted">Due: ${item.deadline}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress flex-grow-1" style="height: 6px; border-radius: 10px;">
                                                <div class="progress-bar ${getProgressColor(item.status)}" 
                                                     role="progressbar" style="width: ${item.progress}%"></div>
                                            </div>
                                            <span class="extra-small fw-bold text-muted" style="min-width: 35px;">${item.progress}%</span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="status-badge ${item.status.toLowerCase().replace(/\s+/g, '-')}">
                                            ${item.status}
                                        </span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    function getProgressColor(status) {
        if (status === 'Completed') return 'bg-success';
        if (status === 'Overdue') return 'bg-danger';
        return 'bg-warning';
    }

    window.HRSubmodules.exportEnrollment = function () {
        const data = getAssignments();
        showAssignedCoursesInfo('Export Enrollment', 'Prepared ' + data.length + ' assignment records for export.');
    };

    window.HRSubmodules.assignNewCourse = function() {
        const modalEl = document.getElementById('assignedCoursesModal');
        const titleEl = document.getElementById('assignedCoursesModalTitle');
        const bodyEl = document.getElementById('assignedCoursesModalBody');
        const footerEl = document.getElementById('assignedCoursesModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Assign New Course';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="assignCourseStaff" placeholder="e.g. Sarah Jenkins">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="assignCourseName" placeholder="e.g. HIPAA Basics">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Deadline</label>',
            '  <input type="date" class="form-control form-control-sm" id="assignCourseDeadline" value="' + new Date(Date.now() + 12096e5).toISOString().split('T')[0] + '">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="assignCourseCreateBtn">Assign</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('assignCourseCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('assignCourseStaff').value || '').trim();
                const course = (document.getElementById('assignCourseName').value || '').trim();
                const deadline = (document.getElementById('assignCourseDeadline').value || '').trim();
                if (!name || !course || !deadline) {
                    return;
                }

                let data = getAssignments();
                data.unshift({
                    id: 'ENR-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    course: course,
                    progress: 0,
                    deadline: deadline,
                    status: 'In Progress'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderAssignedCourses(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showAssignedCoursesInfo('Course Assigned', course + ' has been assigned to ' + name + '.');
            });
        }

        modal.show();
    };
})();

/* Source: submodules/certifications.js */
/**
 * Certifications Submodule
 * Professional License & Board Credential Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrLicenseVault';

    const getCertifications = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Medical License Data
        return [
            { id: "LIC-7701", name: "Dr. Aris Thorne", type: "Medical Board License", issued: "2024-05-20", expiry: "2027-05-20", status: "Active" },
            { id: "LIC-8820", name: "Sarah Jenkins", type: "Registered Nurse (RN)", issued: "2023-11-10", expiry: "2026-11-10", status: "Active" },
            { id: "LIC-4412", name: "James Miller", type: "Radiology Tech Cert", issued: "2021-01-05", expiry: "2024-01-05", status: "Expired" }
        ];
    };

    function ensureCertificationsModalHost() {
        if (document.getElementById('certificationsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="certificationsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="certificationsModalTitle">Credential Vault</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="certificationsModalBody"></div>',
            '      <div class="modal-footer" id="certificationsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCertificationsInfo(title, message) {
        const modalEl = document.getElementById('certificationsModal');
        const titleEl = document.getElementById('certificationsModalTitle');
        const bodyEl = document.getElementById('certificationsModalBody');
        const footerEl = document.getElementById('certificationsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderCertifications = function (container) {
        ensureCertificationsModalHost();

        const certs = getCertifications();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-id-card text-primary me-2"></i>Credential Vault</h6>
                        <small class="text-muted">Monitoring professional licenses and board certifications</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.registerNewLicense()">
                        <i class="fas fa-plus me-1"></i> Register License
                    </button>
                </div>

                <div class="row g-3">
                    ${certs.map(cert => `
                        <div class="col-xl-4 col-md-6">
                            <div class="cert-card bg-white border rounded-4 shadow-sm p-4 h-100 position-relative overflow-hidden">
                                <div class="cert-status-stripe ${cert.status.toLowerCase()}"></div>
                                <div class="d-flex justify-content-between mb-3">
                                    <span class="extra-small text-muted fw-bold">REF: ${cert.id}</span>
                                    <span class="badge ${cert.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} rounded-pill" style="font-size: 9px;">${cert.status}</span>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">${cert.name}</h6>
                                <p class="text-primary small fw-semibold mb-4">${cert.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded-3">
                                    <div class="text-center flex-grow-1">
                                        <div class="extra-small text-muted">ISSUED</div>
                                        <div class="small fw-bold text-dark">${cert.issued}</div>
                                    </div>
                                    <div class="border-start mx-2" style="height: 20px;"></div>
                                    <div class="text-center flex-grow-1">
                                        <div class="extra-small text-muted">EXPIRY</div>
                                        <div class="small fw-bold ${cert.status === 'Expired' ? 'text-danger' : 'text-dark'}">${cert.expiry}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.registerNewLicense = function() {
        const modalEl = document.getElementById('certificationsModal');
        const titleEl = document.getElementById('certificationsModalTitle');
        const bodyEl = document.getElementById('certificationsModalBody');
        const footerEl = document.getElementById('certificationsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Register License';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Professional Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="certNameInput" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">License Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="certTypeInput" placeholder="e.g. Medical Board License">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Expiry Date</label>',
            '  <input type="date" class="form-control form-control-sm" id="certExpiryInput">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="certRegisterBtn">Register</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const registerBtn = document.getElementById('certRegisterBtn');
        if (registerBtn) {
            registerBtn.addEventListener('click', function () {
                const name = (document.getElementById('certNameInput').value || '').trim();
                const type = (document.getElementById('certTypeInput').value || '').trim();
                const expiry = (document.getElementById('certExpiryInput').value || '').trim();
                if (!name || !type || !expiry) {
                    return;
                }

                let certs = getCertifications();
                certs.unshift({
                    id: 'LIC-' + Math.floor(1000 + Math.random() * 9000),
                    name: name,
                    type: type,
                    issued: new Date().toISOString().split('T')[0],
                    expiry: expiry,
                    status: new Date(expiry) > new Date() ? 'Active' : 'Expired'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(certs));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCertifications(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCertificationsInfo('License Registered', type + ' has been registered for ' + name + '.');
            });
        }

        modal.show();
    };
})();

/* Source: submodules/course-catalog.js */
/**
 * Course Catalog Submodule
 * Professional L&D Training Hub
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCourses';

    const getCourses = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Hospital Courses
        return [
            { id: "CRS-101", title: "Advanced Life Support (ALS)", category: "Clinical", duration: "16 Hours", status: "Active", icon: "fa-heart-pulse", color: "#dc3545" },
            { id: "CRS-102", title: "Patient Privacy & HIPAA", category: "Compliance", duration: "4 Hours", status: "Mandatory", icon: "fa-shield-halved", color: "#0d6efd" },
            { id: "CRS-103", title: "Nurse Leadership 101", category: "Management", duration: "20 Hours", status: "Active", icon: "fa-users-gear", color: "#198754" }
        ];
    };

    function ensureCourseCatalogModalHost() {
        if (document.getElementById('courseCatalogModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="courseCatalogModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="courseCatalogModalTitle">Course Catalog</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="courseCatalogModalBody"></div>',
            '      <div class="modal-footer" id="courseCatalogModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCourseCatalogInfo(title, message) {
        const modalEl = document.getElementById('courseCatalogModal');
        const titleEl = document.getElementById('courseCatalogModalTitle');
        const bodyEl = document.getElementById('courseCatalogModalBody');
        const footerEl = document.getElementById('courseCatalogModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderCourseCatalog = function (container) {
        ensureCourseCatalogModalHost();

        const courses = getCourses();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-book-open text-primary me-2"></i>Course Catalog</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Continuing Professional Development</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.addNewCourse()">
                        <i class="fas fa-plus-circle me-1"></i> Add New Course
                    </button>
                </div>

                <div class="row g-4">
                    ${courses.map(course => `
                        <div class="col-xl-4 col-md-6">
                            <div class="course-card border rounded-4 bg-white shadow-sm overflow-hidden h-100 d-flex flex-column">
                                <div class="course-header p-4 text-center" style="background-color: ${course.color}08;">
                                    <div class="course-icon-circle mb-3" style="background-color: ${course.color}15; color: ${course.color};">
                                        <i class="fas ${course.icon} fa-xl"></i>
                                    </div>
                                    <span class="badge rounded-pill mb-2 ${course.status === 'Mandatory' ? 'bg-danger' : 'bg-primary-subtle text-primary'}" style="font-size: 9px;">
                                        ${course.status}
                                    </span>
                                    <h6 class="fw-bold text-dark mb-0 px-2">${course.title}</h6>
                                </div>
                                <div class="course-body p-3 flex-grow-1 border-top">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted small"><i class="far fa-folder me-1"></i> ${course.category}</span>
                                        <span class="text-muted small"><i class="far fa-clock me-1"></i> ${course.duration}</span>
                                    </div>
                                    <div class="extra-small text-muted mb-3">Course ID: ${course.id}</div>
                                    <button class="btn btn-outline-primary btn-sm w-100 rounded-3" onclick="window.HRSubmodules.manageCourseEnrollment('${course.id}')">Manage Enrollment</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewCourse = function() {
        const modalEl = document.getElementById('courseCatalogModal');
        const titleEl = document.getElementById('courseCatalogModalTitle');
        const bodyEl = document.getElementById('courseCatalogModalBody');
        const footerEl = document.getElementById('courseCatalogModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add New Course';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="courseNewTitle" placeholder="e.g. ICU Safety Protocols">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Category</label>',
            '  <input type="text" class="form-control form-control-sm" id="courseNewCategory" placeholder="Clinical/Admin/Compliance">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Duration</label>',
            '  <input type="text" class="form-control form-control-sm" id="courseNewDuration" value="TBD">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="courseCreateBtn">Create Course</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('courseCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const title = (document.getElementById('courseNewTitle').value || '').trim();
                const category = (document.getElementById('courseNewCategory').value || '').trim();
                const duration = (document.getElementById('courseNewDuration').value || '').trim() || 'TBD';
                if (!title || !category) {
                    return;
                }

                let courses = getCourses();
                courses.unshift({
                    id: 'CRS-' + Math.floor(100 + Math.random() * 900),
                    title: title,
                    category: category,
                    duration: duration,
                    status: 'Active',
                    icon: 'fa-graduation-cap',
                    color: '#6f42c1'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(courses));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCourseCatalog(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCourseCatalogInfo('Course Added', title + ' has been added to the learning catalog.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.manageCourseEnrollment = function(courseId) {
        const courses = getCourses();
        const target = courses.find(function (course) {
            return course.id === courseId;
        });
        if (!target) {
            return;
        }

        showCourseCatalogInfo('Enrollment Management', 'Enrollment controls for "' + target.title + '" are now accessible from Assigned Courses.');
    };
})();

/* Source: submodules/course-completion-tracking.js */
/**
 * Course Completion Tracking Submodule
 * Official Records and Certification Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompletions';

    const getCompletions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Completion Records
        return [
            { id: "CERT-901", name: "Dr. Aris Thorne", course: "Advanced Life Support", date: "2026-02-10", grade: "98%", status: "Certified" },
            { id: "CERT-902", name: "Sarah Jenkins", course: "Patient Privacy & HIPAA", date: "2026-01-22", grade: "100%", status: "Certified" },
            { id: "CERT-903", name: "James Miller", course: "Radiology Safety", date: "2025-12-15", grade: "85%", status: "Expired" }
        ];
    };

    function ensureCompletionTrackingModalHost() {
        if (document.getElementById('completionTrackingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="completionTrackingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="completionTrackingModalTitle">Completion Registry</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="completionTrackingModalBody"></div>',
            '      <div class="modal-footer" id="completionTrackingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCompletionTrackingInfo(title, message) {
        const modalEl = document.getElementById('completionTrackingModal');
        const titleEl = document.getElementById('completionTrackingModalTitle');
        const bodyEl = document.getElementById('completionTrackingModalBody');
        const footerEl = document.getElementById('completionTrackingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderCourseCompletionTracking = function (container) {
        ensureCompletionTrackingModalHost();

        const data = getCompletions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-certificate text-success me-2"></i>Completion Registry</h6>
                        <small class="text-muted">Official log of hospital certifications and professional development</small>
                    </div>
                    <button class="btn btn-outline-success btn-sm rounded-pill px-3" onclick="window.HRSubmodules.recordNewCompletion()">
                        <i class="fas fa-file-signature me-1"></i> Record Completion
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-tracking-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Staff Member</th>
                                <th style="width: 30%">Course Title</th>
                                <th style="width: 15%">Grade</th>
                                <th style="width: 15%">Completion</th>
                                <th class="text-end pe-4" style="width: 15%">Credential</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-dark small">${item.course}</div>
                                    </td>
                                    <td>
                                        <span class="fw-bold ${parseInt(item.grade) >= 90 ? 'text-success' : 'text-primary'}">${item.grade}</span>
                                    </td>
                                    <td>
                                        <div class="small text-muted">${item.date}</div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="cert-status ${item.status.toLowerCase()}">${item.status}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.recordNewCompletion = function() {
        const modalEl = document.getElementById('completionTrackingModal');
        const titleEl = document.getElementById('completionTrackingModalTitle');
        const bodyEl = document.getElementById('completionTrackingModalBody');
        const footerEl = document.getElementById('completionTrackingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Record Completion';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="completionStaffName" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Completed</label>',
            '  <input type="text" class="form-control form-control-sm" id="completionCourseName" placeholder="e.g. ALS">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Final Grade</label>',
            '  <input type="text" class="form-control form-control-sm" id="completionCourseGrade" placeholder="e.g. 95%">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="completionRecordBtn">Record</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const recordBtn = document.getElementById('completionRecordBtn');
        if (recordBtn) {
            recordBtn.addEventListener('click', function () {
                const name = (document.getElementById('completionStaffName').value || '').trim();
                const course = (document.getElementById('completionCourseName').value || '').trim();
                const grade = (document.getElementById('completionCourseGrade').value || '').trim() || 'N/A';
                if (!name || !course) {
                    return;
                }

                let data = getCompletions();
                data.unshift({
                    id: 'CERT-' + Math.floor(1000 + Math.random() * 9000),
                    name: name,
                    course: course,
                    date: new Date().toISOString().split('T')[0],
                    grade: grade,
                    status: 'Certified'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCourseCompletionTracking(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCompletionTrackingInfo('Completion Saved', 'Completion record has been added for ' + name + '.');
            });
        }

        modal.show();
    };
})();

