/* Consolidated Employee Self-Service (ESS) - Integrated Administrative Version */
window.HRSubmodules = window.HRSubmodules || {};

(function () {
    'use strict';

    // --- 1. SHARED DATA ENGINE (Strategic Alignment) ---
    const DB_KEYS = {
        MASTER: 'hospitalEmployees',
        TRIAGE: 'staffRequestsQueue',
        AUDIT: 'hrSystemAuditLogs'
    };

    function getDB(key) {
        const stored = localStorage.getItem(key);
        if (stored) return JSON.parse(stored);
        
        // Seed Data for initial system run
        if (key === DB_KEYS.MASTER) {
            const defaults = [
                { empId: 'MED-101', name: 'Dr. Julian Bashir', dept: 'Medical', status: 'Active', license: 'MD-9920', email: 'j.bashir@hospital.com', role: 'Chief Medical Officer' },
                { empId: 'ADM-202', name: 'Nyota Uhura', dept: 'Communications', status: 'Active', license: 'N/A', email: 'n.uhura@hospital.com', role: 'Communications Lead' }
            ];
            localStorage.setItem(key, JSON.stringify(defaults));
            return defaults;
        }
        return [];
    }

    function syncToGlobal(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
        // Triggers 'storage' listener in main-hr2.js for real-time dashboard updates
        window.dispatchEvent(new Event('storage'));
    }

    // --- 2. MODAL & UI HOSTING ---
    function ensureModalHost(id, title) {
        if (document.getElementById(id)) return;
        const modalHost = document.createElement('div');
        modalHost.innerHTML = `
            <div class="modal fade" id="${id}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow">
                        <div class="modal-header bg-light">
                            <h5 class="modal-title fw-bold" id="${id}Title">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body" id="${id}Body"></div>
                        <div class="modal-footer border-0" id="${id}Footer"></div>
                    </div>
                </div>
            </div>`;
        document.body.appendChild(modalHost.firstElementChild);
    }

    // --- 3. SUBMODULE RENDERERS ---

    // A. PERSONNEL MASTER FILE (Audit-Ready View)
    /**
 * SUBMODULE: PERSONNEL MASTER FILE (PMF)
 * Purpose: Administrative summary and audit view of all registered hospital staff.
 */
window.HRSubmodules.renderViewProfile = function (container) {
    if (!container) return;

    // Fetch the Source of Truth (Master Personnel File)
    const employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];

    container.innerHTML = `
        <div class="p-4 animate-fade-in pmf-portal">
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <div>
                    <h5 class="fw-bold mb-1 text-dark">Personnel Master File (PMF)</h5>
                    <p class="text-muted small mb-0">Centralized registry for staff identity and medical credential verification.</p>
                </div>
                <div class="badge bg-primary-subtle text-primary border-0 px-3 py-2">
                    <i class="fas fa-users me-1"></i> ${employees.length} Total Records
                </div>
            </div>

            <div class="row g-2 mb-4">
                <div class="col-md-8">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0"><i class="fas fa-filter text-muted"></i></span>
                        <input type="text" class="form-control border-start-0 shadow-none" placeholder="Filter by name, ID, or department...">
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <button class="btn btn-sm btn-outline-dark" onclick="window.print()">
                        <i class="fas fa-print me-1"></i> Print Registry
                    </button>
                </div>
            </div>

            <div class="table-responsive bg-white rounded shadow-sm border">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="extra-small text-uppercase text-secondary">
                            <th class="ps-3">Staff Identity & UID</th>
                            <th>Deployment / Role</th>
                            <th>Medical License</th>
                            <th>Official Email</th>
                            <th class="text-end pe-3">Audit</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${employees.length > 0 ? employees.map(emp => `
                            <tr>
                                <td class="ps-3">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sq me-3 bg-light d-flex align-items-center justify-content-center rounded" style="width: 35px; height: 35px;">
                                            <i class="fas fa-user-md text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark">${emp.name}</div>
                                            <div class="extra-small text-muted">ID: ${emp.empId}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="small fw-semibold text-dark">${emp.dept}</div>
                                    <div class="extra-small text-muted">${emp.role || 'Personnel'}</div>
                                </td>
                                <td>
                                    <span class="badge bg-green-subtle text-success border-0 px-2 py-1 small">
                                        <i class="fas fa-certificate me-1"></i> ${emp.license || 'N/A'}
                                    </span>
                                </td>
                                <td class="small text-muted">${emp.email}</td>
                                <td class="text-end pe-3">
                                    <button class="btn btn-sm btn-light border shadow-sm px-3" 
                                            onclick="window.HRSubmodules.triggerDetailedAudit('${emp.empId}')">
                                        <i class="fas fa-file-contract"></i>
                                    </button>
                                </td>
                            </tr>`).join('') : `
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <p class="text-muted mb-0">No personnel records found in the master file.</p>
                                </td>
                            </tr>`}
                    </tbody>
                </table>
            </div>
        </div>`;
};

/**
 * CORE LOGIC: DETAILED AUDIT
 * Provides a high-level compliance summary for a specific staff member.
 */
window.HRSubmodules.triggerDetailedAudit = function (id) {
    const employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];
    const emp = employees.find(e => e.empId === id);

    if (!emp) return;

    // Use a professional alert or modal for the audit trail
    alert(`
SYSTEM AUDIT LOG: ${new Date().toLocaleString()}
------------------------------------------------
STAFF: ${emp.name}
UID: ${emp.empId}
DEPT: ${emp.dept}
LICENSE: ${emp.license || 'No license on file'}
STATUS: COMPLIANT / ACTIVE
------------------------------------------------
This record is currently synchronized with Payroll and Scheduling.
    `);
};

    // B. MASTER DATA MAINTENANCE (Maintenance Portal)
    /**
 * SUBMODULE: MASTER DATA MAINTENANCE
 * Purpose: Administrative portal for modifying official personnel records and medical credentials.
 */
window.HRSubmodules.renderUpdatePersonalInfo = function (container) {
    if (!container) return;

    // Fetch live personnel from the master database
    const employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];

    container.innerHTML = `
        <div class="p-4 animate-fade-in maintenance-portal">
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <div>
                    <h5 class="fw-bold mb-1 text-dark">Master Data Maintenance</h5>
                    <p class="text-muted small mb-0">Modify official employment records and synchronize medical credentials.</p>
                </div>
            </div>

            <div class="card border-0 shadow-sm p-4 bg-light mb-4">
                <label class="form-label small fw-bold text-secondary mb-2">Search & Fetch Staff Record</label>
                <div class="input-group shadow-sm">
                    <span class="input-group-text bg-white border-0"><i class="fas fa-search text-muted"></i></span>
                    <select id="maintRecordSelector" class="form-select border-0 shadow-none">
                        <option value="">-- Select Staff Member by ID/Name --</option>
                        ${employees.map(e => `<option value="${e.empId}">${e.name} [ID: ${e.empId}]</option>`).join('')}
                    </select>
                    <button class="btn btn-dark px-4 fw-bold" onclick="window.HRSubmodules.fetchRecordForEdit()">
                        Fetch File
                    </button>
                </div>
            </div>

            <div id="maintenanceFormContainer" class="d-none">
                </div>

            <div id="maintenancePlaceholder" class="text-center py-5 opacity-50">
                <i class="fas fa-file-medical-alt fa-3x mb-3"></i>
                <p>Select a personnel record above to begin the maintenance cycle.</p>
            </div>
        </div>`;
};

/**
 * CORE LOGIC: FETCH RECORD
 * Populates the maintenance form with verified data from the master file.
 */
window.HRSubmodules.fetchRecordForEdit = function () {
    const empId = document.getElementById('maintRecordSelector').value;
    const formContainer = document.getElementById('maintenanceFormContainer');
    const placeholder = document.getElementById('maintenancePlaceholder');

    if (!empId) return;

    const employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];
    const emp = employees.find(e => e.empId === empId);

    if (!emp) return;

    // Hide placeholder and show form
    placeholder.classList.add('d-none');
    formContainer.classList.remove('d-none');

    formContainer.innerHTML = `
        <div class="card border-0 shadow-sm p-4 bg-white border-top border-primary border-4 animate-fade-in">
            <h6 class="fw-bold mb-4 text-primary d-flex align-items-center">
                <i class="fas fa-edit me-2"></i> Modifying Record: ${emp.empId}
            </h6>
            
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Full Legal Name</label>
                    <input type="text" id="editMaintName" class="form-control" value="${emp.name}">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Official Hospital Email</label>
                    <input type="email" id="editMaintEmail" class="form-control" value="${emp.email}">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Medical License / Professional ID</label>
                    <input type="text" id="editMaintLicense" class="form-control" value="${emp.license || ''}" placeholder="e.g. MD-XXXX">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Departmental Deployment</label>
                    <select id="editMaintDept" class="form-select">
                        <option value="Medical" ${emp.dept === 'Medical' ? 'selected' : ''}>Medical</option>
                        <option value="Nursing" ${emp.dept === 'Nursing' ? 'selected' : ''}>Nursing</option>
                        <option value="Admin" ${emp.dept === 'Admin' ? 'selected' : ''}>Administrative</option>
                        <option value="Laboratory" ${emp.dept === 'Laboratory' ? 'selected' : ''}>Laboratory</option>
                    </select>
                </div>
                <div class="col-12 mt-4 pt-3 border-top text-end">
                    <button class="btn btn-outline-secondary px-4 me-2" onclick="location.reload()">Cancel</button>
                    <button class="btn btn-success px-5 fw-bold" onclick="window.HRSubmodules.commitMaintToMaster('${empId}')">
                        Commit to Master File
                    </button>
                </div>
            </div>
        </div>`;
};

/**
 * CORE LOGIC: COMMIT CHANGES
 * Saves modified data and triggers a global sync.
 */
window.HRSubmodules.commitMaintToMaster = function (empId) {
    let employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];
    const index = employees.findIndex(e => e.empId === empId);

    if (index === -1) return;

    // Update the master record
    employees[index].name = document.getElementById('editMaintName').value;
    employees[index].email = document.getElementById('editMaintEmail').value;
    employees[index].license = document.getElementById('editMaintLicense').value;
    employees[index].dept = document.getElementById('editMaintDept').value;

    // Save to localStorage
    localStorage.setItem('hospitalEmployees', JSON.stringify(employees));

    // Dispatch 'storage' event to trigger real-time updates in main-hr2.js
    window.dispatchEvent(new Event('storage'));

    alert(`SYSTEM SUCCESS: Record ${empId} has been updated. Changes are now live across all hospital modules.`);
    
    // Refresh the view to show updated values in the dropdown
    window.HRSubmodules.renderUpdatePersonalInfo(document.getElementById('roleModuleOverviewBody'));
};

    window.HRSubmodules.renderSubmitRequests = function (container) {
    if (!container) return;

    // Fetch data from the shared triage queue
    const requests = JSON.parse(localStorage.getItem('staffRequestsQueue')) || [];
    
    // Sort requests by priority (High priority items first)
    const sortedRequests = [...requests].sort((a, b) => {
        if (a.priority === 'High' && b.priority !== 'High') return -1;
        if (a.priority !== 'High' && b.priority === 'High') return 1;
        return 0;
    });

    container.innerHTML = `
        <div class="p-4 animate-fade-in triage-portal">
            <div class="d-flex justify-content-between align-items-start mb-4 border-bottom pb-3">
                <div>
                    <h5 class="fw-bold mb-1 text-dark">Administrative Triage Queue</h5>
                    <p class="text-muted small mb-0">Review and resolve incoming staff applications for leave, documents, and reimbursements.</p>
                </div>
                <div class="text-end">
                    <div class="badge bg-primary-subtle text-primary border-0 px-3 py-2">
                        <i class="fas fa-clock me-1"></i> ${requests.length} Active Tasks
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3 bg-white border-start border-danger border-4">
                        <div class="extra-small text-uppercase fw-bold text-muted">High Priority (Urgent)</div>
                        <div class="h3 mb-0 fw-bold text-danger">${requests.filter(r => r.priority === 'High').length}</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3 bg-white border-start border-primary border-4">
                        <div class="extra-small text-uppercase fw-bold text-muted">Standard Requests</div>
                        <div class="h3 mb-0 fw-bold text-primary">${requests.filter(r => r.priority !== 'High').length}</div>
                    </div>
                </div>
            </div>

            <div class="table-responsive bg-white rounded shadow-sm border">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="extra-small text-uppercase text-secondary">
                            <th class="ps-3" style="width: 30%;">Personnel & Dept</th>
                            <th style="width: 20%;">Request Category</th>
                            <th style="width: 15%;">Urgency</th>
                            <th style="width: 15%;">Received</th>
                            <th class="text-end pe-3" style="width: 20%;">Decision</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${sortedRequests.length > 0 ? sortedRequests.map(req => `
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark">${req.staffName || 'Unknown Staff'}</div>
                                    <div class="extra-small text-muted">REF: #${req.id} | ${req.dept || 'General'}</div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border px-2 py-1 small fw-normal">${req.type || 'Administrative'}</span>
                                </td>
                                <td>
                                    <span class="badge ${req.priority === 'High' ? 'bg-danger' : 'bg-warning'} border-0 px-2">
                                        ${req.priority || 'Normal'}
                                    </span>
                                </td>
                                <td class="small text-muted">${req.date || new Date().toLocaleDateString()}</td>
                                <td class="text-end pe-3">
                                    <div class="btn-group shadow-sm">
                                        <button class="btn btn-sm btn-success px-3" 
                                                onclick="window.HRSubmodules.executeTriageAction(${req.id}, 'Approved')">
                                            Approve
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger px-3" 
                                                onclick="window.HRSubmodules.executeTriageAction(${req.id}, 'Denied')">
                                            Deny
                                        </button>
                                    </div>
                                </td>
                            </tr>`).join('') : `
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <div class="opacity-50">
                                        <i class="fas fa-check-double fa-3x mb-3"></i>
                                        <p class="mb-0">Triage complete. No pending administrative actions.</p>
                                    </div>
                                </td>
                            </tr>`}
                    </tbody>
                </table>
            </div>
        </div>`;
};

/**
 * SUBMODULE: COMPLIANCE & EMPLOYMENT RECORDS
 * Purpose: High-level administrative oversight of contract integrity and license compliance.
 */
window.HRSubmodules.renderViewEmploymentRecords = function (container) {
    if (!container) return;

    // Fetch live data from the master personnel file
    const employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];
    
    // Calculate Administrative Analytics
    const totalStaff = employees.length;
    const medicalStaff = employees.filter(e => e.dept === 'Medical').length;
    const nursingStaff = employees.filter(e => e.dept === 'Nursing').length;
    
    // Logic: Identify records missing license data (Critical for Hospital Compliance)
    const nonCompliant = employees.filter(e => !e.license || e.license === 'N/A' || e.license === '').length;
    const complianceRate = totalStaff > 0 ? Math.round(((totalStaff - nonCompliant) / totalStaff) * 100) : 0;

    container.innerHTML = `
        <div class="p-4 animate-fade-in compliance-portal">
            <div class="mb-4 border-bottom pb-3">
                <h5 class="fw-bold mb-1 text-dark">Employment & Compliance Oversight</h5>
                <p class="text-muted small mb-0">Monitor workforce distribution and regulatory license standing.</p>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3 bg-white border-start border-primary border-4">
                        <div class="extra-small text-uppercase fw-bold text-muted">Active Personnel</div>
                        <div class="h3 mb-0 fw-bold text-primary">${totalStaff}</div>
                        <div class="extra-small text-muted mt-1">Total Registered Staff</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-4">
                        <div class="extra-small text-uppercase fw-bold text-muted">License Compliance</div>
                        <div class="h3 mb-0 fw-bold text-success">${complianceRate}%</div>
                        <div class="extra-small text-muted mt-1">Verified Medical Credentials</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3 bg-white border-start border-warning border-4">
                        <div class="extra-small text-uppercase fw-bold text-muted">Pending Audits</div>
                        <div class="h3 mb-0 fw-bold text-warning">${nonCompliant}</div>
                        <div class="extra-small text-muted mt-1">Records Requiring Review</div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="fw-bold mb-0 text-dark">Workforce Distribution</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between mb-1 small">
                                <span>Medical Department</span>
                                <span class="fw-bold">${medicalStaff}</span>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-primary" style="width: ${(medicalStaff/totalStaff)*100}%"></div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between mb-1 small">
                                <span>Nursing & Clinical</span>
                                <span class="fw-bold">${nursingStaff}</span>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-info" style="width: ${(nursingStaff/totalStaff)*100}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            ${nonCompliant > 0 ? `
                <div class="alert alert-warning border-0 shadow-sm d-flex align-items-center">
                    <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                    <div>
                        <div class="fw-bold">Regulatory Action Required</div>
                        <div class="small">There are <strong>${nonCompliant}</strong> personnel records missing valid medical licenses. Access the <strong>Master Data Maintenance</strong> portal to update these files.</div>
                    </div>
                </div>
            ` : `
                <div class="alert alert-success border-0 shadow-sm d-flex align-items-center">
                    <i class="fas fa-check-circle fa-2x me-3"></i>
                    <div>
                        <div class="fw-bold">Compliance Standard Met</div>
                        <div class="small">All medical staff licenses are currently verified and up to date.</div>
                    </div>
                </div>
            `}
        </div>`;
};

    // --- 4. CORE ADMINISTRATIVE LOGIC ---

    window.HRSubmodules.loadForMaint = function() {
        const id = document.getElementById('maintSelector').value;
        const area = document.getElementById('maintFormArea');
        if (!id) return;

        const emp = getDB(DB_KEYS.MASTER).find(e => e.empId === id);
        area.classList.remove('d-none');
        area.innerHTML = `
            <div class="card border-0 shadow-sm p-4 bg-white animate-fade-in border-top border-primary border-4">
                <h6 class="fw-bold mb-3 border-bottom pb-2 text-primary">Record Integrity: ${id}</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Full Legal Name</label>
                        <input type="text" id="maintName" class="form-control shadow-none" value="${emp.name}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Official Email</label>
                        <input type="email" id="maintEmail" class="form-control shadow-none" value="${emp.email}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Medical License / ID</label>
                        <input type="text" id="maintLicense" class="form-control shadow-none" value="${emp.license || ''}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Deployment (Dept)</label>
                        <select id="maintDept" class="form-select shadow-none">
                            <option ${emp.dept === 'Medical' ? 'selected' : ''}>Medical</option>
                            <option ${emp.dept === 'Nursing' ? 'selected' : ''}>Nursing</option>
                            <option ${emp.dept === 'Admin' ? 'selected' : ''}>Admin</option>
                            <option ${emp.dept === 'Communications' ? 'selected' : ''}>Communications</option>
                        </select>
                    </div>
                    <div class="col-12 text-end mt-4">
                        <button class="btn btn-success px-5 fw-bold" onclick="window.HRSubmodules.commitMaintChanges('${id}')">Commit to Master File</button>
                    </div>
                </div>
            </div>`;
    };

    window.HRSubmodules.commitMaintChanges = function(id) {
        let employees = getDB(DB_KEYS.MASTER);
        const idx = employees.findIndex(e => e.empId === id);
        
        if (idx === -1) return;

        // Apply modifications
        employees[idx].name = document.getElementById('maintName').value;
        employees[idx].email = document.getElementById('maintEmail').value;
        employees[idx].license = document.getElementById('maintLicense').value;
        employees[idx].dept = document.getElementById('maintDept').value;
        
        syncToGlobal(DB_KEYS.MASTER, employees);
        
        alert("ALIGNED: Personnel record updated and synchronized across all HR2 modules.");
        // Re-render maintenance view to show updated data in dropdown
        window.HRSubmodules.renderUpdatePersonalInfo(document.getElementById('roleModuleOverviewBody'));
    };

    window.HRSubmodules.viewDetailedAudit = function(id) {
        const emp = getDB(DB_KEYS.MASTER).find(e => e.empId === id);
        ensureModalHost('essAuditModal', 'Personnel Audit Record');
        
        const body = document.getElementById('essAuditModalBody');
        const footer = document.getElementById('essAuditModalFooter');

        body.innerHTML = `
            <div class="text-center p-3">
                <i class="fas fa-user-shield fa-3x text-primary mb-3"></i>
                <h5 class="fw-bold mb-1">${emp.name}</h5>
                <p class="text-muted small">UID: ${emp.empId} | Dept: ${emp.dept}</p>
                <div class="alert alert-info py-2 small mt-3">License: <strong>${emp.license || 'Verified'}</strong></div>
            </div>`;
        
        footer.innerHTML = `<button class="btn btn-secondary w-100" data-bs-dismiss="modal">Close Record</button>`;
        bootstrap.Modal.getOrCreateInstance(document.getElementById('essAuditModal')).show();
    };

    window.HRSubmodules.executeTriageAction = function (id, action) {
    let requests = JSON.parse(localStorage.getItem('staffRequestsQueue')) || [];
    
    // In a professional system, we'd log this resolution to an audit trail before removing
    requests = requests.filter(r => r.id !== id);
    
    // Save updated state
    localStorage.setItem('staffRequestsQueue', JSON.stringify(requests));
    
    // Dispatch event to main-hr2.js to update dashboard counters immediately
    window.dispatchEvent(new Event('storage'));
    
    // Provide HR Operational Feedback
    alert(`ADMIN ACTION RECORDED: Request #${id} has been ${action}. Personnel records have been synchronized.`);
    
    // Re-render the current view to reflect the cleared item
    window.HRSubmodules.renderSubmitRequests(document.getElementById('roleModuleOverviewBody'));
};

})();

