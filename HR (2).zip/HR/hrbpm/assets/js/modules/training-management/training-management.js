/* Consolidated training-management module scripts */

/* Source: submodules/training-attendance.js */
/**
 * Training Attendance Submodule
 * Professional Participation & Roll-call Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrAttendance';

    const getAttendance = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Baseline Attendance Records
        return [
            { id: "ATT-001", name: "Dr. Aris Thorne", session: "Advanced Life Support Prep", date: "2024-06-15", status: "Present", timeIn: "08:55 AM" },
            { id: "ATT-002", name: "Sarah Jenkins", session: "Advanced Life Support Prep", date: "2024-06-15", status: "Excused", timeIn: "-" },
            { id: "ATT-003", name: "James Miller", session: "Cybersecurity Protocol", date: "2024-06-20", status: "Absent", timeIn: "-" }
        ];
    };

    function ensureTrainingAttendanceModalHost() {
        if (document.getElementById('trainingAttendanceModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingAttendanceModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingAttendanceModalTitle">Training Attendance</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingAttendanceModalBody"></div>',
            '      <div class="modal-footer" id="trainingAttendanceModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingAttendanceInfo(title, message) {
        const modalEl = document.getElementById('trainingAttendanceModal');
        const titleEl = document.getElementById('trainingAttendanceModalTitle');
        const bodyEl = document.getElementById('trainingAttendanceModalBody');
        const footerEl = document.getElementById('trainingAttendanceModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingAttendance = function (container) {
        ensureTrainingAttendanceModalHost();

        const records = getAttendance();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-check text-success me-2"></i>Live Session Attendance</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Daily Participation Tracking</small>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.exportAttendance()">
                            <i class="fas fa-file-export me-1"></i> Export
                        </button>
                        <button class="btn btn-success btn-sm rounded-pill px-3" onclick="window.HRSubmodules.markAttendance()">
                            <i class="fas fa-check-double me-1"></i> Mark Attendance
                        </button>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-attendance-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Attendee</th>
                                <th style="width: 30%">Session Title</th>
                                <th style="width: 15%">Check-In</th>
                                <th style="width: 15%">Status</th>
                                <th class="text-end pe-4" style="width: 15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${records.map(record => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${record.name}</div>
                                        <div class="extra-small text-muted">Ref: ${record.id}</div>
                                    </td>
                                    <td>
                                        <div class="small text-dark fw-medium text-truncate" style="max-width: 200px;">${record.session}</div>
                                        <div class="extra-small text-muted">${record.date}</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border extra-small">${record.timeIn}</span>
                                    </td>
                                    <td>
                                        <span class="attendance-pill ${record.status.toLowerCase()}">${record.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-link text-primary p-0" onclick="window.HRSubmodules.editAttendanceRecord('${record.id}')">Edit</button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.markAttendance = function() {
        const modalEl = document.getElementById('trainingAttendanceModal');
        const titleEl = document.getElementById('trainingAttendanceModalTitle');
        const bodyEl = document.getElementById('trainingAttendanceModalBody');
        const footerEl = document.getElementById('trainingAttendanceModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Mark Attendance';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Attendee Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingAttendanceName" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Session Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingAttendanceSession" placeholder="e.g. Advanced Life Support Prep">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Status</label>',
            '  <select class="form-select form-select-sm" id="trainingAttendanceStatus">',
            '    <option value="Present">Present</option>',
            '    <option value="Excused">Excused</option>',
            '    <option value="Absent">Absent</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="trainingAttendanceSaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('trainingAttendanceSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const name = (document.getElementById('trainingAttendanceName').value || '').trim();
                const session = (document.getElementById('trainingAttendanceSession').value || '').trim();
                const status = (document.getElementById('trainingAttendanceStatus').value || '').trim() || 'Present';
                if (!name || !session) {
                    return;
                }

                let records = getAttendance();
                records.unshift({
                    id: 'ATT-' + Math.floor(100 + Math.random() * 899),
                    name: name,
                    session: session,
                    date: new Date().toISOString().split('T')[0],
                    status: status,
                    timeIn: status === 'Present'
                        ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        : '-'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingAttendance(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingAttendanceInfo('Attendance Saved', name + ' was marked as ' + status + '.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.editAttendanceRecord = function (recordId) {
        const records = getAttendance();
        const target = records.find(function (record) { return record.id === recordId; });
        if (!target) {
            return;
        }

        showTrainingAttendanceInfo('Attendance Entry', target.id + ' belongs to ' + target.name + ' for ' + target.session + '.');
    };
})();

/* Source: submodules/training-evaluation.js */
/**
 * Training Evaluation Submodule
 * Professional Feedback & Quality Metrics
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrEvaluations';

    const getEvaluations = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Feedback Data
        return [
            { id: "EVL-501", course: "Advanced Life Support", staff: "Dr. Aris Thorne", rating: 5, comment: "Excellent hands-on simulation.", date: "2024-06-16" },
            { id: "EVL-502", course: "HIPAA Compliance", staff: "Sarah Jenkins", rating: 3, comment: "A bit long, but informative.", date: "2024-06-15" },
            { id: "EVL-503", course: "Emergency Response", staff: "James Miller", rating: 4, comment: "Very practical for night shifts.", date: "2024-06-14" }
        ];
    };

    function ensureTrainingEvaluationModalHost() {
        if (document.getElementById('trainingEvaluationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingEvaluationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingEvaluationModalTitle">Training Evaluation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingEvaluationModalBody"></div>',
            '      <div class="modal-footer" id="trainingEvaluationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingEvaluationInfo(title, message) {
        const modalEl = document.getElementById('trainingEvaluationModal');
        const titleEl = document.getElementById('trainingEvaluationModalTitle');
        const bodyEl = document.getElementById('trainingEvaluationModalBody');
        const footerEl = document.getElementById('trainingEvaluationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingEvaluation = function (container) {
        ensureTrainingEvaluationModalHost();

        const evals = getEvaluations();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-star-half-stroke text-warning me-2"></i>Training Quality Feedback</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Post-session Staff Evaluations</small>
                    </div>
                    <button class="btn btn-warning btn-sm text-white rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.submitNewEvaluation()">
                        <i class="fas fa-pen-nib me-1"></i> New Evaluation
                    </button>
                </div>

                <div class="row g-3">
                    ${evals.map(evalItem => `
                        <div class="col-xl-6 col-md-12">
                            <div class="eval-card bg-white border rounded-4 p-3 shadow-sm h-100">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <div class="fw-bold text-dark small">${evalItem.course}</div>
                                        <div class="extra-small text-muted">${evalItem.staff} • ${evalItem.date}</div>
                                    </div>
                                    <div class="rating-stars text-warning small">
                                        ${Array(5).fill(0).map((_, i) => `<i class="${i < evalItem.rating ? 'fas' : 'far'} fa-star"></i>`).join('')}
                                    </div>
                                </div>
                                <div class="eval-comment bg-light p-2 rounded-3 mt-2">
                                    <p class="mb-0 text-muted italic small font-serif">"${evalItem.comment}"</p>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.submitNewEvaluation = function() {
        const modalEl = document.getElementById('trainingEvaluationModal');
        const titleEl = document.getElementById('trainingEvaluationModalTitle');
        const bodyEl = document.getElementById('trainingEvaluationModalBody');
        const footerEl = document.getElementById('trainingEvaluationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Submit Evaluation';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingEvalCourse" placeholder="e.g. Emergency Response">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Rating (1-5)</label>',
            '  <input type="number" class="form-control form-control-sm" id="trainingEvalRating" min="1" max="5" step="1" value="5">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Feedback Comment</label>',
            '  <textarea class="form-control form-control-sm" id="trainingEvalComment" rows="3" placeholder="Share your feedback"></textarea>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-warning text-white" id="trainingEvalSubmitBtn">Submit</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const submitBtn = document.getElementById('trainingEvalSubmitBtn');
        if (submitBtn) {
            submitBtn.addEventListener('click', function () {
                const course = (document.getElementById('trainingEvalCourse').value || '').trim();
                const ratingValue = parseInt((document.getElementById('trainingEvalRating').value || '').trim(), 10);
                const comment = (document.getElementById('trainingEvalComment').value || '').trim() || 'No comments provided.';
                if (!course || Number.isNaN(ratingValue)) {
                    return;
                }

                let evals = getEvaluations();
                evals.unshift({
                    id: 'EVL-' + Math.floor(500 + Math.random() * 499),
                    course: course,
                    staff: 'Current User',
                    rating: ratingValue,
                    comment: comment,
                    date: new Date().toISOString().split('T')[0]
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingEvaluation(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingEvaluationInfo('Evaluation Saved', 'Your feedback for ' + course + ' has been recorded.');
            });
        }

        modal.show();
    };
})();

/* Source: submodules/training-programs.js */
/**
 * Training Programs Submodule
 * Professional Strategic Initiative Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrTrainingPrograms';

    const getPrograms = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Training Initiatives
        return [
            { id: "PROG-001", name: "2024 Leadership Excellence", type: "Workshop Series", cohorts: 3, lead: "Dr. Elena Vance", status: "In Progress" },
            { id: "PROG-002", name: "Emergency Response Drill", type: "Simulation", cohorts: 12, lead: "Marcus Thorne", status: "Scheduled" },
            { id: "PROG-003", name: "Digital Records Migration", type: "Technical", cohorts: 5, lead: "IT Dept", status: "Completed" }
        ];
    };

    function ensureTrainingProgramModalHost() {
        if (document.getElementById('trainingProgramsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingProgramsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingProgramsModalTitle">Training Programs</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingProgramsModalBody"></div>',
            '      <div class="modal-footer" id="trainingProgramsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingProgramInfo(title, message) {
        const modalEl = document.getElementById('trainingProgramsModal');
        const titleEl = document.getElementById('trainingProgramsModalTitle');
        const bodyEl = document.getElementById('trainingProgramsModalBody');
        const footerEl = document.getElementById('trainingProgramsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingPrograms = function (container) {
        ensureTrainingProgramModalHost();

        const programs = getPrograms();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-chalkboard-user text-info me-2"></i>Strategic Training Initiatives</h6>
                        <small class="text-muted">High-level developmental programs and institutional workshops</small>
                    </div>
                    <button class="btn btn-info btn-sm text-white rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.initiateNewProgram()">
                        <i class="fas fa-rocket me-1"></i> New Initiative
                    </button>
                </div>

                <div class="row g-4">
                    ${programs.map(prog => `
                        <div class="col-xl-4 col-md-6">
                            <div class="program-card border rounded-4 bg-white shadow-sm h-100 position-relative overflow-hidden">
                                <div class="program-type-tag">${prog.type}</div>
                                <div class="p-4 pt-5">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h6 class="fw-bold text-dark mb-0 pe-2" style="line-height: 1.4; min-height: 44px;">${prog.name}</h6>
                                        <span class="badge ${getStatusBadgeClass(prog.status)}">${prog.status}</span>
                                    </div>
                                    
                                    <div class="program-meta-grid border-top pt-3 mt-2">
                                        <div class="row text-center">
                                            <div class="col-6 border-end">
                                                <div class="extra-small text-muted text-uppercase fw-bold">Cohorts</div>
                                                <div class="fw-bold text-primary">${prog.cohorts}</div>
                                            </div>
                                            <div class="col-6">
                                                <div class="extra-small text-muted text-uppercase fw-bold">Program Lead</div>
                                                <div class="small fw-semibold text-dark text-truncate px-1">${prog.lead}</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4 pt-2 d-flex gap-2">
                                        <button class="btn btn-light btn-sm flex-grow-1 border" onclick="window.HRSubmodules.viewProgramDetails('${prog.id}')">Details</button>
                                        <button class="btn btn-outline-info btn-sm flex-grow-1" onclick="window.HRSubmodules.viewProgramCohorts('${prog.id}')">Cohorts</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    function getStatusBadgeClass(status) {
        switch(status) {
            case 'Completed': return 'bg-success-subtle text-success';
            case 'In Progress': return 'bg-info-subtle text-info';
            case 'Scheduled': return 'bg-warning-subtle text-warning';
            default: return 'bg-secondary-subtle text-secondary';
        }
    }

    window.HRSubmodules.initiateNewProgram = function() {
        const modalEl = document.getElementById('trainingProgramsModal');
        const titleEl = document.getElementById('trainingProgramsModalTitle');
        const bodyEl = document.getElementById('trainingProgramsModalBody');
        const footerEl = document.getElementById('trainingProgramsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'New Training Initiative';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Program Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingProgramName" placeholder="e.g. Emergency Drill Bootcamp">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Program Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingProgramType" placeholder="Workshop/Simulation/Series">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Program Lead</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingProgramLead" value="Unassigned">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-info text-white" id="trainingProgramCreateBtn">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('trainingProgramCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('trainingProgramName').value || '').trim();
                const type = (document.getElementById('trainingProgramType').value || '').trim();
                const lead = (document.getElementById('trainingProgramLead').value || '').trim() || 'Unassigned';
                if (!name || !type) {
                    return;
                }

                let programs = getPrograms();
                programs.unshift({
                    id: 'PROG-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    type: type,
                    cohorts: 1,
                    lead: lead,
                    status: 'Scheduled'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(programs));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingPrograms(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingProgramInfo('Initiative Created', name + ' has been added as a new training initiative.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewProgramDetails = function (programId) {
        const programs = getPrograms();
        const target = programs.find(function (item) { return item.id === programId; });
        if (!target) {
            return;
        }

        showTrainingProgramInfo('Program Details', target.id + ' - ' + target.name + ' (' + target.status + ').');
    };

    window.HRSubmodules.viewProgramCohorts = function (programId) {
        const programs = getPrograms();
        const target = programs.find(function (item) { return item.id === programId; });
        if (!target) {
            return;
        }

        showTrainingProgramInfo('Cohort Overview', target.name + ' currently has ' + target.cohorts + ' active cohort(s).');
    };
})();

/* Source: submodules/training-schedule.js */
/**
 * Training Schedule Submodule
 * Professional Timeline & Session Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrTrainingSchedule';

    const getSchedule = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Professional Schedule
        return [
            { id: "SCH-001", title: "Advanced Life Support Prep", date: "2024-06-15", time: "09:00 AM", location: "Room 302", instructor: "Dr. Aris Thorne", type: "Clinical" },
            { id: "SCH-002", title: "New Employee Orientation", date: "2024-06-18", time: "10:30 AM", location: "Main Hall", instructor: "HR Dept", type: "Admin" },
            { id: "SCH-003", title: "Cybersecurity Protocol Update", date: "2024-06-20", time: "02:00 PM", location: "Virtual", instructor: "IT Security", type: "Technical" }
        ];
    };

    function ensureTrainingScheduleModalHost() {
        if (document.getElementById('trainingScheduleModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingScheduleModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingScheduleModalTitle">Training Schedule</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingScheduleModalBody"></div>',
            '      <div class="modal-footer" id="trainingScheduleModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingScheduleInfo(title, message) {
        const modalEl = document.getElementById('trainingScheduleModal');
        const titleEl = document.getElementById('trainingScheduleModalTitle');
        const bodyEl = document.getElementById('trainingScheduleModalBody');
        const footerEl = document.getElementById('trainingScheduleModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingSchedule = function (container) {
        ensureTrainingScheduleModalHost();

        const schedule = getSchedule();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-calendar-alt text-primary me-2"></i>Institutional Training Schedule</h6>
                        <small class="text-muted">Live calendar of upcoming workshops, drills, and certifications</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.createNewEvent()">
                        <i class="fas fa-plus me-1"></i> Add Session
                    </button>
                </div>

                <div class="timeline-container bg-white border rounded-3 shadow-sm p-4">
                    ${schedule.map((item, index) => `
                        <div class="timeline-item d-flex pb-4 ${index === schedule.length - 1 ? 'mb-0' : 'mb-4 border-bottom'}">
                            <div class="date-badge text-center me-4" style="min-width: 60px;">
                                <div class="month extra-small fw-bold text-uppercase text-primary">${new Date(item.date).toLocaleString('default', { month: 'short' })}</div>
                                <div class="day h4 fw-bold mb-0">${new Date(item.date).getDate()}</div>
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <h6 class="fw-bold text-dark mb-0">${item.title}</h6>
                                    <span class="badge ${item.type === 'Clinical' ? 'bg-danger-subtle text-danger' : 'bg-info-subtle text-info'} extra-small rounded-pill">${item.type}</span>
                                </div>
                                <div class="d-flex flex-wrap gap-3 text-muted extra-small mt-2">
                                    <span><i class="far fa-clock me-1"></i> ${item.time}</span>
                                    <span><i class="fas fa-map-marker-alt me-1"></i> ${item.location}</span>
                                    <span><i class="fas fa-user-tie me-1"></i> ${item.instructor}</span>
                                </div>
                            </div>
                            <div class="ms-3">
                                <button class="btn btn-outline-secondary btn-sm rounded-circle" onclick="window.HRSubmodules.viewSessionRegistry('${item.id}')"><i class="fas fa-users"></i></button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.createNewEvent = function() {
        const modalEl = document.getElementById('trainingScheduleModal');
        const titleEl = document.getElementById('trainingScheduleModalTitle');
        const bodyEl = document.getElementById('trainingScheduleModalBody');
        const footerEl = document.getElementById('trainingScheduleModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add Training Session';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Session Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingSessionTitle" placeholder="e.g. ER Protocol Review">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Date</label>',
            '  <input type="date" class="form-control form-control-sm" id="trainingSessionDate">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Session Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingSessionType" value="Admin">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="trainingSessionCreateBtn">Create Session</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('trainingSessionCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const title = (document.getElementById('trainingSessionTitle').value || '').trim();
                const date = (document.getElementById('trainingSessionDate').value || '').trim();
                const type = (document.getElementById('trainingSessionType').value || '').trim() || 'Admin';
                if (!title || !date) {
                    return;
                }

                let schedule = getSchedule();
                schedule.unshift({
                    id: 'SCH-' + Math.floor(100 + Math.random() * 900),
                    title: title,
                    date: date,
                    time: '09:00 AM',
                    location: 'TBD',
                    instructor: 'To Be Assigned',
                    type: type
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(schedule));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingSchedule(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingScheduleInfo('Session Added', title + ' was added to the training calendar.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewSessionRegistry = function (sessionId) {
        const schedule = getSchedule();
        const target = schedule.find(function (item) { return item.id === sessionId; });
        if (!target) {
            return;
        }

        showTrainingScheduleInfo('Session Registry', 'Registry for ' + target.title + ' is available for facilitator ' + target.instructor + '.');
    };
})();

