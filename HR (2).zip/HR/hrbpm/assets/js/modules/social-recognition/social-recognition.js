/* Consolidated social-recognition module scripts */

/* Source: submodules/awards-commendations.js */
/**
 * Awards & Commendations Submodule
 * Official Hospital Registry for Career Milestones
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCommendations';

    const getCommendations = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical Commendation Records
        return [
            { id: "CERT-2026-001", name: "Dr. Aris Thorne", title: "DOH Outstanding Physician", level: "National", date: "2026-01-15" },
            { id: "CERT-2026-002", name: "Sarah Jenkins", title: "Patient Safety Advocate Award", level: "Institutional", date: "2026-02-10" }
        ];
    };

    function ensureCommendationModalHost() {
        if (document.getElementById('awardsCommendationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="awardsCommendationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="awardsCommendationModalTitle">Awards Registry</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="awardsCommendationModalBody"></div>',
            '      <div class="modal-footer" id="awardsCommendationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCommendationInfo(title, message) {
        const modalEl = document.getElementById('awardsCommendationModal');
        const titleEl = document.getElementById('awardsCommendationModalTitle');
        const bodyEl = document.getElementById('awardsCommendationModalBody');
        const footerEl = document.getElementById('awardsCommendationModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderAwardsCommendations = function (container) {
        ensureCommendationModalHost();

        const data = getCommendations();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-certificate text-danger me-2"></i>Awards Registry</h6>
                        <small class="text-muted text-uppercase" style="font-size: 10px; letter-spacing: 1px;">Official Records of Merit</small>
                    </div>
                    <button class="btn btn-dark btn-sm px-3 shadow-sm" onclick="window.HRSubmodules.recordNewAward()">
                        <i class="fas fa-pen-nib me-2"></i>Record Commendation
                    </button>
                </div>

                <div class="commendation-list">
                    ${data.map(item => `
                        <div class="commendation-item d-flex align-items-center bg-white p-3 mb-3 border rounded-3 shadow-sm">
                            <div class="award-seal me-4">
                                <i class="fas fa-ribbon fa-2x"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-0 text-dark">${item.title}</h6>
                                <div class="d-flex gap-3 mt-1">
                                    <span class="small text-muted"><i class="fas fa-user me-1"></i> ${item.name}</span>
                                    <span class="badge ${item.level === 'National' ? 'bg-info' : 'bg-light text-dark'} border" style="font-size: 9px;">${item.level}</span>
                                </div>
                            </div>
                            <div class="text-end border-start ps-4">
                                <div class="fw-bold text-dark small">${item.date}</div>
                                <div class="extra-small text-muted">${item.id}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.recordNewAward = function() {
        const modalEl = document.getElementById('awardsCommendationModal');
        const titleEl = document.getElementById('awardsCommendationModalTitle');
        const bodyEl = document.getElementById('awardsCommendationModalBody');
        const footerEl = document.getElementById('awardsCommendationModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Record Commendation';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Official Award Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="commendationTitleInput" placeholder="e.g. DOH Excellence in Service">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Recipient Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="commendationNameInput" placeholder="e.g. Dr. Aris Thorne">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Award Level</label>',
            '  <select class="form-select form-select-sm" id="commendationLevelInput">',
            '    <option>Institutional</option>',
            '    <option>Regional</option>',
            '    <option>National</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-dark" id="commendationSaveBtn">Record</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('commendationSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const title = (document.getElementById('commendationTitleInput').value || '').trim();
                const name = (document.getElementById('commendationNameInput').value || '').trim();
                const level = (document.getElementById('commendationLevelInput').value || 'Institutional').trim();
                if (!title || !name) {
                    return;
                }

                let data = getCommendations();
                data.unshift({
                    id: 'CERT-2026-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    title: title,
                    level: level,
                    date: new Date().toISOString().split('T')[0]
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderAwardsCommendations(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showCommendationInfo('Commendation Recorded', title + ' has been added for ' + name + '.');
            });
        }

        modal.show();
    };

})();

/* Source: submodules/employee-recognition.js */
/**
 * Employee Recognition Submodule
 * Professional "Wall of Fame" and Award System
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrRecognitions';

    const getAwards = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Recognition Data
        return [
            { id: "AWARD-001", name: "Dr. Aris Thorne", award: "Physician of the Month", date: "2026-02-28", icon: "fa-stethoscopes", color: "#0d6efd" },
            { id: "AWARD-002", name: "Sarah Jenkins", award: "Leadership Excellence", date: "2026-03-01", icon: "fa-star", color: "#ffc107" },
            { id: "AWARD-003", name: "James Miller", award: "Service Reliability", date: "2026-03-04", icon: "fa-check-circle", color: "#198754" }
        ];
    };

    function ensureRecognitionModalHost() {
        if (document.getElementById('employeeRecognitionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="employeeRecognitionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="employeeRecognitionModalTitle">Employee Recognition</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="employeeRecognitionModalBody"></div>',
            '      <div class="modal-footer" id="employeeRecognitionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showRecognitionInfo(title, message) {
        const modalEl = document.getElementById('employeeRecognitionModal');
        const titleEl = document.getElementById('employeeRecognitionModalTitle');
        const bodyEl = document.getElementById('employeeRecognitionModalBody');
        const footerEl = document.getElementById('employeeRecognitionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderEmployeeRecognition = function (container) {
        ensureRecognitionModalHost();

        const awards = getAwards();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-trophy text-warning me-2"></i>Employee Recognition</h6>
                        <small class="text-muted">Celebrating excellence and commitment in healthcare</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4" onclick="window.HRSubmodules.nominateStaff()">
                        <i class="fas fa-medal me-1"></i> Nominate Staff
                    </button>
                </div>

                <div class="row g-4">
                    ${awards.map(item => `
                        <div class="col-xl-4 col-md-6">
                            <div class="recognition-card p-4 border rounded-4 bg-white shadow-sm text-center">
                                <div class="award-icon-wrapper mb-3" style="background-color: ${item.color}15; color: ${item.color};">
                                    <i class="fas ${item.icon} fa-2x"></i>
                                </div>
                                <h5 class="fw-bold text-dark mb-1">${item.name}</h5>
                                <p class="text-primary fw-semibold mb-3 small text-uppercase">${item.award}</p>
                                
                                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                    <span class="text-muted extra-small">ID: ${item.id}</span>
                                    <span class="text-muted extra-small"><i class="far fa-calendar-alt me-1"></i>${item.date}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.nominateStaff = function() {
        const modalEl = document.getElementById('employeeRecognitionModal');
        const titleEl = document.getElementById('employeeRecognitionModalTitle');
        const bodyEl = document.getElementById('employeeRecognitionModalBody');
        const footerEl = document.getElementById('employeeRecognitionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Nominate Staff';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="recognitionStaffName" placeholder="e.g. Maria Santos">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Award Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="recognitionAwardTitle" placeholder="e.g. Service Excellence">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="recognitionNominateBtn">Submit Nomination</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const nominateBtn = document.getElementById('recognitionNominateBtn');
        if (nominateBtn) {
            nominateBtn.addEventListener('click', function () {
                const name = (document.getElementById('recognitionStaffName').value || '').trim();
                const awardType = (document.getElementById('recognitionAwardTitle').value || '').trim();
                if (!name || !awardType) {
                    return;
                }

                let awards = getAwards();
                awards.unshift({
                    id: 'AWARD-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    award: awardType,
                    date: new Date().toLocaleDateString(),
                    icon: 'fa-award',
                    color: '#6f42c1'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(awards));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderEmployeeRecognition(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showRecognitionInfo('Nomination Submitted', name + ' has been nominated for ' + awardType + '.');
            });
        }

        modal.show();
    };

})();

/* Source: submodules/recognition-history.js */
/**
 * Recognition History Submodule
 * Comprehensive Archive of Staff Achievements
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrRecognitions';

    const getHistory = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    };

    function ensureRecognitionHistoryModal() {
        if (document.getElementById('recognitionHistoryModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="recognitionHistoryModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="recognitionHistoryModalTitle">Recognition Record</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="recognitionHistoryModalBody"></div>',
            '      <div class="modal-footer">',
            '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function attachRecognitionHistoryInteractions(history) {
        const searchInput = document.getElementById('historySearch');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                const term = (searchInput.value || '').trim().toLowerCase();
                document.querySelectorAll('.timeline-item').forEach(function (itemEl) {
                    const haystack = (itemEl.textContent || '').toLowerCase();
                    itemEl.style.display = haystack.indexOf(term) !== -1 ? '' : 'none';
                });
            });
        }

        document.querySelectorAll('.timeline-content-col').forEach(function (cardEl) {
            cardEl.addEventListener('click', function () {
                const itemId = cardEl.getAttribute('data-id');
                const target = history.find(function (entry) {
                    return entry.id === itemId;
                });
                if (!target) {
                    return;
                }

                const modalEl = document.getElementById('recognitionHistoryModal');
                const titleEl = document.getElementById('recognitionHistoryModalTitle');
                const bodyEl = document.getElementById('recognitionHistoryModalBody');
                if (!modalEl || !titleEl || !bodyEl || !(window.bootstrap && window.bootstrap.Modal)) {
                    return;
                }

                titleEl.textContent = target.award;
                bodyEl.innerHTML = [
                    '<p class="mb-1"><strong>Recipient:</strong> ' + target.name + '</p>',
                    '<p class="mb-1"><strong>Reference ID:</strong> ' + target.id + '</p>',
                    '<p class="mb-0"><strong>Date Awarded:</strong> ' + target.date + '</p>'
                ].join('');
                window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
            });
        });
    }

    window.HRSubmodules.renderRecognitionHistory = function (container) {
        ensureRecognitionHistoryModal();

        const history = getHistory();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-history text-info me-2"></i>Achievement Archive</h6>
                        <small class="text-muted">Historical log of all departmental and institutional awards</small>
                    </div>
                    <div class="search-box-sm">
                        <input type="text" class="form-control form-control-sm" placeholder="Search recipient..." id="historySearch">
                    </div>
                </div>

                ${history.length === 0 ? `
                    <div class="text-center p-5 bg-white border rounded-3">
                        <i class="fas fa-folder-open fa-3x text-light mb-3"></i>
                        <p class="text-muted">No historical records found.</p>
                    </div>
                ` : `
                    <div class="timeline-container">
                        ${history.map((item, index) => `
                            <div class="timeline-item d-flex mb-4">
                                <div class="timeline-date-col text-end pe-4 pt-1">
                                    <div class="fw-bold text-dark small">${item.date}</div>
                                    <div class="extra-small text-muted">Ref: ${item.id}</div>
                                </div>
                                <div class="timeline-marker-col position-relative px-3">
                                    <div class="timeline-line"></div>
                                    <div class="timeline-dot" style="background-color: ${item.color || '#0d6efd'}"></div>
                                </div>
                                <div class="timeline-content-col flex-grow-1 bg-white p-3 border rounded-3 shadow-sm" data-id="${item.id}" style="cursor: pointer;">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold text-primary mb-1">${item.award}</h6>
                                        <i class="fas fa-medal text-warning"></i>
                                    </div>
                                    <div class="text-dark fw-medium mb-1">${item.name}</div>
                                    <p class="text-muted extra-small mb-0">Officially recorded in the Institutional Merit Registry.</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
            </div>
        `;

        attachRecognitionHistoryInteractions(history);
    };

})();

