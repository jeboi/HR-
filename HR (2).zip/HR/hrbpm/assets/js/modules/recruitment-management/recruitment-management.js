/* Consolidated recruitment-management module scripts */

/* Source: submodules/candidate-shortlisting.js */
/**
 * Candidate Shortlisting Submodule
 * Professional Evaluation & Selection UI
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hrCandidates'; // Connecting to existing candidate pool

    // Internal Helper: Get candidates that are in 'New' or 'Shortlisted' status
    const getCandidates = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [
            { id: "APP-101", name: "John Doe", role: "Critical Care Nurse", score: 85, stage: "New" },
            { id: "APP-102", name: "Jane Smith", role: "Radiology Tech", score: 92, stage: "Shortlisted" },
            { id: "APP-103", name: "Robert Ross", role: "Medical Admin", score: 78, stage: "New" }
        ];
    };

    function ensureShortlistModalHost() {
        if (document.getElementById('shortlistActionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="shortlistActionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="shortlistActionModalTitle">Shortlist Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="shortlistActionModalBody"></div>',
            '      <div class="modal-footer" id="shortlistActionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openShortlistConfirmModal(candidate, newStage, onConfirm) {
        const modalEl = document.getElementById('shortlistActionModal');
        const titleEl = document.getElementById('shortlistActionModalTitle');
        const bodyEl = document.getElementById('shortlistActionModalBody');
        const footerEl = document.getElementById('shortlistActionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        const isShortlisting = newStage === 'Shortlisted';
        titleEl.textContent = isShortlisting ? 'Confirm Shortlist' : 'Remove From Shortlist';
        bodyEl.innerHTML = '<p class="mb-0">' +
            (isShortlisting
                ? 'Add <strong>' + candidate.name + '</strong> to shortlisted candidates?'
                : 'Move <strong>' + candidate.name + '</strong> back to the new pool?') +
            '</p>';

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn ' + (isShortlisting ? 'btn-primary' : 'btn-warning') + '" id="shortlistActionConfirmBtn">Confirm</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const confirmBtn = document.getElementById('shortlistActionConfirmBtn');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                onConfirm();
                modal.hide();
            });
        }

        modal.show();
    }

    window.HRSubmodules.renderCandidateShortlisting = function (container) {
        ensureShortlistModalHost();

        const candidates = getCandidates();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-text">
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-check text-primary me-2"></i>Shortlist Management</h6>
                        <small class="text-muted">Evaluate and promote top-tier medical talent</small>
                    </div>
                    <div class="header-stats d-flex gap-3">
                        <div class="text-end border-end pe-3">
                            <div class="fw-bold text-primary small">${candidates.length}</div>
                            <div class="text-muted" style="font-size: 10px;">TOTAL POOL</div>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold text-success small">${candidates.filter(c => c.stage === 'Shortlisted').length}</div>
                            <div class="text-muted" style="font-size: 10px;">SHORTLISTED</div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 shortlist-table">
                        <thead>
                            <tr>
                                <th class="ps-4">Candidate Profile</th>
                                <th>Match Score</th>
                                <th>Current Status</th>
                                <th class="text-end pe-4">Selection</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${candidates.map(can => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate" style="max-width: 250px;">${can.name}</div>
                                        <div class="text-muted small">${can.role}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress flex-grow-1" style="height: 6px; max-width: 100px;">
                                                <div class="progress-bar bg-primary" style="width: ${can.score}%"></div>
                                            </div>
                                            <span class="fw-bold small">${can.score}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge-custom ${can.stage.toLowerCase()}">${can.stage}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            ${can.stage !== 'Shortlisted' ? `
                                                <button class="btn btn-sm btn-outline-primary px-3 rounded-pill" onclick="window.HRSubmodules.updateShortlistStatus('${can.id}', 'Shortlisted')">
                                                    Shortlist
                                                </button>
                                            ` : `
                                                <button class="btn btn-sm btn-success px-3 rounded-pill" onclick="window.HRSubmodules.updateShortlistStatus('${can.id}', 'New')">
                                                    <i class="fas fa-check me-1"></i> Added
                                                </button>
                                            `}
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateShortlistStatus = function(id, newStage) {
        let candidates = getCandidates();
        const index = candidates.findIndex(c => c.id === id);
        if (index !== -1) {
            const target = candidates[index];

            openShortlistConfirmModal(target, newStage, function () {
                candidates[index].stage = newStage;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(candidates));

                // Broadcast for real-time dashboard updates
                window.dispatchEvent(new Event('storage'));

                // Refresh view
                window.HRSubmodules.renderCandidateShortlisting(document.getElementById('roleModuleOverviewBody'));
            });
        }
    };
})();

/* Source: submodules/hiring-approval.js */
/**
 * Hiring Approval Submodule with Audit History & Applicant Integration
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const QUEUE_KEY = 'hospitalHrHiringApprovals';
    const HISTORY_KEY = 'hospitalHrApprovalHistory';
    const CANDIDATES_KEY = 'hrCandidates'; // Link to your applicant list

    const getStorageData = (key, defaults) => {
        const stored = localStorage.getItem(key);
        return stored ? JSON.parse(stored) : defaults;
    };

    function ensureHiringDecisionModal() {
        if (document.getElementById('hiringDecisionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="hiringDecisionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="hiringDecisionModalTitle">Confirm Decision</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="hiringDecisionModalBody"></div>',
            '      <div class="modal-footer" id="hiringDecisionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openHiringDecisionModal(target, outcome, onConfirm) {
        const modalEl = document.getElementById('hiringDecisionModal');
        const titleEl = document.getElementById('hiringDecisionModalTitle');
        const bodyEl = document.getElementById('hiringDecisionModalBody');
        const footerEl = document.getElementById('hiringDecisionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        const approving = outcome === 'Approved';
        titleEl.textContent = approving ? 'Approve Candidate' : 'Reject Candidate';
        bodyEl.innerHTML = '<p class="mb-0">' +
            (approving
                ? 'Approve <strong>' + target.name + '</strong> for final hiring?'
                : 'Reject <strong>' + target.name + '</strong> at final approval stage?') +
            '</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn ' + (approving ? 'btn-success' : 'btn-danger') + '" id="hiringDecisionConfirmBtn">Confirm</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const confirmBtn = document.getElementById('hiringDecisionConfirmBtn');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                onConfirm();
                modal.hide();
            });
        }

        modal.show();
    }

    window.HRSubmodules.renderHiringApproval = function (container) {
        ensureHiringDecisionModal();

        // Fetch candidates from the main applicant list who are ready for final sign-off
        const allCandidates = getStorageData(CANDIDATES_KEY, []);
        
        // Filter for candidates who are in 'Shortlisted' stage (Awaiting final approval)
        const applicantQueue = allCandidates.filter(c => c.stage === 'Shortlisted');
        
        // Combine with any manual approvals in the local queue
        const manualQueue = getStorageData(QUEUE_KEY, [
            { id: "APP-501", name: "Dr. Aris Thorne", role: "Chief Resident", dept: "Emergency" }
        ]);
        
        const combinedQueue = [...applicantQueue, ...manualQueue];
        const history = getStorageData(HISTORY_KEY, []);

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark">Hiring Decision Center</h6>
                        <small class="text-muted">Final authorization for applicants and requisitions</small>
                    </div>
                    <span class="badge bg-primary px-3">${combinedQueue.length} Ready for Review</span>
                </div>

                <div class="row g-3 mb-5">
                    ${combinedQueue.length > 0 ? combinedQueue.map(app => `
                        <div class="col-md-6">
                            <div class="approval-card p-3 border rounded-3 bg-white shadow-sm d-flex justify-content-between align-items-center">
                                <div class="text-truncate me-3">
                                    <div class="fw-bold text-dark text-truncate">${app.name}</div>
                                    <div class="text-primary extra-small">${app.role || app.position || 'Staff Position'}</div>
                                    <span class="badge bg-info-subtle text-info extra-small" style="font-size: 9px">Candidate Pool</span>
                                </div>
                                <div class="d-flex gap-2 shrink-0">
                                    <button class="btn btn-sm btn-success px-3" onclick="window.HRSubmodules.confirmApprovalDecision('${app.id}', 'Approved')">Approve</button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="window.HRSubmodules.confirmApprovalDecision('${app.id}', 'Rejected')">Deny</button>
                                </div>
                            </div>
                        </div>
                    `).join('') : '<div class="col-12 text-center text-muted p-4 border rounded-3 border-dashed">No applicants currently awaiting final approval.</div>'}
                </div>

                <hr class="my-4 opacity-25">

                <div class="history-section">
                    <h6 class="fw-bold mb-3"><i class="fas fa-history me-2 text-muted"></i>Decision History Log</h6>
                    <div class="table-responsive border rounded-3 bg-white shadow-sm">
                        <table class="table table-hover align-middle mb-0 history-table">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3" style="width: 40%">Candidate</th>
                                    <th style="width: 30%">Decision</th>
                                    <th class="text-end pe-3" style="width: 30%">Timestamp</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${history.length > 0 ? history.map(item => `
                                    <tr>
                                        <td class="ps-3">
                                            <div class="fw-bold small text-dark">${item.name}</div>
                                            <div class="text-muted" style="font-size: 10px;">${item.role || item.position}</div>
                                        </td>
                                        <td>
                                            <span class="badge ${item.outcome === 'Approved' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} border">
                                                ${item.outcome}
                                            </span>
                                        </td>
                                        <td class="text-end pe-3 text-muted small">${item.timestamp}</td>
                                    </tr>
                                `).join('') : '<tr><td colspan="3" class="text-center p-4 text-muted">No decisions logged yet.</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.confirmApprovalDecision = function(id, outcome) {
        const queue = getStorageData(QUEUE_KEY, []);
        const applicants = getStorageData(CANDIDATES_KEY, []);
        const target = queue.find(function (item) { return item.id === id; }) || applicants.find(function (item) { return item.id === id; });

        if (!target) {
            return;
        }

        openHiringDecisionModal(target, outcome, function () {
            window.HRSubmodules.processApproval(id, outcome);
        });
    };

    window.HRSubmodules.processApproval = function(id, outcome) {
        let queue = getStorageData(QUEUE_KEY, []);
        let applicants = getStorageData(CANDIDATES_KEY, []);
        let history = getStorageData(HISTORY_KEY, []);
        
        // Find if the target is in the manual queue OR the applicant list
        let target = queue.find(a => a.id === id) || applicants.find(a => a.id === id);
        
        if (target) {
            const decision = {
                id: target.id,
                name: target.name,
                role: target.role || target.position,
                outcome: outcome,
                timestamp: new Date().toLocaleString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' })
            };

            // 1. Add to history
            history.unshift(decision);

            // 2. Clean up manual queue
            queue = queue.filter(a => a.id !== id);

            // 3. Update Applicant List Status
            const appIdx = applicants.findIndex(a => a.id === id);
            if (appIdx !== -1) {
                applicants[appIdx].stage = (outcome === 'Approved') ? 'Hired' : 'Rejected';
            }

            // Save all updates
            localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
            localStorage.setItem(CANDIDATES_KEY, JSON.stringify(applicants));
            localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 10)));

            // 4. Global Stats Update (Dashboard Sync)
            if (outcome === 'Approved') {
                const count = parseInt(localStorage.getItem('hospitalHrHiredCount') || 0);
                localStorage.setItem('hospitalHrHiredCount', count + 1);
            }

            window.dispatchEvent(new Event('storage'));
            this.renderHiringApproval(document.getElementById('roleModuleOverviewBody'));
        }
    };

})();

/* Source: submodules/job-posting-management.js */
/**
 * Job Posting Management Submodule
 * Professional Vacancy Lifecycle Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    // Initial Data State - Mocking a Hospital Vacancy List
    let jobPostings = JSON.parse(localStorage.getItem('hospitalHrJobPostings')) || [
        { id: "JOB-2026-001", title: "Registered Nurse (ICU)", dept: "Nursing", type: "Full-time", apps: 12, status: "Active" },
        { id: "JOB-2026-002", title: "Medical Technologist", dept: "Laboratory", type: "Full-time", apps: 8, status: "Active" },
        { id: "JOB-2026-003", title: "HR Generalist", dept: "Human Resources", type: "Contract", apps: 25, status: "Closed" }
    ];

    function ensureJobModalHost() {
        if (document.getElementById('jobPostingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="jobPostingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="jobPostingModalTitle">Job Posting Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="jobPostingModalBody"></div>',
            '      <div class="modal-footer" id="jobPostingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openJobInfoModal(title, message) {
        const modalEl = document.getElementById('jobPostingModal');
        const titleEl = document.getElementById('jobPostingModalTitle');
        const bodyEl = document.getElementById('jobPostingModalBody');
        const footerEl = document.getElementById('jobPostingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderJobPostingManagement = function (container) {
        ensureJobModalHost();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="mb-0 fw-bold"><i class="fas fa-briefcase text-primary me-2"></i>Job Vacancy Manager</h6>
                        <small class="text-muted">Currently managing ${jobPostings.filter(j => j.status === 'Active').length} active listings</small>
                    </div>
                    <button class="btn btn-primary btn-sm shadow-sm px-3" onclick="window.HRSubmodules.openNewJobModal()">
                        <i class="fas fa-plus-circle me-2"></i>Post New Opening
                    </button>
                </div>

                <div class="row g-3" id="jobGridContainer">
                    ${jobPostings.map(job => `
                        <div class="col-md-6 col-lg-4">
                            <div class="job-card p-3 border rounded-3 bg-white shadow-sm position-relative ${job.status === 'Closed' ? 'opacity-75' : ''}">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge ${job.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'}">
                                        ${job.status}
                                    </span>
                                    <div class="dropdown">
                                        <button class="btn btn-link btn-sm text-muted p-0" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></button>
                                        <ul class="dropdown-menu shadow-sm border-0">
                                            <li><a class="dropdown-item small" href="#" onclick="window.HRSubmodules.toggleJobStatus('${job.id}')">Toggle Status</a></li>
                                            <li><a class="dropdown-item small text-danger" href="#" onclick="window.HRSubmodules.confirmDeleteJob('${job.id}')">Delete Post</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">${job.title}</h6>
                                <p class="text-muted extra-small mb-3"><i class="fas fa-hospital-alt me-1"></i>${job.dept} &bull; ${job.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <div class="text-center">
                                        <div class="fw-bold text-primary mb-0">${job.apps}</div>
                                        <div class="extra-small text-muted">Applicants</div>
                                    </div>
                                    <button class="btn btn-sm btn-light border px-3" style="font-size: 11px;" onclick="window.HRSubmodules.viewJobCandidates('${job.id}')">View Candidates</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.toggleJobStatus = function(id) {
        const job = jobPostings.find(j => j.id === id);
        if (job) {
            job.status = job.status === 'Active' ? 'Closed' : 'Active';
            this.syncJobData();
            this.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.syncJobData = function() {
        localStorage.setItem('hospitalHrJobPostings', JSON.stringify(jobPostings));
        // Update Dashboard Specific Key
        localStorage.setItem('hospitalHrActiveJobs', jobPostings.filter(j => j.status === 'Active').length);
        window.dispatchEvent(new Event('storage'));
    };

    window.HRSubmodules.openNewJobModal = function() {
        const modalEl = document.getElementById('jobPostingModal');
        const titleEl = document.getElementById('jobPostingModalTitle');
        const bodyEl = document.getElementById('jobPostingModalBody');
        const footerEl = document.getElementById('jobPostingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Post New Opening';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Job Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="jobNewTitle" placeholder="e.g. Nurse Supervisor">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Department</label>',
            '  <input type="text" class="form-control form-control-sm" id="jobNewDept" placeholder="e.g. Nursing">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Employment Type</label>',
            '  <select class="form-select form-select-sm" id="jobNewType">',
            '    <option>Full-time</option>',
            '    <option>Part-time</option>',
            '    <option>Contract</option>',
            '  </select>',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="jobCreateConfirm">Create Posting</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('jobCreateConfirm');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const jobTitle = (document.getElementById('jobNewTitle').value || '').trim();
                const jobDept = (document.getElementById('jobNewDept').value || '').trim() || 'General Medicine';
                const jobType = (document.getElementById('jobNewType').value || 'Full-time').trim();

                if (!jobTitle) {
                    return;
                }

                jobPostings.unshift({
                    id: 'JOB-' + Date.now().toString().slice(-6),
                    title: jobTitle,
                    dept: jobDept,
                    type: jobType,
                    apps: 0,
                    status: 'Active'
                });

                window.HRSubmodules.syncJobData();
                window.HRSubmodules.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.confirmDeleteJob = function (id) {
        const target = jobPostings.find(function (item) {
            return item.id === id;
        });
        if (!target) {
            return;
        }

        const modalEl = document.getElementById('jobPostingModal');
        const titleEl = document.getElementById('jobPostingModalTitle');
        const bodyEl = document.getElementById('jobPostingModalBody');
        const footerEl = document.getElementById('jobPostingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Delete Job Posting';
        bodyEl.innerHTML = '<p class="mb-0">Delete <strong>' + target.title + '</strong> (' + target.id + ')? This action cannot be undone.</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-danger" id="jobDeleteConfirm">Delete</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('jobDeleteConfirm');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                jobPostings = jobPostings.filter(function (item) {
                    return item.id !== id;
                });
                window.HRSubmodules.syncJobData();
                window.HRSubmodules.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewJobCandidates = function (id) {
        const target = jobPostings.find(function (item) {
            return item.id === id;
        });
        if (!target) {
            return;
        }

        openJobInfoModal('Candidate Snapshot', target.title + ' currently has ' + target.apps + ' applicants in the pipeline.');
    };

})();

/* Source: submodules/vacancy-requests.js */
/**
 * Vacancy Requests Submodule
 * Professional Staff Requisition Workflow
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrVacancyRequests';

    const getRequests = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        return [
            { id: "REQ-2026-001", position: "Senior Pharmacist", dept: "Pharmacy", urgency: "High", status: "Pending", date: "2026-03-04" },
            { id: "REQ-2026-002", position: "General Surgeon", dept: "Surgical", urgency: "Medium", status: "Approved", date: "2026-03-02" }
        ];
    };

    function ensureVacancyRequestModalHost() {
        if (document.getElementById('vacancyRequestModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="vacancyRequestModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="vacancyRequestModalTitle">Vacancy Request</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="vacancyRequestModalBody"></div>',
            '      <div class="modal-footer" id="vacancyRequestModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showVacancyRequestInfo(title, message) {
        const modalEl = document.getElementById('vacancyRequestModal');
        const titleEl = document.getElementById('vacancyRequestModalTitle');
        const bodyEl = document.getElementById('vacancyRequestModalBody');
        const footerEl = document.getElementById('vacancyRequestModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderVacancyRequests = function (container) {
        ensureVacancyRequestModalHost();

        const requests = getRequests();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3">
                    <div class="header-info">
                        <h6 class="fw-bold text-dark mb-0">Staff Requisitions</h6>
                        <p class="text-muted small mb-0">Review and manage departmental hiring requests</p>
                    </div>
                    <button class="btn btn-primary btn-sm px-4 shadow-sm" onclick="window.HRSubmodules.openRequestModal()">
                        <i class="fas fa-plus me-2"></i>New Request
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 custom-req-table">
                        <thead>
                            <tr>
                                <th class="ps-4" style="width: 15%">ID</th>
                                <th style="width: 35%">Position Details</th>
                                <th style="width: 20%">Urgency</th>
                                <th style="width: 15%">Status</th>
                                <th class="text-end pe-4" style="width: 15%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${requests.map(req => `
                                <tr>
                                    <td class="ps-4 font-monospace text-primary fw-bold small">${req.id}</td>
                                    <td>
                                        <div class="text-truncate fw-bold" title="${req.position}">${req.position}</div>
                                        <div class="text-muted small">${req.dept}</div>
                                    </td>
                                    <td>
                                        <span class="urgency-label ${req.urgency.toLowerCase()}">${req.urgency}</span>
                                    </td>
                                    <td>
                                        <span class="badge ${getStatusClass(req.status)}">${req.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-1">
                                            ${req.status === 'Pending' ? `
                                                <button class="btn btn-action btn-approve" onclick="window.HRSubmodules.updateRequestStatus('${req.id}', 'Approved')">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                                <button class="btn btn-action btn-reject" onclick="window.HRSubmodules.updateRequestStatus('${req.id}', 'Rejected')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            ` : `
                                                <span class="text-muted small fst-italic">Logged</span>
                                            `}
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    function getStatusClass(status) {
        if (status === 'Approved') return 'bg-success-subtle text-success border border-success-subtle';
        if (status === 'Rejected') return 'bg-danger-subtle text-danger border border-danger-subtle';
        return 'bg-warning-subtle text-warning border border-warning-subtle';
    }

    window.HRSubmodules.updateRequestStatus = function(id, newStatus) {
        let requests = getRequests();
        const idx = requests.findIndex(r => r.id === id);
        if (idx !== -1) {
            const positionName = requests[idx].position;
            requests[idx].status = newStatus;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
            window.dispatchEvent(new Event('storage'));
            this.renderVacancyRequests(document.getElementById('roleModuleOverviewBody'));
            showVacancyRequestInfo('Request Updated', positionName + ' has been marked as ' + newStatus + '.');
        }
    };

    window.HRSubmodules.openRequestModal = function() {
        const modalEl = document.getElementById('vacancyRequestModal');
        const titleEl = document.getElementById('vacancyRequestModalTitle');
        const bodyEl = document.getElementById('vacancyRequestModalBody');
        const footerEl = document.getElementById('vacancyRequestModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Create New Vacancy Request';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Position Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="vacReqPosition" placeholder="e.g. ICU Nurse">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Department</label>',
            '  <input type="text" class="form-control form-control-sm" id="vacReqDept" placeholder="e.g. Nursing">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Urgency</label>',
            '  <select class="form-select form-select-sm" id="vacReqUrgency">',
            '    <option>High</option>',
            '    <option selected>Medium</option>',
            '    <option>Low</option>',
            '  </select>',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="vacReqCreateBtn">Create Request</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('vacReqCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const pos = (document.getElementById('vacReqPosition').value || '').trim();
                const dep = (document.getElementById('vacReqDept').value || '').trim();
                const urgency = (document.getElementById('vacReqUrgency').value || 'Medium').trim();

                if (!pos || !dep) {
                    return;
                }

                let requests = getRequests();
                requests.unshift({
                    id: 'REQ-' + Date.now().toString().slice(-6),
                    position: pos,
                    dept: dep,
                    urgency: urgency,
                    status: 'Pending',
                    date: new Date().toLocaleDateString()
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderVacancyRequests(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showVacancyRequestInfo('Request Submitted', 'New vacancy request for ' + pos + ' has been logged.');
            });
        }

        modal.show();
    };
})();

