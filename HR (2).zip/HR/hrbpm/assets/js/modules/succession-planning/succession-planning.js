/* Consolidated succession-planning module scripts */

/* Source: submodules/position-planning.js */
/**
 * Position Planning Submodule
 * Professional Strategic Succession Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrPositionPlanning';

    const getPositions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Professional Position Data
        return [
            { id: "POS-101", title: "Chief Nursing Officer", department: "Nursing Admin", risk: "High", bench: 2, status: "Critical" },
            { id: "POS-102", title: "Head of Radiology", department: "Diagnostic", risk: "Medium", bench: 3, status: "Stable" },
            { id: "POS-103", title: "IT Infrastructure Director", department: "IT", risk: "High", bench: 1, status: "Vulnerable" }
        ];
    };

    function ensurePositionPlanningModalHost() {
        if (document.getElementById('positionPlanningModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="positionPlanningModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="positionPlanningModalTitle">Position Planning</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="positionPlanningModalBody"></div>',
            '      <div class="modal-footer" id="positionPlanningModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPositionPlanningInfo(title, message) {
        const modalEl = document.getElementById('positionPlanningModal');
        const titleEl = document.getElementById('positionPlanningModalTitle');
        const bodyEl = document.getElementById('positionPlanningModalBody');
        const footerEl = document.getElementById('positionPlanningModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderPositionPlanning = function (container) {
        ensurePositionPlanningModalHost();

        const positions = getPositions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-sitemap text-primary me-2"></i>Position & Bench Strength Planning</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Succession Strategy for Critical Roles</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.addNewPositionPlan()">
                        <i class="fas fa-plus-circle me-1"></i> Add Position Plan
                    </button>
                </div>

                <div class="row g-4">
                    ${positions.map(pos => `
                        <div class="col-xl-4 col-md-6">
                            <div class="position-card border rounded-4 bg-white shadow-sm h-100 overflow-hidden">
                                <div class="p-4">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h6 class="fw-bold text-dark mb-1">${pos.title}</h6>
                                            <span class="badge bg-light text-muted border extra-small">${pos.department}</span>
                                        </div>
                                        <span class="status-indicator ${pos.status.toLowerCase()}">${pos.status}</span>
                                    </div>
                                    
                                    <div class="planning-stats border-top pt-3 mt-3">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="text-muted extra-small text-uppercase fw-bold">Departure Risk</div>
                                                <div class="fw-bold ${pos.risk === 'High' ? 'text-danger' : 'text-warning'}">${pos.risk}</div>
                                            </div>
                                            <div class="col-6 border-start">
                                                <div class="text-muted extra-small text-uppercase fw-bold">Successors</div>
                                                <div class="fw-bold text-primary">${pos.bench} Ready</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4 d-grid gap-2">
                                        <button class="btn btn-outline-primary btn-sm" onclick="window.HRSubmodules.managePositionBench('${pos.id}')">
                                            <i class="fas fa-users-viewfinder me-1"></i> Manage Bench
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewPositionPlan = function() {
        const modalEl = document.getElementById('positionPlanningModal');
        const titleEl = document.getElementById('positionPlanningModalTitle');
        const bodyEl = document.getElementById('positionPlanningModalBody');
        const footerEl = document.getElementById('positionPlanningModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add Position Plan';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Position Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="positionPlanTitle" placeholder="e.g. Head of Radiology">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Department</label>',
            '  <input type="text" class="form-control form-control-sm" id="positionPlanDepartment" placeholder="e.g. Diagnostic">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Risk Level</label>',
            '  <select class="form-select form-select-sm" id="positionPlanRisk">',
            '    <option value="Medium">Medium</option>',
            '    <option value="High">High</option>',
            '    <option value="Low">Low</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="savePositionPlanBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('savePositionPlanBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const title = (document.getElementById('positionPlanTitle').value || '').trim();
                const dept = (document.getElementById('positionPlanDepartment').value || '').trim();
                const risk = (document.getElementById('positionPlanRisk').value || '').trim() || 'Medium';
                if (!title || !dept) {
                    return;
                }

                let positions = getPositions();
                positions.unshift({
                    id: 'POS-' + Math.floor(100 + Math.random() * 900),
                    title: title,
                    department: dept,
                    risk: risk,
                    bench: 0,
                    status: 'Review Required'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(positions));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderPositionPlanning(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showPositionPlanningInfo('Plan Added', title + ' was added to succession position planning.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.managePositionBench = function (positionId) {
        const positions = getPositions();
        const target = positions.find(function (pos) { return pos.id === positionId; });
        if (!target) {
            return;
        }

        showPositionPlanningInfo('Manage Bench', 'Potential successors for ' + target.title + ' (' + target.department + ') are ready to review.');
    };
})();

/* Source: submodules/readiness-assessment.js */
// Ensure this is accessible to the renderInlineSubmoduleContent function in main.js
window.HRSubmodules = window.HRSubmodules || {};

function ensureReadinessAssessmentModalHost() {
    if (document.getElementById('readinessAssessmentModal')) {
        return;
    }

    const modalHost = document.createElement('div');
    modalHost.innerHTML = [
        '<div class="modal fade" id="readinessAssessmentModal" tabindex="-1" aria-hidden="true">',
        '  <div class="modal-dialog modal-dialog-centered">',
        '    <div class="modal-content">',
        '      <div class="modal-header">',
        '        <h5 class="modal-title" id="readinessAssessmentModalTitle">Readiness Assessment</h5>',
        '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
        '      </div>',
        '      <div class="modal-body" id="readinessAssessmentModalBody"></div>',
        '      <div class="modal-footer" id="readinessAssessmentModalFooter"></div>',
        '    </div>',
        '  </div>',
        '</div>'
    ].join('');

    document.body.appendChild(modalHost.firstElementChild);
}

function showReadinessAssessmentInfo(title, message) {
    const modalEl = document.getElementById('readinessAssessmentModal');
    const titleEl = document.getElementById('readinessAssessmentModalTitle');
    const bodyEl = document.getElementById('readinessAssessmentModalBody');
    const footerEl = document.getElementById('readinessAssessmentModalFooter');
    if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
        return;
    }

    titleEl.textContent = title;
    bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
    footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
    window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
}

window.HRSubmodules.renderReadinessAssessment = function (container) {
    ensureReadinessAssessmentModalHost();

    const questions = [
        { id: 1, text: "Candidate demonstrates core technical competency for the target role.", category: "Technical" },
        { id: 2, text: "Candidate has completed all required leadership training modules.", category: "Training" },
        { id: 3, text: "Performance reviews consistently meet or exceed 'Exceeds Expectations'.", category: "Performance" },
        { id: 4, text: "Candidate has successfully mentored at least two junior staff members.", category: "Leadership" }
    ];

    container.innerHTML = `
        <div class="card border-0 shadow-sm animate-fade-in">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h5 class="mb-1">Succession Readiness Tool</h5>
                        <p class="text-muted small mb-0">Evaluate internal candidates for critical position transition.</p>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-primary px-3 py-2" id="live-score">Readiness: 0%</span>
                    </div>
                </div>

                <form id="assessment-form">
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-uppercase">Select Candidate</label>
                        <select class="form-select border-light-subtle" id="candidate-select" required>
                            <option value="">Choose an employee...</option>
                            <option value="EMP-2024-001">John Doe (Senior Surgeon)</option>
                            <option value="EMP-2024-012">Jane Smith (Head Nurse)</option>
                        </select>
                    </div>

                    <div class="assessment-questions">
                        ${questions.map(q => `
                            <div class="question-row p-3 mb-2 rounded border border-light-subtle bg-white">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <span class="badge bg-light text-dark extra-small mb-1">${q.category}</span>
                                        <p class="mb-0 small fw-medium">${q.text}</p>
                                    </div>
                                    <div class="col-md-4 text-md-end mt-2 mt-md-0">
                                        <div class="btn-group btn-group-sm" role="group">
                                            <input type="radio" class="btn-check" name="q${q.id}" id="q${q.id}y" value="25" autocomplete="off">
                                            <label class="btn btn-outline-success" for="q${q.id}y">Met</label>
                                            
                                            <input type="radio" class="btn-check" name="q${q.id}" id="q${q.id}n" value="0" autocomplete="off" checked>
                                            <label class="btn btn-outline-secondary" for="q${q.id}n">Not Met</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>

                    <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-light btn-sm text-muted" id="reset-assessment">Reset</button>
                        <button type="submit" class="btn btn-primary px-4">Submit Assessment</button>
                    </div>
                </form>
            </div>
        </div>
    `;

    // Real-time score calculation as they click
    const form = document.getElementById('assessment-form');
    form.addEventListener('change', () => {
        const data = new FormData(form);
        let score = 0;
        for (let value of data.values()) { score += parseInt(value); }
        document.getElementById('live-score').innerText = `Readiness: ${score}%`;
    });

    // Save to LocalStorage to trigger main.js updateDashboardFromModuleData()
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const candidate = document.getElementById('candidate-select').value;
        const data = new FormData(form);
        let score = 0;
        for (let value of data.values()) { score += parseInt(value); }

        const readinessEntries = JSON.parse(localStorage.getItem('hospitalHrReadiness') || '[]');
        readinessEntries.push({
            id: Date.now(),
            candidate: candidate,
            score: score,
            status: score >= 75 ? 'Ready' : 'Developing',
            date: new Date().toLocaleDateString()
        });

        localStorage.setItem('hospitalHrReadiness', JSON.stringify(readinessEntries));
        showReadinessAssessmentInfo('Assessment Synced', 'Dashboard metrics were updated successfully.');
        renderInlineSubmoduleContent('Readiness Assessment'); // Refresh view
    });
};

/* Source: submodules/successor-identification.js */
/**
 * Successor Identification Submodule
 * Professional Talent Bench & Readiness Mapping
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrSuccessors';

    const getSuccessors = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Talent Bench Data
        return [
            { id: "TAL-01", name: "Dr. Sarah Chen", targetRole: "Chief Nursing Officer", readiness: "Ready Now", potential: "High", performance: "Exceeding" },
            { id: "TAL-02", name: "Robert Miller", targetRole: "IT Infrastructure Director", readiness: "1-2 Years", potential: "Medium", performance: "Consistent" },
            { id: "TAL-03", name: "Nurse Elena Rodriguez", targetRole: "Nursing Admin Manager", readiness: "Ready Now", potential: "High", performance: "Exceeding" }
        ];
    };

    function ensureSuccessorModalHost() {
        if (document.getElementById('successorIdentificationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="successorIdentificationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="successorIdentificationModalTitle">Successor Identification</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="successorIdentificationModalBody"></div>',
            '      <div class="modal-footer" id="successorIdentificationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showSuccessorInfo(title, message) {
        const modalEl = document.getElementById('successorIdentificationModal');
        const titleEl = document.getElementById('successorIdentificationModalTitle');
        const bodyEl = document.getElementById('successorIdentificationModalBody');
        const footerEl = document.getElementById('successorIdentificationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderSuccessorIdentification = function (container) {
        ensureSuccessorModalHost();

        const successors = getSuccessors();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-graduate text-success me-2"></i>Talent Bench & Successor Pool</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Identifying Future Leadership Capacity</small>
                    </div>
                    <button class="btn btn-success btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.nominateSuccessor()">
                        <i class="fas fa-user-plus me-1"></i> Nominate Successor
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 custom-talent-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Candidate</th>
                                <th style="width: 25%">Target Role</th>
                                <th style="width: 15%">Readiness</th>
                                <th style="width: 15%">Potential</th>
                                <th class="text-end pe-4" style="width: 20%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${successors.map(person => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${person.name}</div>
                                        <div class="extra-small text-muted">Perf: ${person.performance}</div>
                                    </td>
                                    <td>
                                        <div class="small fw-semibold text-primary">${person.targetRole}</div>
                                    </td>
                                    <td>
                                        <span class="readiness-tag ${person.readiness.replace(/\s+/g, '-').toLowerCase()}">
                                            ${person.readiness}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="potential-bar flex-grow-1 me-2">
                                                <div class="potential-fill ${person.potential.toLowerCase()}" style="width: ${person.potential === 'High' ? '100%' : '60%'}"></div>
                                            </div>
                                            <span class="extra-small fw-bold">${person.potential}</span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="window.HRSubmodules.openDevelopmentPlan('${person.id}')">
                                            <i class="fas fa-chart-line"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.nominateSuccessor = function() {
        const modalEl = document.getElementById('successorIdentificationModal');
        const titleEl = document.getElementById('successorIdentificationModalTitle');
        const bodyEl = document.getElementById('successorIdentificationModalBody');
        const footerEl = document.getElementById('successorIdentificationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Nominate Successor';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Candidate Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="successorCandidateName" placeholder="e.g. Dr. Sarah Chen">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Target Future Role</label>',
            '  <input type="text" class="form-control form-control-sm" id="successorTargetRole" placeholder="e.g. Chief Nursing Officer">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Potential</label>',
            '  <select class="form-select form-select-sm" id="successorPotential">',
            '    <option value="High">High</option>',
            '    <option value="Medium">Medium</option>',
            '    <option value="TBD">TBD</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="saveSuccessorNominationBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('saveSuccessorNominationBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const name = (document.getElementById('successorCandidateName').value || '').trim();
                const role = (document.getElementById('successorTargetRole').value || '').trim();
                const potential = (document.getElementById('successorPotential').value || '').trim() || 'TBD';
                if (!name || !role) {
                    return;
                }

                let successors = getSuccessors();
                successors.unshift({
                    id: 'TAL-' + Math.floor(10 + Math.random() * 89),
                    name: name,
                    targetRole: role,
                    readiness: 'Emergency Only',
                    potential: potential,
                    performance: 'Under Review'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(successors));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderSuccessorIdentification(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showSuccessorInfo('Nomination Saved', name + ' was added to the successor pool.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.openDevelopmentPlan = function (successorId) {
        const successors = getSuccessors();
        const target = successors.find(function (person) { return person.id === successorId; });
        if (!target) {
            return;
        }

        showSuccessorInfo('Development Plan', 'Opening development plan for ' + target.name + ' toward ' + target.targetRole + '.');
    };
})();

