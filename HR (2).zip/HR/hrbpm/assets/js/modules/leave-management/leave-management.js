window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    'use strict';

    const LEAVE_REQUESTS_API = window.location.pathname.toLowerCase().indexOf('/modules/') !== -1
        ? '../php/leave-request-api.php'
        : 'php/leave-request-api.php';

    const WORKFLOW_KEY = 'hospitalHrLeaveWorkflow';
    const BALANCE_LEDGER_KEY = 'hospitalHrLeaveBalanceLedger';
    const RECENT_ACTIVITY_KEY = 'hospitalHrRecentActivities';
    const LOCAL_REQUESTS_KEY = 'hospitalHrLeaveRequestsLocal';

    function getInitialData() {
        return window.hrLeaveData || {
            stats: { pending: 0, approved: 0, rejected: 0, total_days: 0 },
            recentRequests: [],
            balances: []
        };
    }

    function safeJsonParse(raw, fallback) {
        if (!raw) {
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            return parsed && typeof parsed === 'object' ? parsed : fallback;
        } catch (_err) {
            return fallback;
        }
    }

    function normalizeLocalRequest(row) {
        const from = row.from || row.start_date || '';
        const to = row.to || row.end_date || '';
        const days = Number(row.days || calcDays(from, to) || 1);

        return {
            id: row.id || row.leave_code || ('LV-' + Date.now()),
            employee: row.employee || row.employee_name || 'Unknown Employee',
            type: row.type || row.leave_type || 'Vacation',
            from: from,
            to: to,
            reason: row.reason || row.leave_reason || '',
            days: days,
            status: row.status || row.leave_status || 'Pending'
        };
    }

    function getLocalRequests() {
        const raw = safeJsonParse(localStorage.getItem(LOCAL_REQUESTS_KEY), []);
        if (!Array.isArray(raw)) {
            return [];
        }

        return raw.map(normalizeLocalRequest);
    }

    function saveLocalRequests(items) {
        localStorage.setItem(LOCAL_REQUESTS_KEY, JSON.stringify(items || []));
    }

    function upsertLocalRequest(row) {
        const list = getLocalRequests();
        const normalized = normalizeLocalRequest(row);
        const key = normalizeId(normalized.id);
        const index = list.findIndex(function (item) {
            return normalizeId(item.id) === key;
        });

        if (index >= 0) {
            list[index] = Object.assign({}, list[index], normalized);
        } else {
            list.unshift(normalized);
        }

        saveLocalRequests(list);
        return normalized;
    }

    function updateLocalRequestStatus(id, status) {
        const list = getLocalRequests();
        const key = normalizeId(id);
        let updated = false;

        list.forEach(function (item) {
            if (normalizeId(item.id) === key) {
                item.status = status;
                updated = true;
            }
        });

        if (updated) {
            saveLocalRequests(list);
        }

        return updated;
    }

    function normalizeId(id) {
        return String(id || '').trim().toUpperCase();
    }

    function normalizeName(name) {
        return String(name || '').trim().toLowerCase();
    }

    function getWorkflowMap() {
        return safeJsonParse(localStorage.getItem(WORKFLOW_KEY), {});
    }

    function saveWorkflowMap(map) {
        localStorage.setItem(WORKFLOW_KEY, JSON.stringify(map || {}));
    }

    function setWorkflowState(leaveId, patch) {
        const key = normalizeId(leaveId);
        if (!key) {
            return;
        }

        const all = getWorkflowMap();
        const previous = all[key] || {};
        all[key] = Object.assign({}, previous, patch, {
            updatedAt: new Date().toISOString()
        });
        saveWorkflowMap(all);
    }

    function getWorkflowState(leaveRequest) {
        const all = getWorkflowMap();
        const key = normalizeId(leaveRequest && leaveRequest.id);
        const stored = key ? all[key] : null;

        if (stored && stored.stage) {
            // Backward compatibility for intermediate BPMN-only stage.
            if (stored.stage === 'APPROVED_UPDATED') {
                return {
                    stage: 'NOTIFIED_APPROVED',
                    stageLabel: 'Employee Notified (Approved)',
                    note: stored.note || ''
                };
            }
            return stored;
        }

        const status = String((leaveRequest && leaveRequest.status) || 'Pending').toLowerCase();
        if (status === 'approved') {
            return {
                stage: 'NOTIFIED_APPROVED',
                stageLabel: 'Employee Notified (Approved)'
            };
        }

        if (status === 'rejected') {
            return {
                stage: 'NOTIFIED_REJECTED',
                stageLabel: 'Employee Notified (Rejected)'
            };
        }

        return {
            stage: 'DEPT_REVIEW',
            stageLabel: 'Department Head Review'
        };
    }

    function getWorkflowBadge(stage) {
        const map = {
            DEPT_REVIEW: { cls: 'bg-warning-subtle text-warning', label: 'Department Review' },
            ENDORSED: { cls: 'bg-info-subtle text-info', label: 'Endorsed to HR' },
            HR_VALIDATION: { cls: 'bg-primary-subtle text-primary', label: 'HR Validation' },
            AUTO_REJECTED: { cls: 'bg-danger-subtle text-danger', label: 'Auto Rejected' },
            NOTIFIED_REJECTED: { cls: 'bg-danger-subtle text-danger', label: 'Notified (Rejected)' },
            APPROVED_UPDATED: { cls: 'bg-success-subtle text-success', label: 'Approved / Records Updated' },
            NOTIFIED_APPROVED: { cls: 'bg-success-subtle text-success', label: 'Notified (Approved)' }
        };

        return map[stage] || { cls: 'bg-secondary-subtle text-secondary', label: stage || 'Pending' };
    }

    function addRecentActivity(message, type) {
        const items = safeJsonParse(localStorage.getItem(RECENT_ACTIVITY_KEY), []);
        const next = Array.isArray(items) ? items : [];
        next.unshift({
            id: Date.now(),
            type: type || 'leave-workflow',
            message: message,
            at: new Date().toISOString(),
            status: 'new'
        });
        localStorage.setItem(RECENT_ACTIVITY_KEY, JSON.stringify(next.slice(0, 50)));
    }

    function getBalanceLedger() {
        const fromStorage = safeJsonParse(localStorage.getItem(BALANCE_LEDGER_KEY), null);
        if (fromStorage) {
            return fromStorage;
        }

        const data = getInitialData();
        const balances = Array.isArray(data.balances) ? data.balances : [];
        const seed = {};

        balances.forEach(function (row) {
            const key = normalizeName(row.employee_name || row.employee);
            if (!key) {
                return;
            }

            seed[key] = {
                employee: row.employee_name || row.employee,
                vacation: Number(row.vacation || 0),
                sick: Number(row.sick || 0),
                emergency: Number(row.emergency || 0)
            };
        });

        localStorage.setItem(BALANCE_LEDGER_KEY, JSON.stringify(seed));
        return seed;
    }

    function saveBalanceLedger(ledger) {
        localStorage.setItem(BALANCE_LEDGER_KEY, JSON.stringify(ledger || {}));
    }

    function mapLeaveTypeToBalanceKey(type) {
        const normalized = String(type || '').toLowerCase();
        if (normalized.indexOf('sick') !== -1) {
            return 'sick';
        }

        if (normalized.indexOf('emergency') !== -1) {
            return 'emergency';
        }

        return 'vacation';
    }

    function calcDays(fromValue, toValue) {
        if (!fromValue || !toValue) {
            return 0;
        }

        const fromDate = new Date(fromValue);
        const toDate = new Date(toValue);
        if (Number.isNaN(fromDate.getTime()) || Number.isNaN(toDate.getTime()) || toDate < fromDate) {
            return 0;
        }

        const msPerDay = 1000 * 60 * 60 * 24;
        return Math.floor((toDate - fromDate) / msPerDay) + 1;
    }

    function validatePolicy(leaveRequest) {
        const days = Number(leaveRequest.days || 0);
        if (!days || days < 1) {
            return { valid: false, reason: 'Invalid leave duration.' };
        }

        if (days > 30) {
            return { valid: false, reason: 'Request exceeds max policy limit (30 days).' };
        }

        if (!leaveRequest.type) {
            return { valid: false, reason: 'Leave type is required.' };
        }

        return { valid: true, reason: '' };
    }

    function validateBalance(leaveRequest, ledger) {
        const employeeKey = normalizeName(leaveRequest.employee);
        const bucket = mapLeaveTypeToBalanceKey(leaveRequest.type);
        let employeeLedger = ledger[employeeKey];

        if (!employeeLedger) {
            employeeLedger = {
                employee: leaveRequest.employee,
                vacation: 10,
                sick: 8,
                emergency: 3
            };
            ledger[employeeKey] = employeeLedger;
            saveBalanceLedger(ledger);
        }

        const available = Number(employeeLedger[bucket] || 0);
        const required = Number(leaveRequest.days || 0);

        if (required > available) {
            return { valid: false, reason: 'Insufficient leave balance (' + available + ' available).' };
        }

        return { valid: true, reason: '' };
    }

    function ensureModalHost(modalId, titleId, bodyId, footerId, defaultTitle) {
        if (document.getElementById(modalId)) {
            return;
        }

        const host = document.createElement('div');
        host.innerHTML = [
            '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="' + titleId + '">' + defaultTitle + '</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="' + bodyId + '"></div>',
            '      <div class="modal-footer" id="' + footerId + '"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(host.firstElementChild);
    }

    function showModal(modalId, titleId, bodyId, footerId, config) {
        const modalEl = document.getElementById(modalId);
        const titleEl = document.getElementById(titleId);
        const bodyEl = document.getElementById(bodyId);
        const footerEl = document.getElementById(footerId);
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    async function fetchRequestsFromDB() {
        try {
            const response = await fetch(LEAVE_REQUESTS_API);
            if (!response.ok) {
                throw new Error('Request failed (' + response.status + ')');
            }
            const result = await response.json();
            if (result && result.success && Array.isArray(result.data)) {
                const normalized = result.data.map(normalizeLocalRequest);
                saveLocalRequests(normalized);
                return normalized;
            }
            return getLocalRequests();
        } catch (error) {
            console.error('Leave API GET failed:', error);
            return getLocalRequests();
        }
    }

    async function saveRequestToDB(payload) {
        try {
            const response = await fetch(LEAVE_REQUESTS_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error('Request failed (' + response.status + ')');
            }

            const result = await response.json();
            if (!result || !result.success) {
                throw new Error((result && result.error) || 'Failed to create leave request.');
            }

            const normalized = normalizeLocalRequest(result.data || payload);
            upsertLocalRequest(normalized);
            return normalized;
        } catch (error) {
            const fallback = upsertLocalRequest({
                id: 'LV-' + Date.now(),
                employee: payload.employee,
                type: payload.type,
                from: payload.from,
                to: payload.to,
                reason: payload.reason,
                days: calcDays(payload.from, payload.to),
                status: 'Pending'
            });
            return fallback;
        }
    }

    async function updateRequestStatusInDB(id, status, approvedBy) {
        try {
            const response = await fetch(LEAVE_REQUESTS_API, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: id,
                    status: status,
                    approved_by: approvedBy || 'HR System'
                })
            });

            if (!response.ok) {
                throw new Error('Request failed (' + response.status + ')');
            }

            const result = await response.json();
            if (result && result.success) {
                updateLocalRequestStatus(id, status);
                return true;
            }
        } catch (_error) {
            // Fall back to local request updates when API is unavailable.
        }

        return updateLocalRequestStatus(id, status);
    }

    function getMergedRequestsWithWorkflow(requests) {
        return requests.map(function (item) {
            const wf = getWorkflowState(item);
            return Object.assign({}, item, {
                workflowStage: wf.stage,
                workflowLabel: wf.stageLabel || getWorkflowBadge(wf.stage).label,
                workflowNote: wf.note || ''
            });
        });
    }

    function renderKpiCard(title, value) {
        return '<div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">' + title + '</p><h5 class="mb-0">' + value + '</h5></div></div>';
    }

    registry.renderLeaveDashboard = async function (container) {
        const requests = getMergedRequestsWithWorkflow(await fetchRequestsFromDB());

        const deptQueue = requests.filter(function (r) { return r.workflowStage === 'DEPT_REVIEW'; }).length;
        const hrQueue = requests.filter(function (r) { return r.workflowStage === 'ENDORSED' || r.workflowStage === 'HR_VALIDATION'; }).length;
        const approved = requests.filter(function (r) { return String(r.status).toLowerCase() === 'approved'; }).length;
        const rejected = requests.filter(function (r) { return String(r.status).toLowerCase() === 'rejected'; }).length;

        const recentRows = requests.slice(0, 6).map(function (row) {
            const badge = getWorkflowBadge(row.workflowStage);
            return '<tr>'
                + '<td><code>' + row.id + '</code></td>'
                + '<td>' + row.employee + '</td>'
                + '<td>' + row.type + '</td>'
                + '<td>' + (row.days || 1) + '</td>'
                + '<td><span class="badge ' + badge.cls + '">' + badge.label + '</span></td>'
                + '</tr>';
        }).join('') || '<tr><td colspan="5" class="text-center text-muted py-4">No leave requests available</td></tr>';

        container.innerHTML = [
            '<div class="d-flex align-items-center gap-2 mb-3"><i class="fas fa-chart-line text-primary"></i><h6 class="mb-0">Leave Dashboard</h6></div>',
            '<div class="row g-3 mb-3 leave-dashboard-submodule">',
            renderKpiCard('Dept Review Queue', deptQueue),
            renderKpiCard('HR Validation Queue', hrQueue),
            renderKpiCard('Approved', approved),
            renderKpiCard('Rejected', rejected),
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-list-check text-primary me-2"></i>Workflow Snapshot</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>Days</th><th>Workflow Stage</th></tr></thead>',
            '      <tbody>' + recentRows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };

    registry.renderLeaveRequest = async function (container) {
        ensureModalHost('leaveRequestModal', 'leaveRequestModalTitle', 'leaveRequestModalBody', 'leaveRequestModalFooter', 'Leave Request');

        let requests = await fetchRequestsFromDB();

        async function render() {
            requests = await fetchRequestsFromDB();
            const merged = getMergedRequestsWithWorkflow(requests);
            const today = new Date().toISOString().split('T')[0];

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 leave-request-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-paper-plane text-primary me-2"></i>Submit Leave Request</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="lvEmp" class="form-control" placeholder="Employee Name"></div>',
                '      <div class="col-md-2"><select id="lvType" class="form-select"><option>Vacation</option><option>Sick</option><option>Emergency</option></select></div>',
                '      <div class="col-md-2"><input id="lvFrom" type="date" class="form-control" min="' + today + '"></div>',
                '      <div class="col-md-2"><input id="lvTo" type="date" class="form-control" min="' + today + '"></div>',
                '      <div class="col-md-2"><input id="lvReason" class="form-control" placeholder="Reason"></div>',
                '      <div class="col-md-1"><button id="lvAddBtn" class="btn btn-primary w-100"><i class="fas fa-plus"></i></button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-inbox text-primary me-2"></i>Submitted Requests</h5>',
                '    <button id="refreshLeaveReqBtn" class="btn btn-sm btn-outline-primary"><i class="fas fa-sync-alt"></i></button>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>Days</th><th>Workflow</th></tr></thead>',
                '      <tbody>',
                merged.length ? merged.map(function (item) {
                    const badge = getWorkflowBadge(item.workflowStage);
                    return '<tr>'
                        + '<td><code>' + item.id + '</code></td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.type + '</td>'
                        + '<td>' + (item.days || 1) + '</td>'
                        + '<td><span class="badge ' + badge.cls + '">' + badge.label + '</span></td>'
                        + '</tr>';
                }).join('') : '<tr><td colspan="5" class="text-center text-muted py-4">No requests yet</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addBtn = document.getElementById('lvAddBtn');
            const refreshBtn = document.getElementById('refreshLeaveReqBtn');
            const fromInput = document.getElementById('lvFrom');
            const toInput = document.getElementById('lvTo');

            if (fromInput && toInput) {
                fromInput.addEventListener('change', function () {
                    toInput.min = this.value;
                    if (toInput.value && toInput.value < this.value) {
                        toInput.value = this.value;
                    }
                });
            }

            if (refreshBtn) {
                refreshBtn.addEventListener('click', function () {
                    render();
                });
            }

            if (!addBtn) {
                return;
            }

            addBtn.addEventListener('click', async function () {
                const payload = {
                    employee: (document.getElementById('lvEmp').value || '').trim(),
                    type: document.getElementById('lvType').value,
                    from: document.getElementById('lvFrom').value,
                    to: document.getElementById('lvTo').value,
                    reason: (document.getElementById('lvReason').value || '').trim()
                };

                const missingFields = [];
                if (!payload.employee) {
                    missingFields.push('Employee Name');
                }
                if (!payload.from) {
                    missingFields.push('Start Date');
                }
                if (!payload.to) {
                    missingFields.push('End Date');
                }
                if (!payload.reason) {
                    missingFields.push('Reason');
                }

                if (missingFields.length) {
                    showModal('leaveRequestModal', 'leaveRequestModalTitle', 'leaveRequestModalBody', 'leaveRequestModalFooter', {
                        title: 'Missing Required Fields',
                        message: 'Please complete: ' + missingFields.join(', ') + '.'
                    });
                    return;
                }

                const days = calcDays(payload.from, payload.to);
                if (!days) {
                    showModal('leaveRequestModal', 'leaveRequestModalTitle', 'leaveRequestModalBody', 'leaveRequestModalFooter', {
                        title: 'Invalid Date Range',
                        message: 'End Date must be the same as or later than Start Date.'
                    });
                    return;
                }

                addBtn.disabled = true;
                addBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                try {
                    const saved = await saveRequestToDB(payload);

                    setWorkflowState(saved.id, {
                        stage: 'DEPT_REVIEW',
                        stageLabel: 'Department Head Review',
                        lane: 'Department Head',
                        note: 'Submitted by employee and queued for department review.'
                    });

                    addRecentActivity('Leave request ' + saved.id + ' submitted by ' + saved.employee + ' and sent to department head.', 'leave-submitted');
                    await render();

                    showModal('leaveRequestModal', 'leaveRequestModalTitle', 'leaveRequestModalBody', 'leaveRequestModalFooter', {
                        title: 'Submitted',
                        message: 'Request ' + saved.id + ' is waiting for Department Head review.'
                    });
                } catch (error) {
                    showModal('leaveRequestModal', 'leaveRequestModalTitle', 'leaveRequestModalBody', 'leaveRequestModalFooter', {
                        title: 'Submission Failed',
                        message: error.message || 'Could not submit leave request.'
                    });
                } finally {
                    addBtn.disabled = false;
                    addBtn.innerHTML = '<i class="fas fa-plus"></i>';
                }
            });
        }

        await render();
    };

    registry.renderLeaveApproval = async function (container) {
        ensureModalHost('leaveApprovalModal', 'leaveApprovalModalTitle', 'leaveApprovalModalBody', 'leaveApprovalModalFooter', 'Leave Approval');

        async function render() {
            const requests = getMergedRequestsWithWorkflow(await fetchRequestsFromDB());
            const approvalQueue = requests.filter(function (item) {
                return String(item.status).toLowerCase() === 'pending';
            });

            container.innerHTML = [
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h6 class="mb-0"><i class="fas fa-user-check text-primary me-2"></i>Leave Approval</h6></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle leave-approval-submodule">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Action</th></tr></thead>',
                '      <tbody>',
                approvalQueue.length ? approvalQueue.map(function (item) {
                    return '<tr>'
                        + '<td><code>' + item.id + '</code></td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.type + '</td>'
                        + '<td>' + (item.from || '-') + '</td>'
                        + '<td>' + (item.to || '-') + '</td>'
                        + '<td>' + (item.days || 1) + '</td>'
                        + '<td>' + (item.reason || '-') + '</td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join('') : '<tr><td colspan="8" class="text-center text-muted py-3">No pending leave requests for approval</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (btn) {
                btn.addEventListener('click', async function () {
                    const action = btn.getAttribute('data-action');
                    const id = btn.getAttribute('data-id');
                    const item = requests.find(function (row) { return normalizeId(row.id) === normalizeId(id); });
                    if (!item) {
                        return;
                    }

                    const originalHtml = btn.innerHTML;
                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                    try {
                        if (action === 'approve') {
                            setWorkflowState(item.id, {
                                stage: 'HR_VALIDATION',
                                stageLabel: 'Approval Validation',
                                lane: 'HR System',
                                note: 'Validating leave policy and available balance before final approval.'
                            });

                            const ledger = getBalanceLedger();
                            const policy = validatePolicy(item);
                            const balance = validateBalance(item, ledger);

                            if (!policy.valid || !balance.valid) {
                                const reason = !policy.valid ? policy.reason : balance.reason;
                                const okReject = await updateRequestStatusInDB(item.id, 'Rejected', 'HR System');
                                if (okReject) {
                                    setWorkflowState(item.id, {
                                        stage: 'NOTIFIED_REJECTED',
                                        stageLabel: 'Rejected',
                                        lane: 'HR System',
                                        note: 'Rejected during approval validation: ' + reason
                                    });
                                    addRecentActivity('Leave request ' + item.id + ' was rejected: ' + reason, 'leave-rejected');
                                    await render();
                                } else {
                                    showModal('leaveApprovalModal', 'leaveApprovalModalTitle', 'leaveApprovalModalBody', 'leaveApprovalModalFooter', {
                                        title: 'Approval Failed',
                                        message: 'Could not reject request ' + item.id + '. Please try again.'
                                    });
                                }
                                return;
                            }

                            const okApprove = await updateRequestStatusInDB(item.id, 'Approved', 'HR System');
                            if (okApprove) {
                                const employeeKey = normalizeName(item.employee);
                                const leaveBucket = mapLeaveTypeToBalanceKey(item.type);
                                const current = ledger[employeeKey] || {
                                    employee: item.employee,
                                    vacation: 0,
                                    sick: 0,
                                    emergency: 0
                                };

                                current[leaveBucket] = Math.max(0, Number(current[leaveBucket] || 0) - Number(item.days || 0));
                                ledger[employeeKey] = current;
                                saveBalanceLedger(ledger);

                                setWorkflowState(item.id, {
                                    stage: 'NOTIFIED_APPROVED',
                                    stageLabel: 'Approved',
                                    lane: 'HR System',
                                    note: 'Approved by HR and leave records updated.'
                                });
                                addRecentActivity('Leave request ' + item.id + ' approved by HR.', 'leave-approved');
                                await render();
                            } else {
                                showModal('leaveApprovalModal', 'leaveApprovalModalTitle', 'leaveApprovalModalBody', 'leaveApprovalModalFooter', {
                                    title: 'Approval Failed',
                                    message: 'Could not approve request ' + item.id + '. Please try again.'
                                });
                            }
                            return;
                        }

                        if (action === 'reject') {
                            const okReject = await updateRequestStatusInDB(item.id, 'Rejected', 'HR System');
                            if (okReject) {
                                setWorkflowState(item.id, {
                                    stage: 'NOTIFIED_REJECTED',
                                    stageLabel: 'Rejected',
                                    lane: 'HR System',
                                    note: 'Rejected by HR during leave approval.'
                                });
                                addRecentActivity('Leave request ' + item.id + ' rejected by HR.', 'leave-rejected');
                                await render();
                            } else {
                                showModal('leaveApprovalModal', 'leaveApprovalModalTitle', 'leaveApprovalModalBody', 'leaveApprovalModalFooter', {
                                    title: 'Rejection Failed',
                                    message: 'Could not reject request ' + item.id + '. Please try again.'
                                });
                            }
                        }
                    } catch (error) {
                        showModal('leaveApprovalModal', 'leaveApprovalModalTitle', 'leaveApprovalModalBody', 'leaveApprovalModalFooter', {
                            title: 'Action Failed',
                            message: (error && error.message) ? error.message : 'An unexpected error occurred while processing this request.'
                        });
                    } finally {
                        btn.disabled = false;
                        btn.innerHTML = originalHtml;
                    }
                });
            });
        }

        await render();
    };

    registry.renderLeaveBalance = function (container) {
        const ledger = getBalanceLedger();
        const rows = Object.keys(ledger).map(function (key) {
            return ledger[key];
        });

        const totalVacation = rows.reduce(function (sum, row) { return sum + Number(row.vacation || 0); }, 0);
        const totalSick = rows.reduce(function (sum, row) { return sum + Number(row.sick || 0); }, 0);
        const totalEmergency = rows.reduce(function (sum, row) { return sum + Number(row.emergency || 0); }, 0);

        const bodyRows = rows.map(function (row) {
            return '<tr><td>' + (row.employee || 'Unknown') + '</td><td>' + Number(row.vacation || 0) + '</td><td>' + Number(row.sick || 0) + '</td><td>' + Number(row.emergency || 0) + '</td></tr>';
        }).join('') || '<tr><td colspan="4" class="text-center text-muted py-3">No leave balance data available</td></tr>';

        container.innerHTML = [
            '<div class="d-flex align-items-center gap-2 mb-3"><i class="fas fa-wallet text-primary"></i><h6 class="mb-0">Leave Balance (After Workflow Updates)</h6></div>',
            '<div class="row g-3 mb-3 leave-balance-submodule">',
            renderKpiCard('Total Vacation', totalVacation),
            renderKpiCard('Total Sick', totalSick),
            renderKpiCard('Total Emergency', totalEmergency),
            renderKpiCard('Employees in Ledger', rows.length),
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-table-list text-primary me-2"></i>Balance Ledger</h5></div>',
            '  <div class="table-responsive"><table class="table mb-0 align-middle"><thead><tr><th>Employee</th><th>Vacation</th><th>Sick</th><th>Emergency</th></tr></thead><tbody>' + bodyRows + '</tbody></table></div>',
            '</div>'
        ].join('');
    };

    registry.renderLeavePolicy = function (container) {
        container.innerHTML = [
            '<div class="d-flex align-items-center gap-2 mb-3"><i class="fas fa-book-open text-primary"></i><h6 class="mb-0">Leave Policy and Guidelines</h6></div>',
            '<div class="row g-3">',
            '  <div class="col-lg-7">',
            '    <div class="card border-0 shadow-sm h-100">',
            '      <div class="card-header bg-white"><h5 class="mb-0">Policy Matrix</h5></div>',
            '      <div class="table-responsive">',
            '        <table class="table mb-0 align-middle">',
            '          <thead><tr><th>Leave Type</th><th>Default Credits</th><th>Lead Time</th><th>Required Attachment</th></tr></thead>',
            '          <tbody>',
            '            <tr><td>Vacation</td><td>10 days</td><td>At least 3 days before start date</td><td>None</td></tr>',
            '            <tr><td>Sick</td><td>8 days</td><td>Same day submission allowed</td><td>Medical certificate if 2+ days</td></tr>',
            '            <tr><td>Emergency</td><td>3 days</td><td>Immediate filing allowed</td><td>Incident or supporting note if requested</td></tr>',
            '          </tbody>',
            '        </table>',
            '      </div>',
            '    </div>',
            '  </div>',
            '  <div class="col-lg-5">',
            '    <div class="card border-0 shadow-sm mb-3">',
            '      <div class="card-body">',
            '        <h6 class="mb-2"><i class="fas fa-sitemap text-primary me-2"></i>Approval Flow</h6>',
            '        <ul class="mb-0 ps-3">',
            '          <li>Employee submits leave request.</li>',
            '          <li>Department Head reviews and endorses or rejects.</li>',
            '          <li>HR validates policy and leave balance.</li>',
            '          <li>System updates records and notifies employee.</li>',
            '        </ul>',
            '      </div>',
            '    </div>',
            '    <div class="card border-0 shadow-sm">',
            '      <div class="card-body">',
            '        <h6 class="mb-2"><i class="fas fa-circle-info text-primary me-2"></i>Rules to Remember</h6>',
            '        <ul class="mb-0 ps-3">',
            '          <li>Requests beyond available credits are automatically rejected.</li>',
            '          <li>Requests over 30 days fail policy validation.</li>',
            '          <li>Complete reason and valid date range are required before submission.</li>',
            '          <li>Approvals and rejections are logged in recent activity.</li>',
            '        </ul>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');
    };

    registry.renderLeaveReports = async function (container) {
        const requests = getMergedRequestsWithWorkflow(await fetchRequestsFromDB());
        const stageSummary = {};

        requests.forEach(function (item) {
            const label = getWorkflowBadge(item.workflowStage).label;
            stageSummary[label] = (stageSummary[label] || 0) + 1;
        });

        const stageRows = Object.keys(stageSummary).map(function (label) {
            return '<tr><td>' + label + '</td><td>' + stageSummary[label] + '</td></tr>';
        }).join('') || '<tr><td colspan="2" class="text-center text-muted">No report data available</td></tr>';

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 leave-reports-submodule">',
            '  <h6 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Leave Reports</h6>',
            '  <button id="leaveExportCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0">Request Count by Workflow Stage</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Workflow Stage</th><th>Count</th></tr></thead>',
            '      <tbody>' + stageRows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        const exportBtn = document.getElementById('leaveExportCsv');
        if (exportBtn) {
            exportBtn.addEventListener('click', function () {
                const lines = ['ID,Employee,Type,Days,DB Status,Workflow Stage,Workflow Note'];
                requests.forEach(function (item) {
                    lines.push([
                        item.id,
                        String(item.employee || '').replace(/,/g, ';'),
                        item.type,
                        item.days || 1,
                        item.status || 'Pending',
                        getWorkflowBadge(item.workflowStage).label,
                        String(item.workflowNote || '').replace(/,/g, ';')
                    ].join(','));
                });

                const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = 'leave-bpmn-report-' + new Date().toISOString().split('T')[0] + '.csv';
                link.click();
                URL.revokeObjectURL(link.href);
            });
        }
    };
})(window.HRSubmodules);

(function () {
    'use strict';

    const container = document.getElementById('lmSubmoduleContainer');
    const buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    const rendererMap = {
        'Leave Dashboard': 'renderLeaveDashboard',
        'Leave Request': 'renderLeaveRequest',
        'Leave Approval': 'renderLeaveApproval',
        'Leave Balance': 'renderLeaveBalance',
        'Leave Policy': 'renderLeavePolicy',
        'Leave Reports': 'renderLeaveReports'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(name) {
        if (!container) {
            return;
        }

        const rendererName = rendererMap[name];
        const renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            Promise.resolve(renderer(container)).catch(function (error) {
                console.error('Leave submodule render failed:', error);
                container.innerHTML = '<div class="alert alert-danger mb-0">Unable to load submodule.</div>';
            });
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer not available.</div>';
        }

        setActiveButton(name);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container) {
        renderSubmodule('Leave Dashboard');
    }
})();
