window.HRSubmodules = window.HRSubmodules || {};

(function () {
    'use strict';

    function resolveApplicantContainer() {
        return document.getElementById('roleModuleOverviewBody') || document.getElementById('applicantSubmoduleContainer');
    }

    // Persistent Storage Helper
    function getStoredApplicants() {
        const stored = localStorage.getItem('hospitalHrApplicants');
        if (stored) return JSON.parse(stored);
        
        const defaults = [
            { id: 'HR-2026-001', name: 'Clarice Starling', role: 'HR Generalist', status: 'New', date: 'Mar 01, 2026' },
            { id: 'HR-2026-002', name: 'Harvey Specter', role: 'Recruitment Lead', status: 'Interview', date: 'Feb 28, 2026' },
            { id: 'HR-2026-003', name: 'Donna Paulsen', role: 'Benefits Admin', status: 'Shortlisted', date: 'Feb 25, 2026' }
        ];
        localStorage.setItem('hospitalHrApplicants', JSON.stringify(defaults));
        return defaults;
    }

    // Enhanced Add Function for HR Department
window.HRSubmodules.addApplicant = function() {
    const name = prompt("Enter Full Name of Candidate:");
    const role = prompt("Enter Target Position (e.g., Staff Nurse, HR Analyst):");
    const email = prompt("Enter Contact Email:");
    
    if (name && role && email) {
        const applicants = getStoredApplicants();
        // Generate ID based on current year
        const newId = `HR-2026-${String(applicants.length + 1).padStart(3, '0')}`;
        
        applicants.unshift({
            id: newId,
            name: name,
            role: role,
            email: email,
            status: 'New',
            date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })
        });
        
        localStorage.setItem('hospitalHrApplicants', JSON.stringify(applicants));
        
        // Notify other components (like the Dashboard) to update metrics
        window.dispatchEvent(new Event('storage')); 
        
        // Refresh the current view
        const container = resolveApplicantContainer();
        this.renderApplicantList(container);
    }
};

// Remove Function for HR Administrative Use
window.HRSubmodules.removeApplicant = function(id) {
    // HR Confirmation Dialog to prevent accidental data loss
    if (confirm("CONFIRMATION: Are you sure you want to permanently delete this applicant record from the HR database?")) {
        let applicants = getStoredApplicants();
        
        // Filter out the selected ID
        applicants = applicants.filter(a => a.id !== id);
        
        // Update Persistent Storage
        localStorage.setItem('hospitalHrApplicants', JSON.stringify(applicants));
        
        // Trigger global sync for dashboard updates
        window.dispatchEvent(new Event('storage')); 
        
        // Re-render the list to reflect changes immediately
        const container = resolveApplicantContainer();
        this.renderApplicantList(container);
    }
};

    window.HRSubmodules.renderApplicantList = function (container) {
    if (!container) return;
    const hrApplicants = getStoredApplicants();

    container.innerHTML = `
        <div id="applicant-list-section" class="p-4 animate-fade-in">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0 text-dark">Applicant Management <small class="text-muted ms-2">(HR Admin View)</small></h5>
                <button class="btn btn-primary btn-sm px-3 shadow-sm" onclick="window.HRSubmodules.addApplicant()">
                    <i class="bi bi-person-plus-fill me-1"></i> Add New Record
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle" style="border-collapse: separate; border-spacing: 0 10px;">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3">Candidate Info</th>
                            <th>Target Role</th>
                            <th>Status</th>
                            <th class="text-end pe-3">Admin Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${hrApplicants.map(app => `
                            <tr>
                                <td class="ps-3">
                                    <div class="candidate-name-text">${app.name}</div>
                                    <div class="candidate-id-text">${app.id}</div>
                                </td>
                                <td><span class="fw-medium text-dark">${app.role}</span></td>
                                <td>
                                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1">
                                        ${app.status}
                                    </span>
                                </td>
                                <td class="text-end pe-3">
                                    <button class="btn btn-remove-record btn-sm" 
                                            onclick="window.HRSubmodules.removeApplicant('${app.id}')"
                                            title="Delete Record">
                                        <i class="bi bi-trash3-fill"></i> Remove
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
};

    // Initialization Logic
    function initApplicantStandalone() {
        const container = resolveApplicantContainer();
        const navButtons = document.querySelectorAll('[data-submodule]');
        if (!container || !navButtons.length) return;

        const renderMap = { 'Applicant List': 'renderApplicantList' };

        navButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                navButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const method = renderMap[btn.getAttribute('data-submodule')];
                if (window.HRSubmodules[method]) window.HRSubmodules[method](container);
            });
        });

        window.HRSubmodules.renderApplicantList(container);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApplicantStandalone);
    } else {
        initApplicantStandalone();
    }
})();

(function () {
    'use strict';
    function generateApplicantRows(data) {
        if (!data.length) {
            return '<tr><td colspan="6" class="text-center py-5 text-muted">No candidates match your criteria</td></tr>';
        }

        return data.map(function (applicant) {
            return [
                '<tr>',
                '  <td class="ps-4">',
                '    <div class="d-flex align-items-center">',
                '      <div class="applicant-init-avatar me-3">' + applicant.name.charAt(0) + '</div>',
                '      <div>',
                '        <div class="fw-semibold text-dark mb-0">' + applicant.name + '</div>',
                '        <div class="text-muted extra-small">' + applicant.email + '</div>',
                '      </div>',
                '    </div>',
                '  </td>',
                '  <td><span class="text-dark fw-medium">' + applicant.role + '</span></td>',
                '  <td><span class="text-muted small">' + applicant.exp + '</span></td>',
                '  <td class="text-muted small">' + applicant.date + '</td>',
                '  <td>' + getApplicantStatusBadge(applicant.status) + '</td>',
                '  <td class="text-end pe-4">',
                '    <button class="btn btn-icon-sm me-1" title="View Profile" data-action="view" data-id="' + applicant.id + '"><i class="fas fa-file-invoice text-primary"></i></button>',
                '    <button class="btn btn-icon-sm me-1" title="Schedule" data-action="schedule" data-id="' + applicant.id + '"><i class="fas fa-calendar-alt text-success"></i></button>',
                '    <button class="btn btn-icon-sm text-danger" title="Remove" data-action="remove" data-id="' + applicant.id + '"><i class="fas fa-trash"></i></button>',
                '  </td>',
                '</tr>'
            ].join('');
        }).join('');
    }

    function getApplicantStatusBadge(status) {
        const colors = {
            New: 'bg-info-subtle text-info',
            Interview: 'bg-warning-subtle text-warning',
            Shortlisted: 'bg-success-subtle text-success'
        };
        return '<span class="badge ' + (colors[status] || 'bg-light') + ' border-0 px-2 py-1">' + status + '</span>';
    }

    function ensureApplicantModalHost() {
        if (document.getElementById('hrApplicantModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="hrApplicantModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="hrApplicantModalTitle">Applicant Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="hrApplicantModalBody"></div>',
            '      <div class="modal-footer" id="hrApplicantModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function openAddApplicantModal(onCreate) {
        const titleEl = document.getElementById('hrApplicantModalTitle');
        const bodyEl = document.getElementById('hrApplicantModalBody');
        const footerEl = document.getElementById('hrApplicantModalFooter');
        const modalEl = document.getElementById('hrApplicantModal');
        if (!titleEl || !bodyEl || !footerEl || !modalEl) {
            return;
        }

        titleEl.textContent = 'Add External Hire';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Full Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="hrNewName" placeholder="e.g. Alex Rivera">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Position</label>',
            '  <input type="text" class="form-control form-control-sm" id="hrNewRole" placeholder="e.g. HR Analyst">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Email</label>',
            '  <input type="email" class="form-control form-control-sm" id="hrNewEmail" placeholder="name@hospital.com">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="hrAddApplicantConfirm">Add Applicant</button>'
        ].join('');

        const modal = window.bootstrap && window.bootstrap.Modal
            ? window.bootstrap.Modal.getOrCreateInstance(modalEl)
            : null;

        const confirmBtn = document.getElementById('hrAddApplicantConfirm');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                const name = (document.getElementById('hrNewName').value || '').trim();
                const role = (document.getElementById('hrNewRole').value || '').trim();
                const email = (document.getElementById('hrNewEmail').value || '').trim();

                if (!name || !role || !email) {
                    return;
                }

                onCreate({
                    id: 'HR-2026-' + String(Math.floor(100 + Math.random() * 900)),
                    name: name,
                    role: role,
                    date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
                    status: 'New',
                    email: email,
                    exp: '0 years'
                });

                if (modal) {
                    modal.hide();
                }
            });
        }

        if (modal) {
            modal.show();
        }
    }

    function openApplicantDetailsModal(applicant) {
        const titleEl = document.getElementById('hrApplicantModalTitle');
        const bodyEl = document.getElementById('hrApplicantModalBody');
        const footerEl = document.getElementById('hrApplicantModalFooter');
        const modalEl = document.getElementById('hrApplicantModal');
        if (!titleEl || !bodyEl || !footerEl || !modalEl) {
            return;
        }

        titleEl.textContent = 'Applicant Profile';
        bodyEl.innerHTML = [
            '<div class="small text-muted mb-2">ID: ' + applicant.id + '</div>',
            '<h6 class="mb-1">' + applicant.name + '</h6>',
            '<p class="mb-1"><strong>Role:</strong> ' + applicant.role + '</p>',
            '<p class="mb-1"><strong>Email:</strong> ' + applicant.email + '</p>',
            '<p class="mb-0"><strong>Status:</strong> ' + applicant.status + '</p>'
        ].join('');
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>';

        if (window.bootstrap && window.bootstrap.Modal) {
            window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
        }
    }

    function openApplicantScheduleModal(applicant) {
        const titleEl = document.getElementById('hrApplicantModalTitle');
        const bodyEl = document.getElementById('hrApplicantModalBody');
        const footerEl = document.getElementById('hrApplicantModalFooter');
        const modalEl = document.getElementById('hrApplicantModal');
        if (!titleEl || !bodyEl || !footerEl || !modalEl) {
            return;
        }

        titleEl.textContent = 'Schedule Interview';
        bodyEl.innerHTML = [
            '<p class="mb-2">Set interview for <strong>' + applicant.name + '</strong>.</p>',
            '<label class="form-label small mb-1">Date & Time</label>',
            '<input type="datetime-local" class="form-control form-control-sm" id="hrScheduleDate">'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="hrScheduleConfirm">Confirm</button>'
        ].join('');

        const modal = window.bootstrap && window.bootstrap.Modal
            ? window.bootstrap.Modal.getOrCreateInstance(modalEl)
            : null;

        const confirmBtn = document.getElementById('hrScheduleConfirm');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                const dateValue = document.getElementById('hrScheduleDate').value;
                if (!dateValue) {
                    return;
                }

                if (modal) {
                    modal.hide();
                }
            });
        }

        if (modal) {
            modal.show();
        }
    }

    const trackingData = [
        { id: 'APP-401', name: 'Dr. Aris Thorne', role: 'Chief Medical Officer', stage: 'Interview', date: '2026-03-01', priority: 'High' },
        { id: 'APP-402', name: 'Sarah Jenkins', role: 'HR Specialist', stage: 'Shortlisted', date: '2026-02-28', priority: 'Medium' },
        { id: 'APP-403', name: 'Mark Vales', role: 'Clinical Coordinator', stage: 'New', date: '2026-03-04', priority: 'Low' },
        { id: 'APP-404', name: 'Elena Rossi', role: 'HR Manager', stage: 'Offer', date: '2026-03-02', priority: 'High' }
    ];

    window.HRSubmodules.renderApplicationTracking = function (container) {
        ensureTrackingModalHost();

        container.innerHTML = [
            '<div class="submodule-content-wrapper animate-fade-in">',
            '  <div class="submodule-actionbar d-flex justify-content-between mb-3">',
            '    <div class="btn-group">',
            '      <button class="btn btn-sm btn-outline-primary active">All Candidates</button>',
            '      <button class="btn btn-sm btn-outline-primary">Pipeline View</button>',
            '    </div>',
            '    <div class="d-flex gap-2"><input type="text" id="trackSearch" class="form-control form-control-sm" placeholder="Quick search..."></div>',
            '  </div>',
            '  <div class="row g-3 mb-4">',
            ['New', 'Shortlisted', 'Interview', 'Offer'].map(function (stage) {
                return [
                    '    <div class="col-md-3">',
                    '      <div class="tracking-stats-card p-3 border rounded-3 bg-white shadow-sm">',
                    '        <div class="d-flex justify-content-between align-items-center">',
                    '          <span class="text-muted small fw-medium">' + stage + '</span>',
                    '          <span class="badge bg-primary-subtle text-primary rounded-pill">' + trackingData.filter(function (item) { return item.stage === stage; }).length + '</span>',
                    '        </div>',
                    '        <h4 class="mt-2 mb-0 fw-bold">' + (stage === 'Offer' ? '2' : '5') + '%</h4>',
                    '        <div class="progress mt-2" style="height: 4px;"><div class="progress-bar" style="width: 45%"></div></div>',
                    '      </div>',
                    '    </div>'
                ].join('');
            }).join(''),
            '  </div>',
            '  <div class="table-responsive border rounded-3 bg-white">',
            '    <table class="table table-hover align-middle mb-0">',
            '      <thead>',
            '        <tr>',
            '          <th>Candidate</th>',
            '          <th>Stage</th>',
            '          <th>Rating</th>',
            '          <th class="text-end">Actions</th>',
            '        </tr>',
            '      </thead>',
            '      <tbody id="trackingBody">' + renderTrackingRows(hrCandidates) + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        setupTrackingListeners();
    };

    function renderTrackingRows(data) {
    return data.map(function (candidate) {
        const isReadyToHire = candidate.stage === 'Offer' || candidate.stage === 'Hired';
        
        return `
            <tr>
                <td>
                    <div class="fw-bold">${candidate.name}</div>
                    <div class="extra-small text-muted">${candidate.role}</div>
                </td>
                <td>
                    <select class="form-select form-select-sm stage-select" data-id="${candidate.id}">
                        ${['New', 'Shortlisted', 'Interview', 'Offer'].map(stage => 
                            `<option value="${stage}" ${candidate.stage === stage ? 'selected' : ''}>${stage}</option>`
                        ).join('')}
                    </select>
                </td>
                <td>${'<i class="fas fa-star text-warning"></i>'.repeat(candidate.rating)}</td>
                <td class="text-end">
                    ${isReadyToHire ? 
                        `<button class="btn btn-sm btn-success me-1" onclick="window.HRSubmodules.hireApplicant('${candidate.id}')" title="Finalize Hire">
                            <i class="fas fa-user-check"></i> Hire
                         </button>` : ''
                    }
                    <button class="btn btn-sm btn-light border delete-btn" data-id="${candidate.id}">
                        <i class="fas fa-user-slash text-danger"></i>
                    </button>
                </td>
            </tr>`;
    }).join('');
}

    function ensureTrackingModalHost() {
        if (document.getElementById('trackingActionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trackingActionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trackingActionModalTitle">Candidate Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trackingActionModalBody"></div>',
            '      <div class="modal-footer" id="trackingActionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrackingInfoModal(title, message) {
        const modalEl = document.getElementById('trackingActionModal');
        const titleEl = document.getElementById('trackingActionModalTitle');
        const bodyEl = document.getElementById('trackingActionModalBody');
        const footerEl = document.getElementById('trackingActionModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function showDeleteCandidateModal(candidateName, onConfirm) {
        const modalEl = document.getElementById('trackingActionModal');
        const titleEl = document.getElementById('trackingActionModalTitle');
        const bodyEl = document.getElementById('trackingActionModalBody');
        const footerEl = document.getElementById('trackingActionModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Remove Candidate';
        bodyEl.innerHTML = '<p class="mb-0">Are you sure you want to remove <strong>' + candidateName + '</strong> from the pipeline?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-danger" id="trackingDeleteConfirmBtn">Remove</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('trackingDeleteConfirmBtn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                onConfirm();
                modal.hide();
            }, { once: true });
        }

        modal.show();
    }

    let hrCandidates = JSON.parse(localStorage.getItem('hrCandidates')) || [
        { id: 'APP-001', name: 'Clarice Starling', role: 'HR Generalist', stage: 'New', email: 'c.starling@hospital.com', rating: 4 },
        { id: 'APP-002', name: 'Harvey Specter', role: 'Recruitment Lead', stage: 'Interview', email: 'h.specter@hospital.com', rating: 5 }
    ];

    function saveAndSyncCandidates() {
        localStorage.setItem('hrCandidates', JSON.stringify(hrCandidates));
        localStorage.setItem('hospitalHrPendingApps', hrCandidates.filter(function (candidate) { return candidate.stage === 'New'; }).length);
        window.dispatchEvent(new Event('storage'));
    }

    function setupTrackingListeners() {
        document.querySelectorAll('.stage-select').forEach(function (selectEl) {
            selectEl.addEventListener('change', function (event) {
                const id = event.target.dataset.id;
                const candidate = hrCandidates.find(function (item) { return item.id === id; });
                if (!candidate) {
                    return;
                }

                candidate.stage = event.target.value;
                saveAndSyncCandidates();
                showTrackingInfoModal('Stage Updated', candidate.name + ' moved to ' + candidate.stage + '.');
            });
        });

        document.querySelectorAll('.delete-btn').forEach(function (button) {
            button.addEventListener('click', function () {
                const id = button.dataset.id;
                const candidate = hrCandidates.find(function (item) { return item.id === id; });
                if (!candidate) {
                    return;
                }

                showDeleteCandidateModal(candidate.name, function () {
                    hrCandidates = hrCandidates.filter(function (item) { return item.id !== id; });
                    saveAndSyncCandidates();

                    const target = resolveApplicantContainer();
                    if (target) {
                        window.HRSubmodules.renderApplicationTracking(target);
                    }
                });
            });
        });
    }

    window.addEventListener('storage', function () {
        const active = (typeof window.activeSubmoduleName !== 'undefined') ? window.activeSubmoduleName : null;
        const container = resolveApplicantContainer();
        if (container && (!active || active === 'Application Tracking')) {
            window.HRSubmodules.renderApplicationTracking(container);
        }
    });

    window.HRSubmodules.refreshTracking = function () {
        const container = resolveApplicantContainer();
        if (container) {
            window.HRSubmodules.renderApplicationTracking(container);
        }
    };

    function ensureInterviewFeedbackModal() {
        if (document.getElementById('interviewFeedbackModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="interviewFeedbackModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="interviewFeedbackModalTitle">Interview Scheduling</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="interviewFeedbackModalBody"></div>',
            '      <div class="modal-footer"><button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showInterviewFeedback(title, message) {
        const modalEl = document.getElementById('interviewFeedbackModal');
        const titleEl = document.getElementById('interviewFeedbackModalTitle');
        const bodyEl = document.getElementById('interviewFeedbackModalBody');
        if (!modalEl || !titleEl || !bodyEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderInterviewScheduling = function (container) {
        ensureInterviewFeedbackModal();

        container.innerHTML = [
            '<div class="submodule-content-wrapper animate-fade-in">',
            '  <div class="row">',
            '    <div class="col-md-4">',
            '      <div class="p-3 border rounded-3 bg-light mb-3">',
            '        <h6 class="fw-bold">Schedule New</h6>',
            '        <div class="mb-2">',
            '          <label class="extra-small fw-bold">Candidate</label>',
            '          <input type="text" id="intCandidate" class="form-control form-control-sm" placeholder="Name">',
            '        </div>',
            '        <div class="mb-2">',
            '          <label class="extra-small fw-bold">Time Slot</label>',
            '          <input type="datetime-local" id="intTime" class="form-control form-control-sm">',
            '        </div>',
            '        <button id="btnConfirmSchedule" class="btn btn-primary btn-sm w-100 mt-2">Book Interview</button>',
            '      </div>',
            '    </div>',
            '    <div class="col-md-8">',
            '      <div class="border rounded-3 bg-white p-3">',
            '        <h6 class="fw-bold mb-3">Today\'s Schedule</h6>',
            '        <div id="interviewList"><div class="alert alert-info py-2 extra-small">No interviews scheduled for this time.</div></div>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        // Employment Management Logic
window.HRSubmodules.hireApplicant = function(id) {
    let applicants = JSON.parse(localStorage.getItem('hrCandidates')) || [];
    const index = applicants.findIndex(a => a.id === id);

    if (index !== -1) {
        const candidate = applicants[index];
        
        if (confirm(`Confirm hiring for ${candidate.name} as ${candidate.role}?`)) {
            // 1. Create Employee Record
            const employees = JSON.parse(localStorage.getItem('hospitalEmployees')) || [];
            employees.push({
                empId: `EMP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
                name: candidate.name,
                position: candidate.role,
                email: candidate.email,
                hiredDate: new Date().toLocaleDateString(),
                status: 'Active'
            });
            localStorage.setItem('hospitalEmployees', JSON.stringify(employees));

            // 2. Remove from Applicant Pipeline
            applicants.splice(index, 1);
            localStorage.setItem('hrCandidates', JSON.stringify(applicants));

            // 3. Sync and Refresh
            window.dispatchEvent(new Event('storage'));
            alert(`${candidate.name} has been successfully moved to the Employee Roster.`);
            this.renderApplicationTracking(resolveApplicantContainer());
        }
    }
};
        const confirmButton = document.getElementById('btnConfirmSchedule');
        if (confirmButton) {
            confirmButton.addEventListener('click', function () {
                const name = document.getElementById('intCandidate').value;
                const time = document.getElementById('intTime').value;

                if (!name || !time) {
                    showInterviewFeedback('Missing Required Fields', 'Please fill in candidate name and time slot before booking.');
                    return;
                }

                const count = parseInt(localStorage.getItem('hospitalHrPendingInterviews') || '0', 10);
                localStorage.setItem('hospitalHrPendingInterviews', String(count + 1));
                window.dispatchEvent(new Event('storage'));

                showInterviewFeedback('Interview Confirmed', 'Interview confirmed for ' + name + ' at ' + time + '. Dashboard metrics have been updated.');
                document.getElementById('intCandidate').value = '';
                document.getElementById('intTime').value = '';
            });
        }
    };

    function ensureMonitorFeedbackModal() {
        if (document.getElementById('monitorFeedbackModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="monitorFeedbackModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title">Status Monitoring</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="monitorFeedbackBody"></div>',
            '      <div class="modal-footer"><button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showMonitorFeedback(message) {
        const bodyEl = document.getElementById('monitorFeedbackBody');
        const modalEl = document.getElementById('monitorFeedbackModal');
        if (!bodyEl || !modalEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    const monitoringData = [
        { id: 'APP-99', name: 'Clarice Starling', status: 'Active', lastUpdate: '2 mins ago', stage: 'Technical Review', health: 'On Track' },
        { id: 'APP-85', name: 'Harvey Specter', status: 'Pending', lastUpdate: '1 hour ago', stage: 'Background Check', health: 'Delayed' },
        { id: 'APP-42', name: 'Donna Paulsen', status: 'Active', lastUpdate: 'Just now', stage: 'Contract Drafting', health: 'Urgent' }
    ];

    function getHealthColor(health) {
        if (health === 'On Track') {
            return 'success';
        }
        if (health === 'Delayed') {
            return 'warning';
        }
        return 'danger';
    }

    window.HRSubmodules.renderApplicantStatusMonitoring = function (container) {
        ensureMonitorFeedbackModal();

        container.innerHTML = [
            '<div class="submodule-content-wrapper animate-fade-in">',
            '  <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4">',
            '    <div>',
            '      <h6 class="mb-0 fw-bold"><i class="fas fa-satellite-dish text-primary me-2"></i>Live Status Monitor</h6>',
            '      <small class="text-muted">Tracking ' + monitoringData.length + ' high-priority candidates</small>',
            '    </div>',
            '    <div class="status-indicator-group d-flex gap-3">',
            '      <div class="small"><span class="status-dot bg-success"></span> Healthy</div>',
            '      <div class="small"><span class="status-dot bg-warning"></span> Attention</div>',
            '      <div class="small"><span class="status-dot bg-danger"></span> Critical</div>',
            '    </div>',
            '  </div>',
            '  <div class="row g-4">',
            '    <div class="col-lg-12">',
            '      <div class="monitoring-grid">',
            monitoringData.map(function (item) {
                return [
                    '<div class="monitor-card p-3 mb-3 border rounded-3 bg-white shadow-sm">',
                    '  <div class="row align-items-center">',
                    '    <div class="col-md-3"><div class="fw-bold text-dark">' + item.name + '</div><div class="extra-small text-muted font-monospace">' + item.id + '</div></div>',
                    '    <div class="col-md-3"><div class="extra-small text-uppercase fw-bold text-muted mb-1">Current Stage</div><div class="badge bg-primary-subtle text-primary border-primary-subtle">' + item.stage + '</div></div>',
                    '    <div class="col-md-2"><div class="extra-small text-uppercase fw-bold text-muted mb-1">Health</div><span class="text-' + getHealthColor(item.health) + ' small fw-medium"><i class="fas fa-circle me-1" style="font-size: 8px;"></i>' + item.health + '</span></div>',
                    '    <div class="col-md-2 text-center"><div class="extra-small text-uppercase fw-bold text-muted mb-1">Last Update</div><div class="small text-dark">' + item.lastUpdate + '</div></div>',
                    '    <div class="col-md-2 text-end"><button class="btn btn-sm btn-outline-secondary border-0" onclick="window.HRSubmodules.triggerMonitorSync()"><i class="fas fa-ellipsis-h"></i></button></div>',
                    '  </div>',
                    '  <div class="progress mt-3" style="height: 4px;"><div class="progress-bar bg-' + getHealthColor(item.health) + '" style="width: ' + (item.health === 'Urgent' ? '90' : '45') + '%"></div></div>',
                    '</div>'
                ].join('');
            }).join(''),
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');
    };

    window.HRSubmodules.triggerMonitorSync = function () {
        localStorage.setItem('hospitalHrMonitorAlerts', String(Math.floor(Math.random() * 5)));
        localStorage.setItem('hospitalHrLastSync', new Date().toLocaleTimeString());
        window.dispatchEvent(new Event('storage'));
        showMonitorFeedback('Monitor data synced with dashboard at ' + new Date().toLocaleTimeString() + '.');
    };
})();

(function () {
    'use strict';

    function initApplicantStandalone() {
        const container = document.getElementById('applicantSubmoduleContainer');
        const navButtons = document.querySelectorAll('[data-submodule]');
        if (!container || !navButtons.length || !window.HRSubmodules) {
            return;
        }

        const renderMap = {
            'Applicant List': 'renderApplicantList',
            'Application Tracking': 'renderApplicationTracking',
            'Interview Scheduling': 'renderInterviewScheduling',
            'Applicant Status Monitoring': 'renderApplicantStatusMonitoring'
        };

        function render(name) {
            const method = renderMap[name];
            if (method && typeof window.HRSubmodules[method] === 'function') {
                window.HRSubmodules[method](container);
            }
        }

        navButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                navButtons.forEach(function (item) {
                    item.classList.remove('active');
                });
                button.classList.add('active');
                render(button.getAttribute('data-submodule'));
            });
        });

        const activeBtn = document.querySelector('[data-submodule].active') || navButtons[0];
        if (activeBtn) {
            render(activeBtn.getAttribute('data-submodule'));
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApplicantStandalone);
    } else {
        initApplicantStandalone();
    }
})();
