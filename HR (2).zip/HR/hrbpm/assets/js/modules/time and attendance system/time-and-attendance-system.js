window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    // Use data from PHP if available, otherwise fallback to localStorage
    function getAttendanceRecords() {
        if (window.hrAttendanceData && window.hrAttendanceData.records && window.hrAttendanceData.records.length > 0) {
            return window.hrAttendanceData.records.map(record => ({
                employee: record.employee_name || record.employee,
                department: record.department_name || record.department,
                timeIn: record.time_in || record.timeIn || '-',
                timeOut: record.time_out || record.timeOut || '-',
                duty: record.duty_assignment || record.duty || 'General Duty',
                status: record.status || 'No Log-in'
            }));
        }
        
        // Fallback to localStorage if no PHP data
        const stored = localStorage.getItem('hospitalHrAttendanceRecords');
        if (stored) {
            try {
                return JSON.parse(stored);
            } catch (e) {
                return getAttendanceSeedData();
            }
        }
        return getAttendanceSeedData();
    }

    function getAttendanceSeedData() {
        return [
            { employee: 'Anna Santos', department: 'HR Operations', duty: 'Front Desk Coverage', timeIn: '08:02 AM', timeOut: '-', status: 'Present' },
            { employee: 'Mark Rivera', department: 'Finance', duty: 'Payroll Reconciliation', timeIn: '08:21 AM', timeOut: '-', status: 'Late' },
            { employee: 'Liza De Leon', department: 'Nursing', duty: 'Ward A Monitoring', timeIn: '-', timeOut: '-', status: 'No Log-in' },
            { employee: 'Paolo Cruz', department: 'HR Operations', duty: 'Interview Scheduling', timeIn: '-', timeOut: '-', status: 'On Leave' },
            { employee: 'Jude Molina', department: 'Operations', duty: 'Shift Supervisor', timeIn: '07:58 AM', timeOut: '-', status: 'Present' },
            { employee: 'Mara Lopez', department: 'Nursing', duty: 'Medication Rounds', timeIn: '08:17 AM', timeOut: '-', status: 'Late' }
        ];
    }

    function setAttendanceRecords(records) {
        localStorage.setItem('hospitalHrAttendanceRecords', JSON.stringify(records));
    }

    function currentTimeLabel() {
        return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    function getStorageList(key, fallback) {
        // For validation queue and correction requests, try PHP data first
        if (key === 'hospitalHrAttendanceValidationQueue' && window.hrAttendanceData && window.hrAttendanceData.validationQueue) {
            return window.hrAttendanceData.validationQueue.map(item => ({
                id: item.request_id || item.id,
                employee: item.employee_name || item.employee,
                issue: item.issue,
                status: item.status
            }));
        }
        
        if (key === 'hospitalHrCorrectionRequests' && window.hrAttendanceData && window.hrAttendanceData.correctionRequests) {
            return window.hrAttendanceData.correctionRequests;
        }

        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {}

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    // Attendance Monitoring
    registry.renderAttendanceMonitoring = function (container) {
        let records = getAttendanceRecords().map(function (row) {
            return {
                employee: row.employee || 'N/A',
                department: row.department || 'Unassigned',
                duty: row.duty || 'General Duty',
                timeIn: row.timeIn || '-',
                timeOut: row.timeOut || '-',
                status: row.status || 'No Log-in'
            };
        });
        
        container.innerHTML = [
            '<div class="card border-0 shadow-sm att-mon-submodule">',
            '  <div class="card-body">',
            '    <div class="att-mon-title d-flex align-items-center justify-content-between gap-2 mb-3">',
            '      <h6 class="mb-0 d-flex align-items-center gap-2"><i class="fas fa-user-check text-primary"></i>Attendance Monitoring</h6>',
            '      <div class="att-mon-title-tools d-flex align-items-center gap-2">',
            '        <div class="input-group input-group-sm att-mon-search-wrap">',
            '          <span class="input-group-text"><i class="fas fa-magnifying-glass"></i></span>',
            '          <input id="attMonSearch" class="form-control" placeholder="Search employee">',
            '        </div>',
            '        <span class="att-mon-live-chip small">Live</span>',
            '      </div>',
            '    </div>',
            '    <div class="att-mon-control-panel mb-3">',
            '    <div class="row g-3 mb-3">',
            '      <div class="col-lg-4">',
            '        <label class="form-label small text-muted mb-1">Select Employee</label>',
            '        <select id="attMonEmployee" class="form-select"></select>',
            '      </div>',
            '      <div class="col-lg-4">',
            '        <label class="form-label small text-muted mb-1">Duty Assignment</label>',
            '        <input id="attMonDuty" class="form-control" placeholder="Enter assigned duty">',
            '      </div>',
            '      <div class="col-lg-4 d-flex align-items-end gap-2">',
            '        <button id="attMonClockInBtn" class="btn btn-success w-100"><i class="fas fa-right-to-bracket me-1"></i>Clock In</button>',
            '        <button id="attMonClockOutBtn" class="btn btn-outline-danger w-100"><i class="fas fa-right-from-bracket me-1"></i>Clock Out</button>',
            '      </div>',
            '    </div>',
            '    <div class="row g-3">',
            '      <div class="col-md-4">',
            '        <select id="attMonStatus" class="form-select">',
            '          <option value="All">All Status</option>',
            '          <option value="Present">Present</option>',
            '          <option value="Late">Late</option>',
            '          <option value="Clocked Out">Clocked Out</option>',
            '          <option value="On Leave">On Leave</option>',
            '          <option value="No Log-in">No Log-in</option>',
            '          <option value="Absent">Absent</option>',
            '        </select>',
            '      </div>',
            '      <div class="col-md-8">',
            '        <div class="att-mon-live-panel border rounded-3 p-2 px-3 h-100 d-flex align-items-center justify-content-between">',
            '          <span class="small text-muted">Real-Time Attendance Tracking</span>',
            '          <span id="attMonRealtimeStamp" class="small fw-semibold">Updated --</span>',
            '        </div>',
            '      </div>',
            '    </div>',
            '    </div>',
            '    <div id="attMonKpis" class="row g-3 mb-3 att-mon-kpis"></div>',
            '    <div class="table-responsive">',
            '      <table class="table table-sm align-middle mb-0">',
            '        <thead>',
            '          <tr>',
            '            <th>Employee</th>',
            '            <th>Department</th>',
            '            <th>Assigned Duty</th>',
            '            <th>Time In</th>',
            '            <th>Time Out</th>',
            '            <th>Status</th>',
            '            <th>Action</th>',
            '          </tr>',
            '        </thead>',
            '        <tbody id="attMonRows"></tbody>',
            '      </table>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        const employeeSelect = document.getElementById('attMonEmployee');
        const dutyInput = document.getElementById('attMonDuty');
        const clockInButton = document.getElementById('attMonClockInBtn');
        const clockOutButton = document.getElementById('attMonClockOutBtn');
        const searchInput = document.getElementById('attMonSearch');
        const statusSelect = document.getElementById('attMonStatus');
        const rowsEl = document.getElementById('attMonRows');
        const kpisEl = document.getElementById('attMonKpis');
        const realtimeStampEl = document.getElementById('attMonRealtimeStamp');

        function populateEmployeeSelector() {
            if (!employeeSelect) return;
            employeeSelect.innerHTML = records.map(function (row, index) {
                return '<option value="' + index + '">' + row.employee + ' (' + row.department + ')</option>';
            }).join('');

            if (records.length > 0 && dutyInput) {
                dutyInput.value = records[0].duty || '';
            }
        }

        function updateRealtimeStamp() {
            if (realtimeStampEl) {
                realtimeStampEl.textContent = 'Updated ' + currentTimeLabel();
            }
        }

        function commitAndRender() {
            setAttendanceRecords(records);
            updateRealtimeStamp();
            render();
        }

        function render() {
            const query = (searchInput.value || '').toLowerCase().trim();
            const status = statusSelect.value;
            
            const filtered = records.filter(function (row) {
                const matchesStatus = status === 'All' || row.status === status;
                const matchesQuery = !query || 
                    (row.employee && row.employee.toLowerCase().indexOf(query) !== -1) || 
                    (row.department && row.department.toLowerCase().indexOf(query) !== -1);
                return matchesStatus && matchesQuery;
            });

            // Calculate KPIs
            const present = filtered.filter(r => r.status === 'Present').length;
            const late = filtered.filter(r => r.status === 'Late').length;
            const activeNow = filtered.filter(r => (r.status === 'Present' || r.status === 'Late') && (r.timeOut === '-' || !r.timeOut)).length;
            const onLeave = filtered.filter(r => r.status === 'On Leave').length;
            const noLogin = filtered.filter(r => r.status === 'No Log-in' || r.status === 'Absent').length;

            kpisEl.innerHTML = [
                '<div class="col-6 col-md-4">',
                '  <div class="att-mon-kpi-card border rounded-3 p-3">',
                '    <p class="text-muted mb-1">Present</p>',
                '    <h5 class="mb-0">' + present + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-6 col-md-4">',
                '  <div class="att-mon-kpi-card border rounded-3 p-3">',
                '    <p class="text-muted mb-1">Late</p>',
                '    <h5 class="mb-0">' + late + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-6 col-md-4">',
                '  <div class="att-mon-kpi-card border rounded-3 p-3">',
                '    <p class="text-muted mb-1">Active Now</p>',
                '    <h5 class="mb-0">' + activeNow + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-6 col-md-4">',
                '  <div class="att-mon-kpi-card border rounded-3 p-3">',
                '    <p class="text-muted mb-1">On Leave</p>',
                '    <h5 class="mb-0">' + onLeave + '</h5>',
                '  </div>',
                '</div>',
                '<div class="col-6 col-md-4">',
                '  <div class="att-mon-kpi-card border rounded-3 p-3">',
                '    <p class="text-muted mb-1">No Log-in</p>',
                '    <h5 class="mb-0">' + noLogin + '</h5>',
                '  </div>',
                '</div>'
            ].join('');

            rowsEl.innerHTML = filtered.map(function (row) {
                const badgeClass = row.status === 'Present'
                    ? 'bg-success-subtle text-success'
                    : row.status === 'Late'
                        ? 'bg-warning-subtle text-warning'
                        : row.status === 'Clocked Out'
                            ? 'bg-secondary-subtle text-secondary'
                        : row.status === 'On Leave'
                            ? 'bg-info-subtle text-info'
                            : 'bg-danger-subtle text-danger';
                
                return '<tr>' +
                    '<td>' + (row.employee || 'N/A') + '</td>' +
                    '<td>' + (row.department || 'N/A') + '</td>' +
                    '<td>' + (row.duty || 'General Duty') + '</td>' +
                    '<td>' + (row.timeIn || '-') + '</td>' +
                    '<td>' + (row.timeOut || '-') + '</td>' +
                    '<td><span class="badge ' + badgeClass + '">' + (row.status || 'Unknown') + '</span></td>' +
                    '<td class="att-mon-row-actions">' +
                        '<button class="btn btn-sm btn-outline-success" data-row-action="clock-in" data-employee="' + row.employee + '">In</button>' +
                        '<button class="btn btn-sm btn-outline-danger" data-row-action="clock-out" data-employee="' + row.employee + '">Out</button>' +
                    '</td>' +
                    '</tr>';
            }).join('');

            rowsEl.querySelectorAll('button[data-row-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = this.getAttribute('data-row-action');
                    const employee = this.getAttribute('data-employee');
                    const target = records.find(function (item) {
                        return item.employee === employee;
                    });

                    if (!target) return;

                    if (action === 'clock-in') {
                        target.timeIn = currentTimeLabel();
                        target.timeOut = '-';
                        target.status = 'Present';
                    } else {
                        target.timeOut = currentTimeLabel();
                        target.status = 'Clocked Out';
                    }

                    commitAndRender();
                });
            });
        }

        if (employeeSelect) {
            employeeSelect.addEventListener('change', function () {
                const selected = records[Number(employeeSelect.value)];
                if (dutyInput) {
                    dutyInput.value = selected ? (selected.duty || '') : '';
                }
            });
        }

        if (clockInButton) {
            clockInButton.addEventListener('click', function () {
                const selected = records[Number(employeeSelect.value)];
                if (!selected) return;

                selected.timeIn = currentTimeLabel();
                selected.timeOut = '-';
                selected.duty = (dutyInput && dutyInput.value.trim()) ? dutyInput.value.trim() : selected.duty;
                selected.status = 'Present';
                commitAndRender();
            });
        }

        if (clockOutButton) {
            clockOutButton.addEventListener('click', function () {
                const selected = records[Number(employeeSelect.value)];
                if (!selected) return;

                selected.timeOut = currentTimeLabel();
                selected.duty = (dutyInput && dutyInput.value.trim()) ? dutyInput.value.trim() : selected.duty;
                selected.status = 'Clocked Out';
                commitAndRender();
            });
        }

        if (searchInput) searchInput.addEventListener('input', render);
        if (statusSelect) statusSelect.addEventListener('change', render);

        populateEmployeeSelector();
        updateRealtimeStamp();

        if (container && container._attMonRefreshTimer) {
            window.clearInterval(container._attMonRefreshTimer);
        }

        const refreshTimer = window.setInterval(updateRealtimeStamp, 15000);
        if (container) {
            container._attMonRefreshTimer = refreshTimer;
        }

        render();
    };

    // Attendance Validation
    registry.renderAttendanceValidation = function (container) {
        ensureModalHost('attendanceValidationModal');

        const fallback = [];
        let queue = getStorageList('hospitalHrAttendanceValidationQueue', fallback);

        function parseTimeToMinutes(value) {
            if (!value || value === '-') return null;

            const parts = String(value).trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
            if (!parts) return null;

            let hour = Number(parts[1]);
            const minute = Number(parts[2]);
            const meridiem = parts[3].toUpperCase();

            if (meridiem === 'AM' && hour === 12) hour = 0;
            if (meridiem === 'PM' && hour !== 12) hour += 12;

            return (hour * 60) + minute;
        }

        function buildValidationResults() {
            const records = getAttendanceRecords();
            const expectedStartMinutes = (8 * 60) + 1;
            const expectedShiftMinutes = 8 * 60;

            return records.map(function (row) {
                const timeInMinutes = parseTimeToMinutes(row.timeIn);
                const timeOutMinutes = parseTimeToMinutes(row.timeOut);
                const exceptions = [];

                let totalMinutes = 0;
                if (timeInMinutes !== null && timeOutMinutes !== null) {
                    totalMinutes = timeOutMinutes >= timeInMinutes
                        ? (timeOutMinutes - timeInMinutes)
                        : ((24 * 60) - timeInMinutes + timeOutMinutes);
                }

                if (row.status === 'No Log-in' || row.status === 'Absent') {
                    exceptions.push('Absent / No Log-in');
                }

                if (timeInMinutes === null || timeOutMinutes === null) {
                    exceptions.push('Incomplete Log');
                }

                if (timeInMinutes !== null && timeInMinutes > expectedStartMinutes) {
                    exceptions.push('Late Arrival');
                }

                if (totalMinutes > 0 && totalMinutes < expectedShiftMinutes) {
                    exceptions.push('Undertime');
                }

                const hours = Math.floor(totalMinutes / 60);
                const minutes = totalMinutes % 60;
                const totalHoursLabel = totalMinutes > 0
                    ? (String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0'))
                    : '-';

                return {
                    employee: row.employee || 'N/A',
                    department: row.department || 'Unknown',
                    timeIn: row.timeIn || '-',
                    timeOut: row.timeOut || '-',
                    totalMinutes: totalMinutes,
                    totalHoursLabel: totalHoursLabel,
                    validationStatus: exceptions.length ? 'Invalid' : 'Valid',
                    exceptionText: exceptions.length ? exceptions.join(', ') : 'None'
                };
            });
        }

        function syncAutoValidationQueue(results) {
            const autoById = {};
            const manualQueue = queue.filter(function (item) {
                return String(item.id || '').indexOf('VAL-AUTO-') !== 0;
            });

            queue.forEach(function (item) {
                if (String(item.id || '').indexOf('VAL-AUTO-') === 0) {
                    autoById[item.id] = item;
                }
            });

            const autoQueue = results
                .filter(function (row) {
                    return row.validationStatus === 'Invalid';
                })
                .map(function (row, index) {
                    const id = 'VAL-AUTO-' + String(index + 1).padStart(3, '0');
                    const existing = autoById[id];
                    return {
                        id: id,
                        employee: row.employee,
                        issue: row.exceptionText,
                        hours: row.totalHoursLabel,
                        status: existing ? existing.status : 'For Review'
                    };
                });

            queue = manualQueue.concat(autoQueue);
            setStorageList('hospitalHrAttendanceValidationQueue', queue);
        }

        function render() {
            const validationResults = buildValidationResults();
            syncAutoValidationQueue(validationResults);

            const invalidCount = validationResults.filter(function (row) {
                return row.validationStatus === 'Invalid';
            }).length;
            const validCount = validationResults.length - invalidCount;
            const withHours = validationResults.filter(function (row) {
                return row.totalMinutes > 0;
            });
            const avgMinutes = withHours.length
                ? Math.round(withHours.reduce(function (sum, row) {
                    return sum + row.totalMinutes;
                }, 0) / withHours.length)
                : 0;
            const avgHoursLabel = avgMinutes
                ? (String(Math.floor(avgMinutes / 60)).padStart(2, '0') + ':' + String(avgMinutes % 60).padStart(2, '0'))
                : '-';

            container.innerHTML = [
                '<div class="card border-0 shadow-sm att-val-submodule att-val-overview mb-3">',
                '  <div class="card-body">',
                '    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-3">',
                '      <h5 class="mb-0"><i class="fas fa-clipboard-check text-primary me-2"></i>Attendance Validation</h5>',
                '      <button class="btn btn-primary btn-sm" id="attRunValidation"><i class="fas fa-rotate me-1"></i>Auto-Validate Attendance</button>',
                '    </div>',
                '    <div class="row g-3">',
                '      <div class="col-6 col-lg-3"><div class="att-val-kpi border rounded-3 p-3"><p class="text-muted mb-1">Valid Logs</p><h5 class="mb-0">' + validCount + '</h5></div></div>',
                '      <div class="col-6 col-lg-3"><div class="att-val-kpi border rounded-3 p-3"><p class="text-muted mb-1">Flagged Invalid</p><h5 class="mb-0 text-danger">' + invalidCount + '</h5></div></div>',
                '      <div class="col-6 col-lg-3"><div class="att-val-kpi border rounded-3 p-3"><p class="text-muted mb-1">Avg Working Hours</p><h5 class="mb-0">' + avgHoursLabel + '</h5></div></div>',
                '      <div class="col-6 col-lg-3"><div class="att-val-kpi border rounded-3 p-3"><p class="text-muted mb-1">Exceptions Detected</p><h5 class="mb-0 text-warning">' + invalidCount + '</h5></div></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm att-val-submodule mb-3">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center gap-2">',
                '    <h6 class="mb-0">Validation Results</h6>',
                '    <span class="att-val-count small">' + validationResults.length + ' records</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle att-val-table">',
                '      <thead><tr><th>Employee</th><th>Department</th><th>Time In</th><th>Time Out</th><th>Total Hours</th><th>Validation</th><th>Exception Detection</th><th>Action</th></tr></thead>',
                '      <tbody>',
                validationResults.map(function (row) {
                    const badgeClass = row.validationStatus === 'Valid'
                        ? 'bg-success-subtle text-success'
                        : 'bg-danger-subtle text-danger';

                    return '<tr>' +
                        '<td>' + row.employee + '</td>' +
                        '<td>' + row.department + '</td>' +
                        '<td>' + row.timeIn + '</td>' +
                        '<td>' + row.timeOut + '</td>' +
                        '<td>' + row.totalHoursLabel + '</td>' +
                        '<td><span class="badge ' + badgeClass + '">' + row.validationStatus + '</span></td>' +
                        '<td><span class="att-val-exception-text">' + row.exceptionText + '</span></td>' +
                        '<td class="att-val-actions">' +
                            (row.validationStatus === 'Invalid'
                                ? '<button class="btn btn-sm btn-outline-danger" data-flag-invalid="' + row.employee + '">Flag Invalid</button>'
                                : '<span class="text-success small">No Exception</span>') +
                        '</td>' +
                        '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm att-val-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h6 class="mb-0">Validation Exception Queue</h6>',
                '    <span class="badge bg-warning-subtle text-warning">' + queue.filter(function (item) { return item.status === 'Pending' || item.status === 'For Review'; }).length + ' Open</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle att-val-table">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Issue</th><th>Computed Hours</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                queue.map(function (item) {
                    const statusClass = item.status === 'Approved'
                        ? 'bg-success-subtle text-success'
                        : item.status === 'Rejected'
                            ? 'bg-danger-subtle text-danger'
                            : 'bg-warning-subtle text-warning';

                    return '<tr>' +
                        '<td>' + item.id + '</td>' +
                        '<td>' + item.employee + '</td>' +
                        '<td><span class="att-val-exception-text">' + item.issue + '</span></td>' +
                        '<td>' + (item.hours || '-') + '</td>' +
                        '<td><span class="badge ' + statusClass + '">' + item.status + '</span></td>' +
                        '<td class="att-val-actions">' +
                        '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>' +
                        '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>' +
                        '</td>' +
                        '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const runValidationButton = document.getElementById('attRunValidation');
            if (runValidationButton) {
                runValidationButton.addEventListener('click', function () {
                    showModal({
                        modalId: 'attendanceValidationModal',
                        title: 'Auto Validation Complete',
                        message: 'Attendance logs were auto-validated and invalid logs were flagged into the exception queue.'
                    });
                    render();
                });
            }

            container.querySelectorAll('button[data-flag-invalid]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const employee = this.getAttribute('data-flag-invalid');
                    queue = queue.map(function (item) {
                        if (item.employee === employee && (item.status === 'Pending' || item.status === 'For Review')) {
                            return Object.assign({}, item, { status: 'For Review' });
                        }
                        return item;
                    });

                    setStorageList('hospitalHrAttendanceValidationQueue', queue);
                    render();
                });
            });

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = this.getAttribute('data-action');
                    const id = this.getAttribute('data-id');
                    const target = queue.find(function (item) {
                        return item.id === id;
                    });

                    if (!target) return;

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showModal({
                        modalId: 'attendanceValidationModal',
                        title: nextStatus === 'Approved' ? 'Approve Validation' : 'Reject Validation',
                        message: 'Set request ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmAction">Confirm</button>'
                        ].join(''),
                        onConfirm: function (modal) {
                            queue = queue.map(function (item) {
                                if (item.id === id) {
                                    return Object.assign({}, item, { status: nextStatus });
                                }
                                return item;
                            });
                            setStorageList('hospitalHrAttendanceValidationQueue', queue);
                            modal.hide();
                            render();
                        }
                    });
                });
            });
        }

        render();
    };

    // Attendance Reports
    registry.renderAttendanceReports = function (container) {
        ensureModalHost('attendanceReportsModal');

        const reportStateKey = 'hospitalHrAttendanceReportState';

        function parseTimeToMinutes(value) {
            if (!value || value === '-') return null;

            const parts = String(value).trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
            if (!parts) return null;

            let hour = Number(parts[1]);
            const minute = Number(parts[2]);
            const meridiem = parts[3].toUpperCase();

            if (meridiem === 'AM' && hour === 12) hour = 0;
            if (meridiem === 'PM' && hour !== 12) hour += 12;

            return (hour * 60) + minute;
        }

        function formatMinutes(totalMinutes) {
            if (!totalMinutes || totalMinutes <= 0) return '-';
            const hours = Math.floor(totalMinutes / 60);
            const minutes = totalMinutes % 60;
            return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0');
        }

        function getReportState() {
            const raw = localStorage.getItem(reportStateKey);
            if (!raw) {
                return { finalized: false, finalizedAt: null, records: [] };
            }

            try {
                const parsed = JSON.parse(raw);
                return {
                    finalized: !!parsed.finalized,
                    finalizedAt: parsed.finalizedAt || null,
                    records: Array.isArray(parsed.records) ? parsed.records : []
                };
            } catch (error) {
                return { finalized: false, finalizedAt: null, records: [] };
            }
        }

        function saveReportState(nextState) {
            localStorage.setItem(reportStateKey, JSON.stringify(nextState));
        }

        function buildGeneratedRecord(baseRow, approvedCorrectionMap) {
            const timeIn = baseRow.timeIn || '-';
            const timeOut = baseRow.timeOut || '-';
            const timeInMinutes = parseTimeToMinutes(timeIn);
            const timeOutMinutes = parseTimeToMinutes(timeOut);

            let totalMinutes = 0;
            if (timeInMinutes !== null && timeOutMinutes !== null) {
                totalMinutes = timeOutMinutes >= timeInMinutes
                    ? (timeOutMinutes - timeInMinutes)
                    : ((24 * 60) - timeInMinutes + timeOutMinutes);
            }

            const approvedCorrection = approvedCorrectionMap[baseRow.employee] || null;
            return {
                employee: baseRow.employee || 'N/A',
                department: baseRow.department || 'Unknown',
                status: baseRow.status || 'Unknown',
                timeIn: timeIn,
                timeOut: timeOut,
                totalHours: formatMinutes(totalMinutes),
                correction: approvedCorrection ? approvedCorrection.issue : 'None',
                updatedAt: new Date().toISOString()
            };
        }

        function buildDepartmentSummary(records) {
            const departments = {};

            records.forEach(function (row) {
                const dept = row.department || 'Unknown';
                if (!departments[dept]) {
                    departments[dept] = { total: 0, late: 0, absences: 0 };
                }

                departments[dept].total += 1;
                if (row.status === 'Late') departments[dept].late += 1;
                if (row.status === 'No Log-in' || row.status === 'Absent') departments[dept].absences += 1;
            });

            return departments;
        }

        function render() {
            const attendanceRows = getAttendanceRecords();
            const correctionRequests = getStorageList('hospitalHrCorrectionRequests', []);
            const approvedCorrectionMap = {};

            correctionRequests.forEach(function (item) {
                if (item && item.status === 'Approved' && item.employee) {
                    approvedCorrectionMap[item.employee] = item;
                }
            });

            let reportState = getReportState();
            const generatedRecords = reportState.records;

            const sourceRows = generatedRecords.length > 0 ? generatedRecords : attendanceRows;
            const departments = buildDepartmentSummary(sourceRows);
            const totalEmployees = sourceRows.length;
            const totalAbsences = sourceRows.filter(function (r) {
                return r.status === 'No Log-in' || r.status === 'Absent';
            }).length;
            const totalLate = sourceRows.filter(function (r) {
                return r.status === 'Late';
            }).length;
            const attendanceRate = totalEmployees > 0
                ? Math.round(((totalEmployees - totalAbsences) / totalEmployees) * 100)
                : 0;

            const departmentRows = Object.keys(departments).map(function (dept) {
                const info = departments[dept];
                const rate = Math.round(((info.total - info.absences) / info.total) * 100);
                return '<tr><td>' + dept + '</td><td>' + rate + '%</td><td>' + info.late + '</td><td>' + info.absences + '</td></tr>';
            }).join('');

            const employeeOptions = attendanceRows.map(function (row, index) {
                return '<option value="' + index + '">' + row.employee + ' (' + (row.department || 'Unknown') + ')</option>';
            }).join('');

            const finalizedLabel = reportState.finalizedAt
                ? new Date(reportState.finalizedAt).toLocaleString()
                : '-';

            container.innerHTML = [
                '<div class="card border-0 shadow-sm att-reports-submodule mb-3">',
                '  <div class="card-body">',
                '    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-3">',
                '      <h6 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Attendance Reports</h6>',
                '      <div class="d-flex flex-wrap gap-2">',
                '        <button id="attApplyCorrections" class="btn btn-outline-primary btn-sm">Update Attendance Record</button>',
                '        <button id="attFinalizeBtn" class="btn ' + (reportState.finalized ? 'btn-success' : 'btn-outline-success') + ' btn-sm">Finalize Attendance</button>',
                '        <button id="attExportCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button>',
                '      </div>',
                '    </div>',
                '    <div class="row g-3 mb-3">',
                '      <div class="col-6 col-lg-3"><div class="att-report-kpi border rounded-3 p-3"><p class="text-muted mb-1">Attendance Rate</p><h5 class="mb-0">' + attendanceRate + '%</h5></div></div>',
                '      <div class="col-6 col-lg-3"><div class="att-report-kpi border rounded-3 p-3"><p class="text-muted mb-1">Late Incidents</p><h5 class="mb-0">' + totalLate + '</h5></div></div>',
                '      <div class="col-6 col-lg-3"><div class="att-report-kpi border rounded-3 p-3"><p class="text-muted mb-1">Absences</p><h5 class="mb-0">' + totalAbsences + '</h5></div></div>',
                '      <div class="col-6 col-lg-3"><div class="att-report-kpi border rounded-3 p-3"><p class="text-muted mb-1">Finalized At</p><h6 class="mb-0">' + finalizedLabel + '</h6></div></div>',
                '    </div>',
                '    <div class="att-report-generate row g-2">',
                '      <div class="col-lg-6">',
                '        <select id="attReportEmployee" class="form-select">',
                employeeOptions || '<option value="">No employee data</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-lg-3">',
                '        <button id="attGenerateRecord" class="btn btn-primary att-report-action-btn"' + (attendanceRows.length ? '' : ' disabled') + '>Generate Attendance Record</button>',
                '      </div>',
                '      <div class="col-lg-3">',
                '        <button id="attNotifyEmployee" class="btn btn-outline-info att-report-action-btn"' + (reportState.finalized ? '' : ' disabled') + '>Notify Employee</button>',
                '      </div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm mb-3">',
                '  <div class="card-header bg-white">',
                '    <h6 class="mb-0">Generated Attendance Logs</h6>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle att-report-table">',
                '      <thead><tr><th>Employee</th><th>Department</th><th>Time In</th><th>Time Out</th><th>Total Hours</th><th>Status</th><th>Correction Applied</th></tr></thead>',
                '      <tbody>',
                generatedRecords.length
                    ? generatedRecords.map(function (row) {
                        return '<tr>' +
                            '<td>' + row.employee + '</td>' +
                            '<td>' + row.department + '</td>' +
                            '<td>' + row.timeIn + '</td>' +
                            '<td>' + row.timeOut + '</td>' +
                            '<td>' + row.totalHours + '</td>' +
                            '<td>' + row.status + '</td>' +
                            '<td>' + row.correction + '</td>' +
                            '</tr>';
                    }).join('')
                    : '<tr><td colspan="7" class="text-center text-muted py-4">No generated attendance record yet.</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white">',
                '    <h6 class="mb-0">Department Attendance Summary</h6>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle att-report-table">',
                '      <thead><tr><th>Department</th><th>Attendance Rate</th><th>Late Cases</th><th>Absences</th></tr></thead>',
                '      <tbody>' + departmentRows + '</tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const generateButton = document.getElementById('attGenerateRecord');
            const updateButton = document.getElementById('attApplyCorrections');
            const finalizeButton = document.getElementById('attFinalizeBtn');
            const notifyButton = document.getElementById('attNotifyEmployee');
            const exportButton = document.getElementById('attExportCsv');
            const employeeSelect = document.getElementById('attReportEmployee');

            if (generateButton) {
                generateButton.addEventListener('click', function () {
                    const selectedIndex = Number(employeeSelect ? employeeSelect.value : -1);
                    const selectedRow = attendanceRows[selectedIndex];
                    if (!selectedRow) return;

                    const generated = buildGeneratedRecord(selectedRow, approvedCorrectionMap);
                    const existingIndex = reportState.records.findIndex(function (item) {
                        return item.employee === generated.employee;
                    });

                    if (existingIndex >= 0) {
                        reportState.records[existingIndex] = generated;
                    } else {
                        reportState.records.unshift(generated);
                    }

                    saveReportState(reportState);
                    showModal({
                        modalId: 'attendanceReportsModal',
                        title: 'Record Generated',
                        message: 'Attendance log for ' + generated.employee + ' has been generated.'
                    });
                    render();
                });
            }

            if (updateButton) {
                updateButton.addEventListener('click', function () {
                    if (!reportState.records.length) {
                        showModal({
                            modalId: 'attendanceReportsModal',
                            title: 'No Generated Records',
                            message: 'Generate attendance records first before applying correction updates.'
                        });
                        return;
                    }

                    reportState.records = reportState.records.map(function (item) {
                        const approved = approvedCorrectionMap[item.employee];
                        if (!approved) return item;

                        return Object.assign({}, item, {
                            correction: approved.issue,
                            updatedAt: new Date().toISOString()
                        });
                    });

                    saveReportState(reportState);
                    showModal({
                        modalId: 'attendanceReportsModal',
                        title: 'Attendance Record Updated',
                        message: 'Approved correction requests have been reflected in generated attendance records.'
                    });
                    render();
                });
            }

            if (finalizeButton) {
                finalizeButton.addEventListener('click', function () {
                    if (reportState.finalized) {
                        showModal({
                            modalId: 'attendanceReportsModal',
                            title: 'Already Finalized',
                            message: 'Attendance for this period is already finalized.'
                        });
                        return;
                    }

                    if (!reportState.records.length) {
                        showModal({
                            modalId: 'attendanceReportsModal',
                            title: 'No Records To Finalize',
                            message: 'Generate attendance records before finalizing the period.'
                        });
                        return;
                    }

                    reportState.finalized = true;
                    reportState.finalizedAt = new Date().toISOString();
                    saveReportState(reportState);

                    showModal({
                        modalId: 'attendanceReportsModal',
                        title: 'Attendance Finalized',
                        message: 'Attendance records for this period are now finalized and locked.'
                    });
                    render();
                });
            }

            if (notifyButton) {
                notifyButton.addEventListener('click', function () {
                    const selectedIndex = Number(employeeSelect ? employeeSelect.value : -1);
                    const selectedRow = attendanceRows[selectedIndex];

                    if (!selectedRow) return;

                    if (!reportState.finalized) {
                        showModal({
                            modalId: 'attendanceReportsModal',
                            title: 'Finalize Required',
                            message: 'Finalize attendance first before notifying employees.'
                        });
                        return;
                    }

                    const generated = reportState.records.find(function (item) {
                        return item.employee === selectedRow.employee;
                    });

                    if (!generated) {
                        showModal({
                            modalId: 'attendanceReportsModal',
                            title: 'Record Missing',
                            message: 'Generate attendance record for ' + selectedRow.employee + ' before sending notification.'
                        });
                        return;
                    }

                    showModal({
                        modalId: 'attendanceReportsModal',
                        title: 'Employee Notified',
                        message: 'Finalized attendance summary sent to ' + generated.employee + ' (Hours: ' + generated.totalHours + ').'
                    });
                });
            }

            if (exportButton) {
                exportButton.addEventListener('click', function () {
                    showModal({
                        modalId: 'attendanceReportsModal',
                        title: 'Export Attendance CSV',
                        message: 'Generate and download the attendance summary CSV now?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmExport">Export</button>'
                        ].join(''),
                        onConfirm: function (modal) {
                            const csvLines = ['Employee,Department,Time In,Time Out,Total Hours,Status,Correction Applied'];
                            const exportRows = reportState.records.length ? reportState.records : attendanceRows;

                            exportRows.forEach(function (row) {
                                csvLines.push([
                                    row.employee || '-',
                                    row.department || '-',
                                    row.timeIn || '-',
                                    row.timeOut || '-',
                                    row.totalHours || '-',
                                    row.status || '-',
                                    row.correction || 'None'
                                ].join(','));
                            });

                            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                            const link = document.createElement('a');
                            link.href = URL.createObjectURL(blob);
                            link.download = 'attendance-report-' + new Date().toISOString().split('T')[0] + '.csv';
                            link.click();
                            URL.revokeObjectURL(link.href);
                            modal.hide();

                            showModal({
                                modalId: 'attendanceReportsModal',
                                title: 'Export Complete',
                                message: 'Attendance report CSV has been downloaded.'
                            });
                        }
                    });
                });
            }
        }

        render();
    };

    // Correction Requests
    registry.renderCorrectionRequests = function (container) {
        ensureModalHost('correctionRequestsModal');

        const fallback = [
            { id: 'CR-1042', employee: 'Anna Santos', issue: 'Missing Time Out', status: 'Pending', requestedTimeOut: '05:10 PM', filedBy: 'Employee' },
            { id: 'CR-1041', employee: 'Miguel Reyes', issue: 'Wrong Shift Tag', status: 'Approved', requestedTimeIn: '08:01 AM', filedBy: 'Supervisor' },
            { id: 'CR-1038', employee: 'Leah Gomez', issue: 'Late Log Adjustment', status: 'Rejected', requestedTimeIn: '08:00 AM', filedBy: 'Employee' }
        ];

        let requests = getStorageList('hospitalHrCorrectionRequests', fallback).map(function (item, index) {
            return {
                id: item.id || item.request_id || ('CR-' + String(1000 + index)),
                employee: item.employee || item.employee_name || 'N/A',
                department: item.department || item.department_name || 'Unknown',
                issue: item.issue || 'Attendance exception',
                requestedTimeIn: item.requestedTimeIn || item.timeIn || item.requested_time_in || '-',
                requestedTimeOut: item.requestedTimeOut || item.timeOut || item.requested_time_out || '-',
                filedBy: item.filedBy || item.filed_by || 'Employee',
                status: item.status || 'Pending',
                createdAt: item.createdAt || item.created_at || new Date().toISOString()
            };
        });

        function getFlaggedAttendanceRecords() {
            const records = getAttendanceRecords();
            return records.filter(function (row) {
                const noLog = row.status === 'No Log-in' || row.status === 'Absent';
                const late = row.status === 'Late';
                const incomplete = !row.timeIn || row.timeIn === '-' || !row.timeOut || row.timeOut === '-';
                return noLog || late || incomplete;
            }).map(function (row) {
                const flags = [];
                if (row.status === 'Late') flags.push('Late');
                if (row.status === 'No Log-in' || row.status === 'Absent') flags.push('Absent / No Log-in');
                if (!row.timeIn || row.timeIn === '-' || !row.timeOut || row.timeOut === '-') flags.push('Incomplete Log');

                return {
                    employee: row.employee || 'N/A',
                    department: row.department || 'Unknown',
                    timeIn: row.timeIn || '-',
                    timeOut: row.timeOut || '-',
                    flags: flags.join(', ')
                };
            });
        }

        function nextRequestId() {
            const numericIds = requests
                .map(function (item) {
                    const parsed = String(item.id || '').match(/CR-(\d+)/i);
                    return parsed ? Number(parsed[1]) : 0;
                })
                .filter(function (value) {
                    return value > 0;
                });

            const max = numericIds.length ? Math.max.apply(null, numericIds) : 1000;
            return 'CR-' + String(max + 1);
        }

        function render() {
            const flaggedRecords = getFlaggedAttendanceRecords();
            const pendingCount = requests.filter(function (item) {
                return item.status === 'Pending' || item.status === 'For Review';
            }).length;
            const approvedCount = requests.filter(function (item) {
                return item.status === 'Approved';
            }).length;

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 corr-req-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h6 class="mb-0"><i class="fas fa-triangle-exclamation text-warning me-2"></i>Review Attendance Exception</h6>',
                '    <span class="badge bg-warning-subtle text-warning">' + flaggedRecords.length + ' Flagged</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle corr-req-table">',
                '      <thead><tr><th>Employee</th><th>Department</th><th>Time In</th><th>Time Out</th><th>Flag</th></tr></thead>',
                '      <tbody>',
                flaggedRecords.length
                    ? flaggedRecords.map(function (row) {
                        return '<tr>' +
                            '<td>' + row.employee + '</td>' +
                            '<td>' + row.department + '</td>' +
                            '<td>' + row.timeIn + '</td>' +
                            '<td>' + row.timeOut + '</td>' +
                            '<td><span class="corr-flag-text">' + row.flags + '</span></td>' +
                            '</tr>';
                    }).join('')
                    : '<tr><td colspan="5" class="text-center text-muted py-4">No attendance exceptions found.</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm mb-3 corr-req-submodule">',
                '  <div class="card-header bg-white"><h6 class="mb-0"><i class="fas fa-pen-to-square text-primary me-2"></i>Request Attendance Correction</h6></div>',
                '  <div class="card-body">',
                '    <div class="row g-2">',
                '      <div class="col-lg-3"><select id="corrFiledBy" class="form-select"><option value="Employee">Employee</option><option value="Supervisor">Supervisor</option></select></div>',
                '      <div class="col-lg-3"><input id="corrEmployee" class="form-control" placeholder="Employee name"></div>',
                '      <div class="col-lg-3"><input id="corrRequestedIn" class="form-control" placeholder="Requested Time In (e.g. 08:00 AM)"></div>',
                '      <div class="col-lg-3"><input id="corrRequestedOut" class="form-control" placeholder="Requested Time Out (e.g. 05:00 PM)"></div>',
                '      <div class="col-lg-8"><input id="corrIssue" class="form-control" placeholder="Reason / issue"></div>',
                '      <div class="col-lg-4"><button id="corrAddBtn" class="btn btn-primary w-100">Submit Correction Request</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm mb-3 corr-req-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h6 class="mb-0"><i class="fas fa-user-check text-success me-2"></i>Approve/Reject Correction</h6>',
                '    <span class="badge bg-info-subtle text-info">' + pendingCount + ' For Department Head</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle corr-req-table">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Issue</th><th>Requested In</th><th>Requested Out</th><th>Filed By</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                requests.map(function (item) {
                    const badge = item.status === 'Applied'
                        ? 'bg-primary-subtle text-primary'
                        : item.status === 'Approved'
                            ? 'bg-success-subtle text-success'
                            : item.status === 'Rejected'
                                ? 'bg-danger-subtle text-danger'
                                : 'bg-warning-subtle text-warning';

                    const canDecide = item.status === 'Pending' || item.status === 'For Review';

                    return '<tr>' +
                        '<td>' + item.id + '</td>' +
                        '<td>' + item.employee + '</td>' +
                        '<td><span class="corr-issue-text">' + item.issue + '</span></td>' +
                        '<td>' + (item.requestedTimeIn || '-') + '</td>' +
                        '<td>' + (item.requestedTimeOut || '-') + '</td>' +
                        '<td>' + item.filedBy + '</td>' +
                        '<td><span class="badge ' + badge + '">' + item.status + '</span></td>' +
                        '<td class="corr-actions">' +
                            (canDecide
                                ? '<button class="btn btn-sm btn-outline-success" data-action="approve" data-id="' + item.id + '">Approve</button><button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                                : '<span class="text-muted small">No Action</span>') +
                        '</td>' +
                        '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm corr-req-submodule">',
                '  <div class="card-body d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">',
                '    <div>',
                '      <h6 class="mb-1"><i class="fas fa-arrows-rotate text-primary me-2"></i>Update Attendance Record</h6>',
                '      <p class="text-muted mb-0">Apply approved corrections back into the attendance system.</p>',
                '    </div>',
                '    <div class="d-flex align-items-center gap-2">',
                '      <span class="badge bg-success-subtle text-success">' + approvedCount + ' Approved</span>',
                '      <button id="corrApplyApprovedBtn" class="btn btn-outline-primary">Apply Approved Changes</button>',
                '    </div>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('corrAddBtn');
            if (addButton) {
                addButton.addEventListener('click', function () {
                    const filedBy = (document.getElementById('corrFiledBy').value || 'Employee').trim();
                    const employee = (document.getElementById('corrEmployee').value || '').trim();
                    const issue = (document.getElementById('corrIssue').value || '').trim();
                    const requestedIn = (document.getElementById('corrRequestedIn').value || '-').trim();
                    const requestedOut = (document.getElementById('corrRequestedOut').value || '-').trim();

                    if (!employee || !issue) {
                        showModal({
                            modalId: 'correctionRequestsModal',
                            title: 'Incomplete Request',
                            message: 'Enter employee name and issue before submitting a correction request.'
                        });
                        return;
                    }

                    requests.unshift({
                        id: nextRequestId(),
                        employee: employee,
                        department: 'Unknown',
                        issue: issue,
                        requestedTimeIn: requestedIn || '-',
                        requestedTimeOut: requestedOut || '-',
                        filedBy: filedBy,
                        status: 'Pending',
                        createdAt: new Date().toISOString()
                    });

                    setStorageList('hospitalHrCorrectionRequests', requests);
                    render();

                    showModal({
                        modalId: 'correctionRequestsModal',
                        title: 'Correction Request Submitted',
                        message: 'Correction request for ' + employee + ' is now pending department head decision.'
                    });
                });
            }

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = this.getAttribute('data-action');
                    const id = this.getAttribute('data-id');
                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';

                    requests = requests.map(function (item) {
                        if (item.id === id) {
                            return Object.assign({}, item, { status: nextStatus });
                        }
                        return item;
                    });

                    setStorageList('hospitalHrCorrectionRequests', requests);
                    render();

                    showModal({
                        modalId: 'correctionRequestsModal',
                        title: nextStatus === 'Approved' ? 'Correction Approved' : 'Correction Rejected',
                        message: 'Request ' + id + ' is now marked as ' + nextStatus + '.'
                    });
                });
            });

            const applyApprovedButton = document.getElementById('corrApplyApprovedBtn');
            if (applyApprovedButton) {
                applyApprovedButton.addEventListener('click', function () {
                    const approved = requests.filter(function (item) {
                        return item.status === 'Approved';
                    });

                    if (!approved.length) {
                        showModal({
                            modalId: 'correctionRequestsModal',
                            title: 'No Approved Corrections',
                            message: 'Approve at least one correction request before applying updates.'
                        });
                        return;
                    }

                    let records = getAttendanceRecords();
                    approved.forEach(function (request) {
                        records = records.map(function (row) {
                            if (row.employee !== request.employee) return row;

                            const updated = Object.assign({}, row);
                            if (request.requestedTimeIn && request.requestedTimeIn !== '-') {
                                updated.timeIn = request.requestedTimeIn;
                            }
                            if (request.requestedTimeOut && request.requestedTimeOut !== '-') {
                                updated.timeOut = request.requestedTimeOut;
                            }

                            if (updated.timeIn && updated.timeIn !== '-') {
                                updated.status = 'Present';
                            }

                            return updated;
                        });
                    });

                    setAttendanceRecords(records);
                    requests = requests.map(function (item) {
                        if (item.status === 'Approved') {
                            return Object.assign({}, item, { status: 'Applied' });
                        }
                        return item;
                    });
                    setStorageList('hospitalHrCorrectionRequests', requests);

                    showModal({
                        modalId: 'correctionRequestsModal',
                        title: 'Attendance Updated',
                        message: 'Approved correction changes were applied to attendance records.'
                    });
                    render();
                });
            }
        }

        render();
    };

    // Helper Functions
    function ensureModalHost(modalId) {
        if (document.getElementById(modalId)) return;

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="' + modalId + 'Title"></h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="' + modalId + 'Body"></div>',
            '      <div class="modal-footer" id="' + modalId + 'Footer"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showModal(config) {
        const modalEl = document.getElementById(config.modalId);
        const titleEl = document.getElementById(config.modalId + 'Title');
        const bodyEl = document.getElementById(config.modalId + 'Body');
        const footerEl = document.getElementById(config.modalId + 'Footer');
        
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !window.bootstrap) return;

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (config.onConfirm) {
            const confirmBtn = document.getElementById('confirmAction') || document.getElementById('confirmExport');
            if (confirmBtn) {
                confirmBtn.addEventListener('click', function () {
                    config.onConfirm(modal);
                }, { once: true });
            }
        }
    }

})(window.HRSubmodules);

// Initialize submodule switching
(function () {
    const container = document.getElementById('tasSubmoduleContainer');
    const buttons = document.querySelectorAll('button[data-submodule]');
    
    const rendererMap = {
        'Attendance Monitoring': 'renderAttendanceMonitoring',
        'Attendance Validation': 'renderAttendanceValidation',
        'Attendance Reports': 'renderAttendanceReports',
        'Correction Requests': 'renderCorrectionRequests'
    };

    function setActiveButton(activeName) {
        buttons.forEach(button => {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) return;

        const rendererName = rendererMap[submoduleName];
        const renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            renderSubmodule(this.getAttribute('data-submodule'));
        });
    });

    // Start with Attendance Monitoring
    renderSubmodule('Attendance Monitoring');
})();