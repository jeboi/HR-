/* Consolidated hmo-benefits-administration module scripts */

/* Source: submodules/benefits-claims.js */
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const BENEFITS_KEY = 'hospitalHrBenefitsRecords';

    function ensureBenefitsClaimsModalHost() {
        if (document.getElementById('benefitsClaimsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="benefitsClaimsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="benefitsClaimsModalTitle">Benefits Claims</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="benefitsClaimsModalBody"></div>',
            '      <div class="modal-footer" id="benefitsClaimsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showBenefitsClaimsModal(config) {
        const modalEl = document.getElementById('benefitsClaimsModal');
        const titleEl = document.getElementById('benefitsClaimsModalTitle');
        const bodyEl = document.getElementById('benefitsClaimsModalBody');
        const footerEl = document.getElementById('benefitsClaimsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultBenefits() {
        return [
            { id: 'BEN-6001', employee: 'Anna Santos', hmoPlan: 'Premium Plus', benefitsType: 'Medical', coverage: 250000, claimAmount: 0, claimStatus: 'None', enrolled: true },
            { id: 'BEN-6002', employee: 'Jude Molina', hmoPlan: 'Standard Care', benefitsType: 'Medical', coverage: 180000, claimAmount: 12000, claimStatus: 'Approved', enrolled: true },
            { id: 'BEN-6003', employee: 'Leah Gomez', hmoPlan: 'Basic Care', benefitsType: 'Medical', coverage: 120000, claimAmount: 8000, claimStatus: 'Pending', enrolled: true }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderBenefitsClaims = function (container) {
        ensureBenefitsClaimsModalHost();

        let records = getStorageList(BENEFITS_KEY, defaultBenefits);

        function render() {
            const pendingClaims = records.filter(function (item) { return item.claimStatus === 'Pending'; }).length;
            const approvedClaims = records.filter(function (item) { return item.claimStatus === 'Approved'; }).length;

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 benefits-claims-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-file-medical text-primary me-2"></i>Submit Benefits Claim</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-4"><select id="benefitsClaimEmployee" class="form-select">',
                records.map(function (item) {
                    return '<option value="' + item.id + '">' + item.employee + ' (' + item.id + ')</option>';
                }).join(''),
                '      </select></div>',
                '      <div class="col-md-4"><input id="benefitsClaimAmount" type="number" min="1" class="form-control" placeholder="Claim Amount"></div>',
                '      <div class="col-md-4"><button id="benefitsClaimSubmit" class="btn btn-primary w-100">Submit Claim</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-6"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Pending Claims</p><h5 class="mb-0">' + pendingClaims + '</h5></div></div>',
                '  <div class="col-md-6"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Claims</p><h5 class="mb-0">' + approvedClaims + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-receipt text-primary me-2"></i>Benefits Claims Queue</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Plan</th><th>Claim Amount</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    const badge = item.claimStatus === 'Approved'
                        ? 'bg-success-subtle text-success'
                        : item.claimStatus === 'Pending'
                            ? 'bg-warning-subtle text-warning'
                            : 'bg-secondary-subtle text-secondary';
                    const disabled = item.claimStatus !== 'Pending' ? ' disabled' : '';

                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.hmoPlan + '</td>'
                        + '<td>₱' + Number(item.claimAmount || 0).toLocaleString() + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.claimStatus + '</span></td>'
                        + '<td><button class="btn btn-sm btn-outline-success" data-action="approve" data-id="' + item.id + '"' + disabled + '>Approve</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const submitButton = document.getElementById('benefitsClaimSubmit');
            if (submitButton) {
                submitButton.addEventListener('click', function () {
                    const selectedId = document.getElementById('benefitsClaimEmployee').value;
                    const amount = Number(document.getElementById('benefitsClaimAmount').value || 0);
                    if (!selectedId || !amount) {
                        showBenefitsClaimsModal({
                            title: 'Incomplete Claim',
                            message: 'Select an employee and enter a valid claim amount.'
                        });
                        return;
                    }

                    records = records.map(function (item) {
                        if (item.id !== selectedId) {
                            return item;
                        }
                        return {
                            id: item.id,
                            employee: item.employee,
                            hmoPlan: item.hmoPlan,
                            benefitsType: item.benefitsType,
                            coverage: item.coverage,
                            claimAmount: amount,
                            claimStatus: 'Pending',
                            enrolled: item.enrolled
                        };
                    });

                    setStorageList(BENEFITS_KEY, records);
                    render();

                    const filed = records.find(function (item) { return item.id === selectedId; });
                    showBenefitsClaimsModal({
                        title: 'Claim Submitted',
                        message: 'Claim for ' + (filed ? filed.employee : selectedId) + ' was submitted successfully.'
                    });
                });
            }

            container.querySelectorAll('button[data-action="approve"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showBenefitsClaimsModal({
                        title: 'Approve Claim',
                        message: 'Approve claim for ' + target.employee + ' (' + target.id + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-success" id="confirmBenefitsClaimApproveBtn">Approve</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmBenefitsClaimApproveBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        hmoPlan: item.hmoPlan,
                                        benefitsType: item.benefitsType,
                                        coverage: item.coverage,
                                        claimAmount: item.claimAmount,
                                        claimStatus: 'Approved',
                                        enrolled: item.enrolled
                                    };
                                });
                                setStorageList(BENEFITS_KEY, records);
                                modal.hide();
                                render();

                                showBenefitsClaimsModal({
                                    title: 'Claim Approved',
                                    message: 'Claim for ' + target.employee + ' is now approved.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

/* Source: submodules/benefits-management.js */
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const BENEFITS_KEY = 'hospitalHrBenefitsRecords';

    function ensureBenefitsManagementModalHost() {
        if (document.getElementById('benefitsManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="benefitsManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="benefitsManagementModalTitle">Benefits Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="benefitsManagementModalBody"></div>',
            '      <div class="modal-footer" id="benefitsManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showBenefitsManagementModal(config) {
        const modalEl = document.getElementById('benefitsManagementModal');
        const titleEl = document.getElementById('benefitsManagementModalTitle');
        const bodyEl = document.getElementById('benefitsManagementModalBody');
        const footerEl = document.getElementById('benefitsManagementModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultBenefits() {
        return [
            { id: 'BEN-6001', employee: 'Anna Santos', hmoPlan: 'Premium Plus', benefitsType: 'Medical', coverage: 250000, claimAmount: 0, claimStatus: 'None', enrolled: true },
            { id: 'BEN-6002', employee: 'Jude Molina', hmoPlan: 'Standard Care', benefitsType: 'Medical', coverage: 180000, claimAmount: 12000, claimStatus: 'Approved', enrolled: true },
            { id: 'BEN-6003', employee: 'Leah Gomez', hmoPlan: 'Basic Care', benefitsType: 'Medical', coverage: 120000, claimAmount: 8000, claimStatus: 'Pending', enrolled: true }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderBenefitsManagement = function (container) {
        ensureBenefitsManagementModalHost();

        let records = getStorageList(BENEFITS_KEY, defaultBenefits);

        function render() {
            const totalCoverage = records.reduce(function (sum, item) { return sum + Number(item.coverage || 0); }, 0);

            container.innerHTML = [
                '<div class="row g-3 mb-3 benefits-management-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Benefit Profiles</p><h5 class="mb-0">' + records.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Coverage</p><h5 class="mb-0">₱' + totalCoverage.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Medical Plans</p><h5 class="mb-0">' + records.filter(function (item) { return item.benefitsType === 'Medical'; }).length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-shield-heart text-primary me-2"></i>Benefits Management</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Plan</th><th>Coverage</th><th>Benefit Type</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.hmoPlan + '</td>'
                        + '<td>₱' + Number(item.coverage || 0).toLocaleString() + '</td>'
                        + '<td>' + item.benefitsType + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="upgrade" data-id="' + item.id + '">+₱10,000</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="upgrade"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showBenefitsManagementModal({
                        title: 'Upgrade Coverage',
                        message: 'Increase coverage for ' + target.employee + ' by ₱10,000?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmBenefitsUpgradeBtn">Upgrade</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmBenefitsUpgradeBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        hmoPlan: item.hmoPlan,
                                        benefitsType: item.benefitsType,
                                        coverage: Number(item.coverage || 0) + 10000,
                                        claimAmount: item.claimAmount,
                                        claimStatus: item.claimStatus,
                                        enrolled: item.enrolled
                                    };
                                });

                                setStorageList(BENEFITS_KEY, records);
                                modal.hide();
                                render();

                                showBenefitsManagementModal({
                                    title: 'Coverage Updated',
                                    message: 'Coverage upgrade was applied for ' + target.employee + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

/* Source: submodules/benefits-reports.js */
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const BENEFITS_KEY = 'hospitalHrBenefitsRecords';

    function defaultBenefits() {
        return [
            { id: 'BEN-6001', employee: 'Anna Santos', hmoPlan: 'Premium Plus', benefitsType: 'Medical', coverage: 250000, claimAmount: 0, claimStatus: 'None', enrolled: true },
            { id: 'BEN-6002', employee: 'Jude Molina', hmoPlan: 'Standard Care', benefitsType: 'Medical', coverage: 180000, claimAmount: 12000, claimStatus: 'Approved', enrolled: true },
            { id: 'BEN-6003', employee: 'Leah Gomez', hmoPlan: 'Basic Care', benefitsType: 'Medical', coverage: 120000, claimAmount: 8000, claimStatus: 'Pending', enrolled: true }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    registry.renderBenefitsReports = function (container) {
        const records = getStorageList(BENEFITS_KEY, defaultBenefits);

        const totalCoverage = records.reduce(function (sum, item) { return sum + Number(item.coverage || 0); }, 0);
        const totalClaims = records.reduce(function (sum, item) { return sum + Number(item.claimAmount || 0); }, 0);
        const approvedClaims = records.filter(function (item) { return item.claimStatus === 'Approved'; }).length;

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 benefits-reports-submodule"><h6 class="mb-0"><i class="fas fa-chart-pie text-primary me-2"></i>Benefits Reports</h6></div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Profiles</p><h5 class="mb-0">' + records.length + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Coverage</p><h5 class="mb-0">₱' + totalCoverage.toLocaleString() + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Claims</p><h5 class="mb-0">₱' + totalClaims.toLocaleString() + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Claims</p><h5 class="mb-0">' + approvedClaims + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-table-list text-primary me-2"></i>Benefits Utilization Report</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>ID</th><th>Employee</th><th>Plan</th><th>Coverage</th><th>Claim Amount</th><th>Claim Status</th></tr></thead>',
            '      <tbody>',
            records.map(function (item) {
                const badge = item.claimStatus === 'Approved'
                    ? 'bg-success-subtle text-success'
                    : item.claimStatus === 'Pending'
                        ? 'bg-warning-subtle text-warning'
                        : 'bg-secondary-subtle text-secondary';
                return '<tr>'
                    + '<td>' + item.id + '</td>'
                    + '<td>' + item.employee + '</td>'
                    + '<td>' + item.hmoPlan + '</td>'
                    + '<td>₱' + Number(item.coverage || 0).toLocaleString() + '</td>'
                    + '<td>₱' + Number(item.claimAmount || 0).toLocaleString() + '</td>'
                    + '<td><span class="badge ' + badge + '">' + item.claimStatus + '</span></td>'
                    + '</tr>';
            }).join(''),
            '      </tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };
})(window.HRSubmodules);

/* Source: submodules/hmo-enrollment.js */
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const BENEFITS_KEY = 'hospitalHrBenefitsRecords';

    function ensureHmoEnrollmentModalHost() {
        if (document.getElementById('hmoEnrollmentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="hmoEnrollmentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="hmoEnrollmentModalTitle">HMO Enrollment</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="hmoEnrollmentModalBody"></div>',
            '      <div class="modal-footer" id="hmoEnrollmentModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showHmoEnrollmentInfo(title, message) {
        const modalEl = document.getElementById('hmoEnrollmentModal');
        const titleEl = document.getElementById('hmoEnrollmentModalTitle');
        const bodyEl = document.getElementById('hmoEnrollmentModalBody');
        const footerEl = document.getElementById('hmoEnrollmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function defaultBenefits() {
        return [
            { id: 'BEN-6001', employee: 'Anna Santos', hmoPlan: 'Premium Plus', benefitsType: 'Medical', coverage: 250000, claimAmount: 0, claimStatus: 'None', enrolled: true },
            { id: 'BEN-6002', employee: 'Jude Molina', hmoPlan: 'Standard Care', benefitsType: 'Medical', coverage: 180000, claimAmount: 12000, claimStatus: 'Approved', enrolled: true },
            { id: 'BEN-6003', employee: 'Leah Gomez', hmoPlan: 'Basic Care', benefitsType: 'Medical', coverage: 120000, claimAmount: 8000, claimStatus: 'Pending', enrolled: true }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderHmoEnrollment = function (container) {
        ensureHmoEnrollmentModalHost();

        let records = getStorageList(BENEFITS_KEY, defaultBenefits);

        function render() {
            const enrolledCount = records.filter(function (item) { return item.enrolled === true; }).length;

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 hmo-enrollment-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-notes-medical text-primary me-2"></i>HMO Enrollment</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="hmoEmp" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-3"><input id="hmoPlan" class="form-control" placeholder="Plan"></div>',
                '      <div class="col-md-3"><input id="hmoCoverage" type="number" min="1" class="form-control" placeholder="Coverage"></div>',
                '      <div class="col-md-3"><button id="hmoEnrollBtn" class="btn btn-primary w-100">Enroll</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-6"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Profiles</p><h5 class="mb-0">' + records.length + '</h5></div></div>',
                '  <div class="col-md-6"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Active Enrollments</p><h5 class="mb-0">' + enrolledCount + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-hospital-user text-primary me-2"></i>Enrollment Registry</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Plan</th><th>Coverage</th><th>Status</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    const badge = item.enrolled === true ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.hmoPlan + '</td>'
                        + '<td>₱' + Number(item.coverage).toLocaleString() + '</td>'
                        + '<td><span class="badge ' + badge + '">' + (item.enrolled ? 'Enrolled' : 'Inactive') + '</span></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const enrollButton = document.getElementById('hmoEnrollBtn');
            if (!enrollButton) {
                return;
            }

            enrollButton.addEventListener('click', function () {
                const employee = (document.getElementById('hmoEmp').value || '').trim();
                const hmoPlan = (document.getElementById('hmoPlan').value || '').trim();
                const coverage = Number(document.getElementById('hmoCoverage').value || 0);

                if (!employee || !hmoPlan || !coverage) {
                    showHmoEnrollmentInfo('Incomplete Enrollment', 'Employee name, plan, and coverage are required.');
                    return;
                }

                const nextId = 'BEN-' + (6000 + records.length + 1);
                records.unshift({
                    id: nextId,
                    employee: employee,
                    hmoPlan: hmoPlan,
                    benefitsType: 'Medical',
                    coverage: coverage,
                    claimAmount: 0,
                    claimStatus: 'None',
                    enrolled: true
                });

                setStorageList(BENEFITS_KEY, records);
                render();
                showHmoEnrollmentInfo('Enrollment Saved', 'HMO enrollment ' + nextId + ' for ' + employee + ' was created.');
            });
        }

        render();
    };
})(window.HRSubmodules);

