/* Consolidated competency-management module scripts */

/* Source: submodules/competency-assessment.js */
/**
 * Competency Assessment Submodule
 * Professional Grading & Proficiency Standards
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompetencyEvals';

    const getAssessments = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Data
        return [
            { id: "CMP-001", name: "Dr. Aris Thorne", area: "Clinical Expertise", score: 95, status: "Certified" },
            { id: "CMP-002", name: "Sarah Jenkins", area: "Patient Safety", score: 88, status: "Certified" },
            { id: "CMP-003", name: "James Miller", area: "Technical Ops", score: 72, status: "Training Required" }
        ];
    };

    function ensureCompetencyAssessmentModalHost() {
        if (document.getElementById('competencyAssessmentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="competencyAssessmentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="competencyAssessmentModalTitle">Competency Assessment</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="competencyAssessmentModalBody"></div>',
            '      <div class="modal-footer" id="competencyAssessmentModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    window.HRSubmodules.renderCompetencyAssessment = function (container) {
        ensureCompetencyAssessmentModalHost();

        const data = getAssessments();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-chart-line text-success me-2"></i>Competency Assessment</h6>
                        <small class="text-muted">Measure staff proficiency against healthcare benchmarks</small>
                    </div>
                    <button class="btn btn-outline-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.startNewAssessment()">
                        <i class="fas fa-clipboard-check me-1"></i> New Assessment
                    </button>
                </div>

                <div class="row g-3">
                    ${data.map(item => `
                        <div class="col-md-6 col-xl-4">
                            <div class="comp-card bg-white p-3 border rounded-3 shadow-sm h-100">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="text-truncate" style="max-width: 70%;">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-primary">${item.area}</div>
                                    </div>
                                    <span class="comp-badge ${item.status.toLowerCase().replace(/\s+/g, '-')}">${item.status}</span>
                                </div>

                                <div class="mb-2 d-flex justify-content-between align-items-center">
                                    <span class="small text-muted">Proficiency Score</span>
                                    <span class="fw-bold ${item.score >= 80 ? 'text-success' : 'text-warning'}">${item.score}%</span>
                                </div>
                                
                                <div class="progress mb-3" style="height: 8px; border-radius: 10px;">
                                    <div class="progress-bar ${item.score >= 80 ? 'bg-success' : 'bg-warning'}" 
                                         role="progressbar" style="width: ${item.score}%"></div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="extra-small text-muted">ID: ${item.id}</span>
                                    <button class="btn btn-link btn-sm p-0 text-decoration-none extra-small" onclick="window.HRSubmodules.updateCompScore('${item.id}')">Update Score</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.startNewAssessment = function() {
        const modalEl = document.getElementById('competencyAssessmentModal');
        const titleEl = document.getElementById('competencyAssessmentModalTitle');
        const bodyEl = document.getElementById('competencyAssessmentModalBody');
        const footerEl = document.getElementById('competencyAssessmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'New Competency Assessment';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="assessmentStaffName" placeholder="e.g. John Doe">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Assessment Area</label>',
            '  <input type="text" class="form-control form-control-sm" id="assessmentArea" placeholder="e.g. Clinical, Ethics">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="assessmentCreateBtn">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('assessmentCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('assessmentStaffName').value || '').trim();
                const area = (document.getElementById('assessmentArea').value || '').trim();
                if (!name || !area) {
                    return;
                }

                let data = getAssessments();
                data.unshift({
                    id: 'CMP-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    area: area,
                    score: 0,
                    status: 'Pending'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCompetencyAssessment(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.updateCompScore = function(id) {
        let data = getAssessments();
        const idx = data.findIndex(function (i) { return i.id === id; });
        if (idx === -1) {
            return;
        }

        const modalEl = document.getElementById('competencyAssessmentModal');
        const titleEl = document.getElementById('competencyAssessmentModalTitle');
        const bodyEl = document.getElementById('competencyAssessmentModalBody');
        const footerEl = document.getElementById('competencyAssessmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Update Competency Score';
        bodyEl.innerHTML = [
            '<p class="mb-2">Employee: <strong>' + data[idx].name + '</strong></p>',
            '<label class="form-label small mb-1">Score (0-100)</label>',
            '<input type="number" min="0" max="100" class="form-control form-control-sm" id="assessmentScoreInput" value="' + data[idx].score + '">'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="assessmentScoreSaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('assessmentScoreSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const score = Number(document.getElementById('assessmentScoreInput').value);
                if (Number.isNaN(score) || score < 0 || score > 100) {
                    return;
                }

                data[idx].score = Math.round(score);
                data[idx].status = data[idx].score >= 75 ? 'Certified' : 'Training Required';
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCompetencyAssessment(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

})();

/* Source: submodules/competency-gap-analysis.js */
/**
 * Competency Gap Analysis Submodule
 * Identifies training needs by comparing Actual vs. Required skills
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompetencyGaps';

    const getGaps = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Baseline Data
        return [
            { id: "GAP-001", name: "Dr. Aris Thorne", skill: "Robotic Surgery", required: 90, actual: 85, status: "Critical" },
            { id: "GAP-002", name: "Sarah Jenkins", skill: "Disaster Response", required: 95, actual: 95, status: "Optimized" },
            { id: "GAP-003", name: "James Miller", skill: "Advanced Imaging", required: 80, actual: 60, status: "High Risk" }
        ];
    };

    function ensureGapAnalysisModalHost() {
        if (document.getElementById('competencyGapModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="competencyGapModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="competencyGapModalTitle">Gap Analysis</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="competencyGapModalBody"></div>',
            '      <div class="modal-footer" id="competencyGapModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    window.HRSubmodules.renderCompetencyGapAnalysis = function (container) {
        ensureGapAnalysisModalHost();

        const gaps = getGaps();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-microscope text-danger me-2"></i>Gap Analysis Matrix</h6>
                        <small class="text-muted">Strategic comparison of current talent vs. institutional requirements</small>
                    </div>
                    <button class="btn btn-dark btn-sm px-3 shadow-sm" onclick="window.HRSubmodules.analyzeNewSkill()">
                        <i class="fas fa-search-plus me-1"></i> New Analysis
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-gap-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Staff & Skill</th>
                                <th style="width: 35%">Proficiency Variance</th>
                                <th style="width: 20%">Gap Score</th>
                                <th class="text-end pe-4" style="width: 20%">Priority</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${gaps.map(item => {
                                const variance = item.actual - item.required;
                                const isNegative = variance < 0;
                                return `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">${item.skill}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="small text-muted" style="width: 30px;">${item.actual}%</span>
                                            <div class="progress flex-grow-1" style="height: 6px;">
                                                <div class="progress-bar ${isNegative ? 'bg-danger' : 'bg-success'}" 
                                                     style="width: ${item.actual}%"></div>
                                            </div>
                                            <span class="small text-muted" style="width: 30px;">${item.required}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="fw-bold ${isNegative ? 'text-danger' : 'text-success'}">
                                            ${isNegative ? variance : '+' + variance}%
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="priority-pill ${item.status.toLowerCase().replace(' ', '-')}">
                                            ${item.status}
                                        </span>
                                    </td>
                                </tr>
                            `}).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.analyzeNewSkill = function() {
        const modalEl = document.getElementById('competencyGapModal');
        const titleEl = document.getElementById('competencyGapModalTitle');
        const bodyEl = document.getElementById('competencyGapModalBody');
        const footerEl = document.getElementById('competencyGapModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'New Gap Analysis';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="gapStaffName" placeholder="e.g. Jane Doe">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Skill to Analyze</label>',
            '  <input type="text" class="form-control form-control-sm" id="gapSkillName" placeholder="e.g. Robotic Surgery">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Required Proficiency (%)</label>',
            '  <input type="number" min="0" max="100" class="form-control form-control-sm" id="gapRequiredScore" value="90">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-dark" id="gapCreateBtn">Analyze</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('gapCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('gapStaffName').value || '').trim();
                const skill = (document.getElementById('gapSkillName').value || '').trim();
                const required = Number(document.getElementById('gapRequiredScore').value);
                if (!name || !skill || Number.isNaN(required) || required < 0 || required > 100) {
                    return;
                }

                let gaps = getGaps();
                gaps.unshift({
                    id: 'GAP-' + Math.floor(100 + Math.random() * 899),
                    name: name,
                    skill: skill,
                    required: Math.round(required),
                    actual: 0,
                    status: 'High Risk'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(gaps));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCompetencyGapAnalysis(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };
})();

/* Source: submodules/skill-inventory.js */
/**
 * Skill Inventory Submodule
 * Professional Medical & Administrative Talent Database
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrSkillInventory';

    const getSkills = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        return [
            { id: "SKL-001", name: "Dr. Aris Thorne", category: "Clinical", skills: ["Surgery", "ER", "Trauma"], level: "Expert" },
            { id: "SKL-002", name: "Sarah Jenkins", category: "Leadership", skills: ["Team Mgmt", "Nursing Ops"], level: "Advanced" },
            { id: "SKL-003", name: "James Miller", category: "Technical", skills: ["Radiology", "MRI"], level: "Intermediate" }
        ];
    };

    function ensureSkillInventoryModalHost() {
        if (document.getElementById('skillInventoryModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="skillInventoryModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="skillInventoryModalTitle">Skill Inventory</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="skillInventoryModalBody"></div>',
            '      <div class="modal-footer" id="skillInventoryModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showSkillInventoryInfo(title, message) {
        const modalEl = document.getElementById('skillInventoryModal');
        const titleEl = document.getElementById('skillInventoryModalTitle');
        const bodyEl = document.getElementById('skillInventoryModalBody');
        const footerEl = document.getElementById('skillInventoryModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderSkillInventory = function (container) {
        ensureSkillInventoryModalHost();

        const inventory = getSkills();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-info">
                        <h6 class="fw-bold mb-0 text-dark">Talent Inventory</h6>
                        <small class="text-muted">Specialized medical and technical competencies</small>
                    </div>
                    <button class="btn btn-sm btn-primary px-3 shadow-sm" onclick="window.HRSubmodules.addNewSkillEntry()">
                        <i class="fas fa-plus me-2"></i>Add Talent
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-skill-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 30%">Staff Member</th>
                                <th style="width: 45%">Competencies</th>
                                <th class="text-end pe-4" style="width: 25%">Proficiency</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${inventory.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate">${item.name}</div>
                                        <div class="text-muted extra-small">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-1">
                                            ${item.skills.map(s => `<span class="skill-tag">${s}</span>`).join('')}
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="level-badge ${item.level.toLowerCase()}">${item.level}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewSkillEntry = function() {
        const modalEl = document.getElementById('skillInventoryModal');
        const titleEl = document.getElementById('skillInventoryModalTitle');
        const bodyEl = document.getElementById('skillInventoryModalBody');
        const footerEl = document.getElementById('skillInventoryModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add Talent Entry';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="skillEntryName" placeholder="e.g. John Doe">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Category</label>',
            '  <input type="text" class="form-control form-control-sm" id="skillEntryCategory" value="General">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Skills (comma separated)</label>',
            '  <input type="text" class="form-control form-control-sm" id="skillEntrySkills" placeholder="e.g. Triage, ER, Documentation">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="skillEntrySaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('skillEntrySaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const name = (document.getElementById('skillEntryName').value || '').trim();
                const category = (document.getElementById('skillEntryCategory').value || '').trim() || 'General';
                const skillsRaw = (document.getElementById('skillEntrySkills').value || '').trim();
                if (!name || !skillsRaw) {
                    return;
                }

                const inventory = getSkills();
                inventory.unshift({
                    id: 'SKL-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    category: category,
                    skills: skillsRaw.split(',').map(function (s) { return s.trim(); }).filter(Boolean),
                    level: 'Intermediate'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(inventory));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderSkillInventory(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showSkillInventoryInfo('Talent Added', name + ' was added to the skill inventory.');
            });
        }

        modal.show();
    };
})();

