/* Consolidated performance-management module scripts */

/* Source: submodules/evaluation-results.js */
/**
 * Evaluation Results Submodule
 * Final performance reporting and history
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrEvalResults';

    const getResults = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical Staff Evaluation History
        return [
            { id: "RES-2026-001", name: "Dr. Aris Thorne", period: "Q1 2026", finalScore: 94, outcome: "Permanent", remark: "Exceptional clinical precision." },
            { id: "RES-2026-002", name: "Sarah Jenkins", period: "Q1 2026", finalScore: 78, outcome: "Extended", remark: "Requires more administrative focus." },
            { id: "RES-2026-003", name: "James Miller", period: "Q1 2026", finalScore: 82, outcome: "Permanent", remark: "Technical skills meet hospital standards." }
        ];
    };

    function ensureEvaluationResultsModal() {
        if (document.getElementById('evaluationResultsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="evaluationResultsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="evaluationResultsModalTitle">Evaluation Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="evaluationResultsModalBody"></div>',
            '      <div class="modal-footer" id="evaluationResultsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    window.HRSubmodules.renderEvaluationResults = function (container) {
        ensureEvaluationResultsModal();

        const results = getResults();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm text-center">
                            <div class="text-muted small fw-bold text-uppercase">Avg. Hospital Score</div>
                            <h4 class="fw-bold text-primary mb-0">84.6%</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm text-center">
                            <div class="text-muted small fw-bold text-uppercase">Passing Rate</div>
                            <h4 class="fw-bold text-success mb-0">92%</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm d-flex align-items-center justify-content-center">
                            <button class="btn btn-sm btn-outline-dark" onclick="window.HRSubmodules.exportEvaluationReport()">
                                <i class="fas fa-file-pdf me-2"></i>Export Reports
                            </button>
                        </div>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-result-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Employee Details</th>
                                <th style="width: 15%">Review Period</th>
                                <th style="width: 15%">Final Score</th>
                                <th style="width: 15%">Outcome</th>
                                <th class="pe-4" style="width: 30%">HR Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${results.map(res => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${res.name}</div>
                                        <div class="extra-small text-muted">${res.id}</div>
                                    </td>
                                    <td class="text-secondary small">${res.period}</td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="fw-bold me-2 ${res.finalScore >= 80 ? 'text-success' : 'text-warning'}">${res.finalScore}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="outcome-pill ${res.outcome.toLowerCase()}">${res.outcome}</span>
                                    </td>
                                    <td class="pe-4">
                                        <div class="remark-text" title="${res.remark}">${res.remark}</div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.exportEvaluationReport = function () {
        const modalEl = document.getElementById('evaluationResultsModal');
        const titleEl = document.getElementById('evaluationResultsModalTitle');
        const bodyEl = document.getElementById('evaluationResultsModalBody');
        const footerEl = document.getElementById('evaluationResultsModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Export Evaluation Reports';
        bodyEl.innerHTML = '<p class="mb-0">Generate a printable copy of current evaluation results?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="evaluationExportConfirmBtn">Export</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const exportBtn = document.getElementById('evaluationExportConfirmBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', function () {
                window.print();
                modal.hide();
            });
        }

        modal.show();
    };

})();

/* Source: submodules/initial-kpi-setup.js */
/**
 * Initial KPI Setup Submodule
 * Defines performance targets for new staff
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrKpiSetup';

    const getKpis = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical KPI Defaults
        return [
            { id: "KPI-2026-01", name: "Dr. Aris Thorne", category: "Clinical", metric: "Patient Satisfaction Score", target: ">= 90%", status: "Approved" },
            { id: "KPI-2026-02", name: "Sarah Jenkins", category: "Administrative", metric: "Staff Retention Rate", target: ">= 85%", status: "Pending Approval" },
            { id: "KPI-2026-03", name: "James Miller", category: "Technical", metric: "Imaging Turnaround Time", target: "< 2 Hours", status: "Draft" }
        ];
    };

    function ensureKpiModalHost() {
        if (document.getElementById('kpiSetupModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="kpiSetupModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="kpiSetupModalTitle">KPI Setup</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="kpiSetupModalBody"></div>',
            '      <div class="modal-footer" id="kpiSetupModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showKpiInfo(title, message) {
        const modalEl = document.getElementById('kpiSetupModal');
        const titleEl = document.getElementById('kpiSetupModalTitle');
        const bodyEl = document.getElementById('kpiSetupModalBody');
        const footerEl = document.getElementById('kpiSetupModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderInitialKPISetup = function (container) {
        ensureKpiModalHost();

        const kpis = getKpis();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-primary me-2"></i>KPI Framework</h6>
                        <small class="text-muted">Establish baseline performance metrics for new personnel</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.createNewKpi()">
                        <i class="fas fa-plus me-1"></i> Define KPI
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Employee</th>
                                <th>Category</th>
                                <th>Metric & Target</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${kpis.map(kpi => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${kpi.name}</div>
                                        <div class="text-muted extra-small">${kpi.id}</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border">${kpi.category}</span>
                                    </td>
                                    <td>
                                        <div class="fw-medium text-primary">${kpi.metric}</div>
                                        <div class="small text-muted">Goal: ${kpi.target}</div>
                                    </td>
                                    <td>
                                        <span class="kpi-status-pill ${kpi.status.toLowerCase().replace(/\s+/g, '-')}">${kpi.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            <button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateKpiStatus('${kpi.id}', 'Approved')">Approve</button>
                                            <button class="btn btn-xs btn-outline-danger" onclick="window.HRSubmodules.deleteKpi('${kpi.id}')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateKpiStatus = function(id, status) {
        let kpis = getKpis();
        const idx = kpis.findIndex(k => k.id === id);
        if (idx !== -1) {
            const employeeName = kpis[idx].name;
            kpis[idx].status = status;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
            window.dispatchEvent(new Event('storage')); // Trigger Dashboard Update
            this.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
            showKpiInfo('KPI Updated', employeeName + ' KPI was marked as ' + status + '.');
        }
    };

    window.HRSubmodules.createNewKpi = function() {
        const modalEl = document.getElementById('kpiSetupModal');
        const titleEl = document.getElementById('kpiSetupModalTitle');
        const bodyEl = document.getElementById('kpiSetupModalBody');
        const footerEl = document.getElementById('kpiSetupModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Define New KPI';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Employee Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="kpiEmployeeName" placeholder="e.g. Sarah Jenkins">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Metric</label>',
            '  <input type="text" class="form-control form-control-sm" id="kpiMetric" placeholder="e.g. Case Resolution Time">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Target</label>',
            '  <input type="text" class="form-control form-control-sm" id="kpiTarget" value="TBD">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="kpiCreateBtn">Create KPI</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('kpiCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('kpiEmployeeName').value || '').trim();
                const metric = (document.getElementById('kpiMetric').value || '').trim();
                const target = (document.getElementById('kpiTarget').value || '').trim() || 'TBD';
                if (!name || !metric) {
                    return;
                }

                let kpis = getKpis();
                kpis.unshift({
                    id: 'KPI-2026-' + Math.floor(Math.random() * 1000),
                    name: name,
                    category: 'General',
                    metric: metric,
                    target: target,
                    status: 'Draft'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.deleteKpi = function(id) {
        const kpis = getKpis();
        const target = kpis.find(function (kpi) {
            return kpi.id === id;
        });
        if (!target) {
            return;
        }

        const modalEl = document.getElementById('kpiSetupModal');
        const titleEl = document.getElementById('kpiSetupModalTitle');
        const bodyEl = document.getElementById('kpiSetupModalBody');
        const footerEl = document.getElementById('kpiSetupModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Delete KPI';
        bodyEl.innerHTML = '<p class="mb-0">Remove KPI <strong>' + target.metric + '</strong> for ' + target.name + '?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-danger" id="kpiDeleteBtn">Delete</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('kpiDeleteBtn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                let filtered = getKpis().filter(function (kpi) {
                    return kpi.id !== id;
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

})();

/* Source: submodules/probation-evaluation.js */
/**
 * Probation Evaluation Submodule
 * Handles performance review for new medical and admin staff
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrProbationEvals';

    const getEvals = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Mock Data for Probationary Period
        return [
            { id: "EVL-901", name: "Dr. Aris Thorne", role: "Resident Physician", score: 92, status: "Recommended", date: "2026-03-05" },
            { id: "EVL-902", name: "Sarah Jenkins", role: "Head Nurse", score: 45, status: "Under Review", date: "2026-03-06" },
            { id: "EVL-903", name: "James Miller", role: "Radiology Tech", score: 0, status: "Pending", date: "-" }
        ];
    };

    function ensureProbationModalHost() {
        if (document.getElementById('probationEvalModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="probationEvalModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="probationEvalModalTitle">Probation Evaluation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="probationEvalModalBody"></div>',
            '      <div class="modal-footer" id="probationEvalModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showProbationInfo(title, message) {
        const modalEl = document.getElementById('probationEvalModal');
        const titleEl = document.getElementById('probationEvalModalTitle');
        const bodyEl = document.getElementById('probationEvalModalBody');
        const footerEl = document.getElementById('probationEvalModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderProbationEvaluation = function (container) {
        ensureProbationModalHost();

        const evals = getEvals();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-clipboard-check text-primary me-2"></i>Probationary Performance</h6>
                        <small class="text-muted">Monitor and evaluate new hire progress for regularization</small>
                    </div>
                    <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.addNewEvaluation()">
                        <i class="fas fa-user-plus me-1"></i> Start Evaluation
                    </button>
                </div>

                <div class="row g-3">
                    ${evals.map(evalItem => `
                        <div class="col-xl-4 col-md-6">
                            <div class="eval-card p-3 border rounded-3 bg-white h-100 shadow-sm">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark">${evalItem.name}</h6>
                                        <small class="text-primary">${evalItem.role}</small>
                                    </div>
                                    <span class="badge-eval ${evalItem.status.replace(/\s+/g, '-').toLowerCase()}">${evalItem.status}</span>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="extra-small text-muted">Performance Score</span>
                                        <span class="extra-small fw-bold">${evalItem.score}%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar ${evalItem.score >= 75 ? 'bg-success' : 'bg-warning'}" 
                                             role="progressbar" style="width: ${evalItem.score}%"></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="text-muted extra-small">Last Updated: ${evalItem.date}</span>
                                    <div class="btn-group">
                                        <button class="btn btn-xs btn-outline-secondary" onclick="window.HRSubmodules.updateScore('${evalItem.id}')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        ${evalItem.score >= 80 && evalItem.status !== 'Recommended' ? 
                                            `<button class="btn btn-xs btn-success ms-1" onclick="window.HRSubmodules.finalizeEval('${evalItem.id}', 'Recommended')">Approve</button>` : ''
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateScore = function(id) {
        const evals = getEvals();
        const idx = evals.findIndex(function (entry) {
            return entry.id === id;
        });
        if (idx === -1) {
            return;
        }

        const target = evals[idx];
        const modalEl = document.getElementById('probationEvalModal');
        const titleEl = document.getElementById('probationEvalModalTitle');
        const bodyEl = document.getElementById('probationEvalModalBody');
        const footerEl = document.getElementById('probationEvalModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Update Performance Score';
        bodyEl.innerHTML = [
            '<p class="mb-2">Update score for <strong>' + target.name + '</strong>.</p>',
            '<label class="form-label small mb-1">Score (0-100)</label>',
            '<input type="number" min="0" max="100" class="form-control form-control-sm" id="probationScoreInput" value="' + target.score + '">'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="probationScoreSaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('probationScoreSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const rawScore = Number(document.getElementById('probationScoreInput').value);
                if (Number.isNaN(rawScore) || rawScore < 0 || rawScore > 100) {
                    return;
                }

                evals[idx].score = Math.round(rawScore);
                evals[idx].status = evals[idx].score >= 75 ? 'Under Review' : 'Pending';
                evals[idx].date = new Date().toLocaleDateString();
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.finalizeEval = function(id, status) {
        let evals = getEvals();
        const idx = evals.findIndex(e => e.id === id);
        if (idx !== -1) {
            const target = evals[idx];
            const modalEl = document.getElementById('probationEvalModal');
            const titleEl = document.getElementById('probationEvalModalTitle');
            const bodyEl = document.getElementById('probationEvalModalBody');
            const footerEl = document.getElementById('probationEvalModalFooter');

            if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
                return;
            }

            titleEl.textContent = 'Finalize Evaluation';
            bodyEl.innerHTML = '<p class="mb-0">Mark <strong>' + target.name + '</strong> as ' + status + '?</p>';
            footerEl.innerHTML = [
                '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                '<button type="button" class="btn btn-success" id="probationFinalizeBtn">Confirm</button>'
            ].join('');

            const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
            const finalizeBtn = document.getElementById('probationFinalizeBtn');
            if (finalizeBtn) {
                finalizeBtn.addEventListener('click', function () {
                    evals[idx].status = status;
                    evals[idx].date = new Date().toLocaleDateString();
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                    window.dispatchEvent(new Event('storage'));
                    window.HRSubmodules.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
                    modal.hide();
                    showProbationInfo('Evaluation Finalized', target.name + ' has been marked as ' + status + '.');
                });
            }

            modal.show();
        }
    };

    window.HRSubmodules.addNewEvaluation = function() {
        const modalEl = document.getElementById('probationEvalModal');
        const titleEl = document.getElementById('probationEvalModalTitle');
        const bodyEl = document.getElementById('probationEvalModalBody');
        const footerEl = document.getElementById('probationEvalModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Start New Evaluation';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Employee Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="probationNewName" placeholder="e.g. Alex Rivera">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Role</label>',
            '  <input type="text" class="form-control form-control-sm" id="probationNewRole" placeholder="e.g. Staff Nurse">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="probationCreateBtn">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('probationCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('probationNewName').value || '').trim();
                const role = (document.getElementById('probationNewRole').value || '').trim() || 'General Staff';
                if (!name) {
                    return;
                }

                const evals = getEvals();
                evals.unshift({
                    id: 'EVL-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    role: role,
                    score: 0,
                    status: 'Pending',
                    date: '-'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

})();

