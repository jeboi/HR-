(function () {
    'use strict';

    var fallback = '../dashboardhr1.html';
    var allowed = {
        'dashboardhr1.html': true,
        'dashboardhr2.html': true,
        'dashboardhr3.html': true,
        'dashboardhr4.html': true,
        'dashboard.php': true
    };

    function normalizeCandidate(rawPath) {
        if (!rawPath) {
            return '';
        }

        var cleaned = String(rawPath).split('?')[0].split('#')[0].toLowerCase();
        var parts = cleaned.split('/');
        return parts[parts.length - 1];
    }

    function getReferrerFileName() {
        try {
            if (!document.referrer) {
                return '';
            }

            var referrerUrl = new URL(document.referrer, window.location.origin);
            return normalizeCandidate(referrerUrl.pathname);
        } catch (_err) {
            return '';
        }
    }

    var link = document.getElementById('backToDashboardLink')
        || document.querySelector('a[href="../dashboardhr1.html"]');

    if (!link) {
        return;
    }

    var source = getReferrerFileName();
    link.href = allowed[source] ? ('../' + source) : fallback;
})();
