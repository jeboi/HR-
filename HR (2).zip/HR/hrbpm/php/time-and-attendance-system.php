<?php
// time-and-attendance-system.php
// Fix the path - note the correct path is just "php/connect.php" not "phpphp/connect.php"
require_once __DIR__ . '/connect.php';

// Initialize variables
$attendanceStats = [
    'present' => 0,
    'late' => 0,
    'on_leave' => 0,
    'no_login' => 0
];

$attendanceRecords = [];
$validationQueue = [];
$correctionRequests = [];

try {
    if ($conn) {
        // Check if tables exist before querying
        $tablesExist = true;
        
        // Check if attendance table exists
        $checkAttendance = $conn->query("SHOW TABLES LIKE 'attendance'");
        if ($checkAttendance->rowCount() == 0) {
            $tablesExist = false;
            error_log("Attendance table does not exist");
        }
        
        // Check if employees table exists
        $checkEmployees = $conn->query("SHOW TABLES LIKE 'employees'");
        if ($checkEmployees->rowCount() == 0) {
            $tablesExist = false;
            error_log("Employees table does not exist");
        }
        
        if ($tablesExist) {
            // Get today's attendance statistics from database
            $stmt = $conn->prepare("
                SELECT 
                    SUM(CASE WHEN attendance_status = 'Present' THEN 1 ELSE 0 END) as present,
                    SUM(CASE WHEN attendance_status = 'Late' THEN 1 ELSE 0 END) as late,
                    SUM(CASE WHEN attendance_status = 'On Leave' THEN 1 ELSE 0 END) as on_leave,
                    SUM(CASE WHEN attendance_status = 'Absent' THEN 1 ELSE 0 END) as absent
                FROM attendance 
                WHERE attendance_date = CURDATE()
            ");
            $stmt->execute();
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($stats) {
                $attendanceStats['present'] = (int)($stats['present'] ?? 0);
                $attendanceStats['late'] = (int)($stats['late'] ?? 0);
                $attendanceStats['on_leave'] = (int)($stats['on_leave'] ?? 0);
                $attendanceStats['no_login'] = (int)($stats['absent'] ?? 0);
            }

            // Get today's attendance records with employee details
            $stmt = $conn->prepare("
                SELECT 
                    CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                    COALESCE(d.department_name, 'No Department') as department_name,
                    CASE 
                        WHEN a.time_in IS NOT NULL THEN DATE_FORMAT(a.time_in, '%h:%i %p')
                        ELSE '-'
                    END as time_in,
                    COALESCE(a.attendance_status, 'No Log-in') as status
                FROM employees e
                LEFT JOIN attendance a ON e.employee_id = a.employee_id AND a.attendance_date = CURDATE()
                LEFT JOIN departments d ON e.department_id = d.department_id
                WHERE e.employment_status IN ('Regular', 'Probationary', 'Contractual')
                ORDER BY 
                    CASE 
                        WHEN a.time_in IS NULL THEN 1 
                        ELSE 0 
                    END,
                    a.time_in ASC
                LIMIT 20
            ");
            $stmt->execute();
            $dbRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($dbRecords)) {
                $attendanceRecords = $dbRecords;
            }

            // Get validation queue (pending attendance records that need validation)
            $stmt = $conn->prepare("
                SELECT 
                    CONCAT('VAL-', a.attendance_id) as request_id,
                    CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                    CASE 
                        WHEN a.attendance_status = 'Late' THEN 'Late Log Entry'
                        WHEN a.time_in IS NULL THEN 'Missing Time In'
                        WHEN a.time_out IS NULL THEN 'Missing Time Out'
                        ELSE 'Attendance Discrepancy'
                    END as issue,
                    CASE 
                        WHEN a.remarks IS NULL THEN 'Pending'
                        ELSE 'For Review'
                    END as status
                FROM attendance a
                JOIN employees e ON a.employee_id = e.employee_id
                WHERE a.attendance_date = CURDATE() 
                AND (a.attendance_status IN ('Late', 'Present') OR a.time_in IS NULL OR a.time_out IS NULL)
                AND a.remarks IS NULL
                LIMIT 10
            ");
            $stmt->execute();
            $dbQueue = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($dbQueue)) {
                $validationQueue = $dbQueue;
            }

            // Get correction requests from database if table exists
            try {
                $checkCorrections = $conn->query("SHOW TABLES LIKE 'correction_requests'");
                if ($checkCorrections->rowCount() > 0) {
                    $stmt = $conn->prepare("
                        SELECT 
                            CONCAT('CR-', cr.request_id) as id,
                            CONCAT(e.first_name, ' ', e.last_name) as employee,
                            cr.issue_description as issue,
                            cr.status
                        FROM correction_requests cr
                        JOIN employees e ON cr.employee_id = e.employee_id
                        ORDER BY cr.request_date DESC
                        LIMIT 10
                    ");
                    $stmt->execute();
                    $dbCorrections = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($dbCorrections)) {
                        $correctionRequests = $dbCorrections;
                    }
                }
            } catch (PDOException $e) {
                // correction_requests table might not exist yet, use sample data
                error_log("Correction requests table error: " . $e->getMessage());
            }
        } else {
            error_log("Some tables are missing. Using sample data.");
        }
    }
} catch(PDOException $e) {
    error_log("Time and Attendance DB Error: " . $e->getMessage());
}

// If no records from DB, use sample data
if (empty($attendanceRecords)) {
    // Use the actual data from your database that you showed in the SQL dump
    $attendanceRecords = [
        ['employee_name' => 'Anna Santos', 'department_name' => 'Human Resources', 'time_in' => '08:02 AM', 'status' => 'Present'],
        ['employee_name' => 'Jude Molina', 'department_name' => 'Nursing', 'time_in' => '08:21 AM', 'status' => 'Late'],
        ['employee_name' => 'Leah Gomez', 'department_name' => 'Nursing', 'time_in' => '-', 'status' => 'Absent'],
        ['employee_name' => 'Mark Rivera', 'department_name' => 'Finance', 'time_in' => '07:58 AM', 'status' => 'Present']
    ];
    
    // Update stats based on sample data
    $attendanceStats = [
        'present' => 0,
        'late' => 0,
        'on_leave' => 0,
        'no_login' => 0
    ];
    
    foreach ($attendanceRecords as $record) {
        switch($record['status']) {
            case 'Present': $attendanceStats['present']++; break;
            case 'Late': $attendanceStats['late']++; break;
            case 'On Leave': $attendanceStats['on_leave']++; break;
            case 'Absent':
            case 'No Log-in': $attendanceStats['no_login']++; break;
        }
    }
}

if (empty($validationQueue)) {
    $validationQueue = [
        ['request_id' => 'VAL-1001', 'employee_name' => 'Leah Gomez', 'issue' => 'Missing Time In', 'status' => 'Pending'],
        ['request_id' => 'VAL-1002', 'employee_name' => 'Jude Molina', 'issue' => 'Late Log Entry', 'status' => 'Pending']
    ];
}

if (empty($correctionRequests)) {
    $correctionRequests = [
        ['id' => 'CR-1042', 'employee' => 'Anna Santos', 'issue' => 'Missing Time Out', 'status' => 'Pending'],
        ['id' => 'CR-1041', 'employee' => 'Leah Gomez', 'issue' => 'Late Log Adjustment', 'status' => 'Pending']
    ];
}

// Get current date for display
$currentDate = date('F d, Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Time and Attendance System - Hospital HR</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-bg: #f8f9fa;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }

        .tas-wrap {
            max-width: 1400px;
            margin: 0 auto;
        }

        .tas-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #34495e 100%);
            border-radius: 20px;
            color: white;
        }

        .tas-header .btn-light {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            transition: all 0.3s ease;
        }

        .tas-header .btn-light:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.4);
            color: white;
            transform: translateY(-2px);
        }

        .tas-subnav .btn {
            border-radius: 50px;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .tas-subnav .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .tas-subnav .btn.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .card {
            border-radius: 15px;
            overflow: hidden;
        }

        .card-header {
            border-bottom: 2px solid #f0f0f0;
            background: white;
        }

        .table th {
            font-weight: 600;
            color: #495057;
            border-bottom-width: 2px;
        }

        .badge {
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 500;
        }

        .bg-success-subtle {
            background-color: rgba(39, 174, 96, 0.1);
        }

        .bg-warning-subtle {
            background-color: rgba(243, 156, 18, 0.1);
        }

        .bg-danger-subtle {
            background-color: rgba(231, 76, 60, 0.1);
        }

        .bg-info-subtle {
            background-color: rgba(52, 152, 219, 0.1);
        }

        .text-success { color: #27ae60 !important; }
        .text-warning { color: #f39c12 !important; }
        .text-danger { color: #e74c3c !important; }
        .text-info { color: #3498db !important; }

        .connection-status {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 12px 24px;
            border-radius: 50px;
            font-size: 14px;
            z-index: 9999;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            transition: opacity 1s;
            font-weight: 500;
        }
        
        .connection-status.connected {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .connection-status.disconnected {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .connection-status i {
            margin-right: 8px;
        }

        .kpi-card {
            transition: all 0.3s ease;
            cursor: default;
        }

        .kpi-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
        }

        .btn-outline-primary {
            border-color: #dee2e6;
            color: var(--primary-color);
        }

        .btn-outline-primary:hover {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }

        .table tbody tr:hover {
            background-color: rgba(0,0,0,0.02);
        }

        @media (max-width: 768px) {
            .tas-header {
                padding: 1.5rem !important;
            }
            
            .tas-subnav .btn {
                width: 100%;
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($conn) && $conn): ?>
        <div class="connection-status connected">
            <i class="fas fa-check-circle"></i> Database Connected - 
            <?php echo !empty($attendanceRecords) && $attendanceRecords[0]['employee_name'] != 'Anna Santos' ? 'Live Data' : 'Using Sample Data (Tables may be empty)'; ?>
        </div>
    <?php else: ?>
        <div class="connection-status disconnected">
            <i class="fas fa-exclamation-circle"></i> Database Connection Failed (Using Sample Data)
        </div>
    <?php endif; ?>

    <main class="container py-4 py-md-5">
        <div class="tas-wrap">
            <section class="tas-header p-4 p-md-5 shadow-sm mb-4">
                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                    <div>
                        <h1 class="h3 mb-2">
                            <i class="fas fa-user-check me-2"></i>Time and Attendance System
                        </h1>
                        <p class="mb-0 opacity-75">
                            <i class="fas fa-calendar-alt me-2"></i>
                            <?php echo $currentDate; ?> - Manage monitoring, validation, reporting, and correction workflows
                        </p>
                        <div class="mt-2">
                            <?php if(isset($conn) && $conn): ?>
                                <span class="badge bg-success-subtle text-success">
                                    <i class="fas fa-database me-1"></i> Database Connected
                                </span>
                            <?php else: ?>
                                <span class="badge bg-warning-subtle text-warning">
                                    <i class="fas fa-exclamation-triangle me-1"></i> Using Sample Data
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <a href="../dashboard.php" class="btn btn-light">
                        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                    </a>
                </div>
            </section>

            <section class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="tas-subnav d-flex flex-wrap gap-2" role="tablist" aria-label="Time and Attendance submodules">
                        <button type="button" class="btn btn-outline-primary active" data-submodule="Attendance Monitoring">
                            <i class="fas fa-eye me-2"></i>Attendance Monitoring
                        </button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Attendance Validation">
                            <i class="fas fa-clipboard-check me-2"></i>Attendance Validation
                        </button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Attendance Reports">
                            <i class="fas fa-chart-bar me-2"></i>Attendance Reports
                        </button>
                        <button type="button" class="btn btn-outline-primary" data-submodule="Correction Requests">
                            <i class="fas fa-pen-to-square me-2"></i>Correction Requests
                        </button>
                    </div>
                </div>
            </section>

            <section class="card border-0 shadow-sm">
                <div class="card-body">
                    <div id="tasSubmoduleContainer">
                        <!-- Submodules will be loaded here dynamically -->
                        <div class="text-center py-5">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <p class="mt-3 text-muted">Loading attendance data...</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <script>
        // Pass PHP data to JavaScript
        window.hrAttendanceData = {
            stats: {
                present: <?php echo $attendanceStats['present']; ?>,
                late: <?php echo $attendanceStats['late']; ?>,
                on_leave: <?php echo $attendanceStats['on_leave']; ?>,
                no_login: <?php echo $attendanceStats['no_login']; ?>
            },
            records: <?php echo json_encode($attendanceRecords); ?>,
            validationQueue: <?php echo json_encode($validationQueue); ?>,
            correctionRequests: <?php echo json_encode($correctionRequests); ?>
        };
        
        console.log('Attendance Data loaded:', window.hrAttendanceData);
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modules/time and attendance system/time-and-attendance-system.js"></script>
    
    <script>
        // Auto-hide connection status after 5 seconds
        setTimeout(function() {
            var statusDiv = document.querySelector('.connection-status');
            if (statusDiv) {
                statusDiv.style.transition = 'opacity 1s';
                statusDiv.style.opacity = '0';
                setTimeout(function() {
                    statusDiv.style.display = 'none';
                }, 1000);
            }
        }, 5000);
    </script>
</body>
</html>