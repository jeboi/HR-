<?php
// php/attendance-api.php
require_once __DIR__ . '/connect.php';

header('Content-Type: application/json');

// Get the request method
$method = $_SERVER['REQUEST_METHOD'];

try {
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    switch ($method) {
        case 'GET':
            // Get attendance records
            $date = $_GET['date'] ?? date('Y-m-d');
            $type = $_GET['type'] ?? 'monitoring';
            
            if ($type === 'monitoring') {
                $sql = "
                    SELECT 
                        CONCAT(e.first_name, ' ', e.last_name) as employee,
                        d.department_name as department,
                        COALESCE(TIME_FORMAT(a.time_in, '%h:%i %p'), '-') as timeIn,
                        COALESCE(a.attendance_status, 'No Log-in') as status
                    FROM employees e
                    LEFT JOIN departments d ON e.department_id = d.department_id
                    LEFT JOIN attendance a ON e.employee_id = a.employee_id AND a.attendance_date = ?
                    WHERE e.employment_status IN ('Regular', 'Probationary')
                    ORDER BY a.time_in IS NULL, a.time_in ASC
                    LIMIT 50
                ";
                
                $stmt = $conn->prepare($sql);
                $stmt->execute([$date]);
                $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode(['success' => true, 'data' => $records]);
            } elseif ($type === 'validation') {
                $sql = "
                    SELECT 
                        CONCAT('VAL-', a.attendance_id) as id,
                        CONCAT(e.first_name, ' ', e.last_name) as employee,
                        CASE 
                            WHEN a.attendance_status = 'Late' THEN 'Late Log Entry'
                            WHEN a.time_in IS NULL THEN 'Missing Time In'
                            WHEN a.time_out IS NULL THEN 'Missing Time Out'
                            ELSE 'Attendance Discrepancy'
                        END as issue,
                        CASE 
                            WHEN a.attendance_status IN ('Present', 'Late') THEN 'Pending'
                            ELSE 'For Review'
                        END as status
                    FROM attendance a
                    JOIN employees e ON a.employee_id = e.employee_id
                    WHERE a.attendance_date = ? 
                    AND a.attendance_status IN ('Late', 'Present')
                    AND a.remarks IS NULL
                    LIMIT 20
                ";
                
                $stmt = $conn->prepare($sql);
                $stmt->execute([$date]);
                $queue = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode(['success' => true, 'data' => $queue]);
            }
            break;
            
        case 'POST':
            // Create correction request
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['employee']) || !isset($data['issue'])) {
                throw new Exception('Invalid request data');
            }
            
            // You'll need to create a correction_requests table
            // For now, return success with generated ID
            $requestId = 'CR-' . rand(1000, 9999);
            
            echo json_encode([
                'success' => true,
                'message' => 'Correction request created',
                'data' => [
                    'id' => $requestId,
                    'employee' => $data['employee'],
                    'issue' => $data['issue'],
                    'status' => 'Pending'
                ]
            ]);
            break;
            
        case 'PUT':
            // Update validation status
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id']) || !isset($data['status'])) {
                throw new Exception('Invalid request data');
            }
            
            $attendance_id = str_replace('VAL-', '', $data['id']);
            
            $sql = "UPDATE attendance SET 
                    remarks = ?,
                    attendance_status = CASE 
                        WHEN ? = 'Approved' THEN attendance_status
                        WHEN ? = 'Rejected' THEN 'Absent'
                        ELSE attendance_status
                    END
                    WHERE attendance_id = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$data['status'], $data['status'], $data['status'], $attendance_id]);
            
            echo json_encode(['success' => true, 'message' => 'Validation updated']);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    error_log('Attendance API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>