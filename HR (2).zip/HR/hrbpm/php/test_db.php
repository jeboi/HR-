<?php
// test-db.php
require_once 'php/connect.php';

echo "<h1>Database Structure Test</h1>";

try {
    if (!$conn) {
        die("<p style='color:red'>❌ Connection failed</p>");
    }
    
    echo "<p style='color:green'>✅ Connected to database: " . $conn->query("SELECT DATABASE()")->fetchColumn() . "</p>";
    
    // Test leave_requests table
    echo "<h2>leave_requests table:</h2>";
    $stmt = $conn->query("SHOW TABLES LIKE 'leave_requests'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✅ Table exists</p>";
        
        // Show columns
        $columns = $conn->query("DESCRIBE leave_requests")->fetchAll(PDO::FETCH_ASSOC);
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>" . $col['Field'] . "</td>";
            echo "<td>" . $col['Type'] . "</td>";
            echo "<td>" . $col['Null'] . "</td>";
            echo "<td>" . $col['Key'] . "</td>";
            echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show sample data
        $data = $conn->query("SELECT * FROM leave_requests LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>Sample Data:</h3>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    } else {
        echo "<p style='color:red'>❌ Table does not exist</p>";
    }
    
    // Test employees table
    echo "<h2>employees table:</h2>";
    $stmt = $conn->query("SHOW TABLES LIKE 'employees'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✅ Table exists</p>";
        
        // Show columns
        $columns = $conn->query("DESCRIBE employees")->fetchAll(PDO::FETCH_ASSOC);
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>" . $col['Field'] . "</td>";
            echo "<td>" . $col['Type'] . "</td>";
            echo "<td>" . $col['Null'] . "</td>";
            echo "<td>" . $col['Key'] . "</td>";
            echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show sample data
        $data = $conn->query("SELECT * FROM employees LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>Sample Data:</h3>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    } else {
        echo "<p style='color:red'>❌ Table does not exist</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}
?>