/**
 * Skill Inventory Submodule
 * Professional Medical & Administrative Talent Database
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrSkillInventory';

    const getSkills = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        return [
            { id: "SKL-001", name: "Dr. Aris Thorne", category: "Clinical", skills: ["Surgery", "ER", "Trauma"], level: "Expert" },
            { id: "SKL-002", name: "Sarah Jenkins", category: "Leadership", skills: ["Team Mgmt", "Nursing Ops"], level: "Advanced" },
            { id: "SKL-003", name: "James Miller", category: "Technical", skills: ["Radiology", "MRI"], level: "Intermediate" }
        ];
    };

    window.HRSubmodules.renderSkillInventory = function (container) {
        const inventory = getSkills();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-info">
                        <h6 class="fw-bold mb-0 text-dark">Talent Inventory</h6>
                        <small class="text-muted">Specialized medical and technical competencies</small>
                    </div>
                    <button class="btn btn-sm btn-primary px-3 shadow-sm" onclick="window.HRSubmodules.addNewSkillEntry()">
                        <i class="fas fa-plus me-2"></i>Add Talent
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-skill-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 30%">Staff Member</th>
                                <th style="width: 45%">Competencies</th>
                                <th class="text-end pe-4" style="width: 25%">Proficiency</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${inventory.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate">${item.name}</div>
                                        <div class="text-muted extra-small">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-1">
                                            ${item.skills.map(s => `<span class="skill-tag">${s}</span>`).join('')}
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="level-badge ${item.level.toLowerCase()}">${item.level}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewSkillEntry = function() {
        const name = prompt("Staff Name:");
        const skills = prompt("Skills (comma separated):");
        if (name && skills) {
            let inventory = getSkills();
            inventory.unshift({
                id: "SKL-" + Math.floor(100 + Math.random() * 900),
                name: name,
                category: "General",
                skills: skills.split(',').map(s => s.trim()),
                level: "Intermediate"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(inventory));
            window.dispatchEvent(new Event('storage'));
            this.renderSkillInventory(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();