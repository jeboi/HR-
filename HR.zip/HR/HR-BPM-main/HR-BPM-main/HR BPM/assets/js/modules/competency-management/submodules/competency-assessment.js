/**
 * Competency Assessment Submodule
 * Professional Grading & Proficiency Standards
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompetencyEvals';

    const getAssessments = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Data
        return [
            { id: "CMP-001", name: "Dr. Aris Thorne", area: "Clinical Expertise", score: 95, status: "Certified" },
            { id: "CMP-002", name: "Sarah Jenkins", area: "Patient Safety", score: 88, status: "Certified" },
            { id: "CMP-003", name: "James Miller", area: "Technical Ops", score: 72, status: "Training Required" }
        ];
    };

    window.HRSubmodules.renderCompetencyAssessment = function (container) {
        const data = getAssessments();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-chart-line text-success me-2"></i>Competency Assessment</h6>
                        <small class="text-muted">Measure staff proficiency against healthcare benchmarks</small>
                    </div>
                    <button class="btn btn-outline-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.startNewAssessment()">
                        <i class="fas fa-clipboard-check me-1"></i> New Assessment
                    </button>
                </div>

                <div class="row g-3">
                    ${data.map(item => `
                        <div class="col-md-6 col-xl-4">
                            <div class="comp-card bg-white p-3 border rounded-3 shadow-sm h-100">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="text-truncate" style="max-width: 70%;">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-primary">${item.area}</div>
                                    </div>
                                    <span class="comp-badge ${item.status.toLowerCase().replace(/\s+/g, '-')}">${item.status}</span>
                                </div>

                                <div class="mb-2 d-flex justify-content-between align-items-center">
                                    <span class="small text-muted">Proficiency Score</span>
                                    <span class="fw-bold ${item.score >= 80 ? 'text-success' : 'text-warning'}">${item.score}%</span>
                                </div>
                                
                                <div class="progress mb-3" style="height: 8px; border-radius: 10px;">
                                    <div class="progress-bar ${item.score >= 80 ? 'bg-success' : 'bg-warning'}" 
                                         role="progressbar" style="width: ${item.score}%"></div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="extra-small text-muted">ID: ${item.id}</span>
                                    <button class="btn btn-link btn-sm p-0 text-decoration-none extra-small" onclick="window.HRSubmodules.updateCompScore('${item.id}')">Update Score</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.startNewAssessment = function() {
        const name = prompt("Staff Name:");
        const area = prompt("Assessment Area (e.g., Clinical, Ethics):");
        if (name && area) {
            let data = getAssessments();
            data.unshift({
                id: "CMP-" + Math.floor(100 + Math.random() * 900),
                name: name,
                area: area,
                score: 0,
                status: "Pending"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            window.dispatchEvent(new Event('storage'));
            this.renderCompetencyAssessment(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.updateCompScore = function(id) {
        const score = prompt("Enter New Score (0-100):");
        if (score !== null) {
            let data = getAssessments();
            const idx = data.findIndex(i => i.id === id);
            if (idx !== -1) {
                data[idx].score = parseInt(score);
                data[idx].status = data[idx].score >= 75 ? "Certified" : "Training Required";
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                this.renderCompetencyAssessment(document.getElementById('roleModuleOverviewBody'));
            }
        }
    };

})();