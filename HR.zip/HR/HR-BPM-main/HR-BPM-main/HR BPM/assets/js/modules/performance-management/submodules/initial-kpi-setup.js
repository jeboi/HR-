/**
 * Initial KPI Setup Submodule
 * Defines performance targets for new staff
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrKpiSetup';

    const getKpis = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical KPI Defaults
        return [
            { id: "KPI-2026-01", name: "Dr. Aris Thorne", category: "Clinical", metric: "Patient Satisfaction Score", target: ">= 90%", status: "Approved" },
            { id: "KPI-2026-02", name: "Sarah Jenkins", category: "Administrative", metric: "Staff Retention Rate", target: ">= 85%", status: "Pending Approval" },
            { id: "KPI-2026-03", name: "James Miller", category: "Technical", metric: "Imaging Turnaround Time", target: "< 2 Hours", status: "Draft" }
        ];
    };

    window.HRSubmodules.renderInitialKPISetup = function (container) {
        const kpis = getKpis();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-primary me-2"></i>KPI Framework</h6>
                        <small class="text-muted">Establish baseline performance metrics for new personnel</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.createNewKpi()">
                        <i class="fas fa-plus me-1"></i> Define KPI
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Employee</th>
                                <th>Category</th>
                                <th>Metric & Target</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${kpis.map(kpi => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${kpi.name}</div>
                                        <div class="text-muted extra-small">${kpi.id}</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border">${kpi.category}</span>
                                    </td>
                                    <td>
                                        <div class="fw-medium text-primary">${kpi.metric}</div>
                                        <div class="small text-muted">Goal: ${kpi.target}</div>
                                    </td>
                                    <td>
                                        <span class="kpi-status-pill ${kpi.status.toLowerCase().replace(/\s+/g, '-')}">${kpi.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            <button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateKpiStatus('${kpi.id}', 'Approved')">Approve</button>
                                            <button class="btn btn-xs btn-outline-danger" onclick="window.HRSubmodules.deleteKpi('${kpi.id}')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateKpiStatus = function(id, status) {
        let kpis = getKpis();
        const idx = kpis.findIndex(k => k.id === id);
        if (idx !== -1) {
            kpis[idx].status = status;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
            window.dispatchEvent(new Event('storage')); // Trigger Dashboard Update
            this.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.createNewKpi = function() {
        const name = prompt("Employee Name:");
        const metric = prompt("Metric (e.g., Response Time):");
        if (name && metric) {
            let kpis = getKpis();
            kpis.unshift({
                id: "KPI-2026-" + Math.floor(Math.random() * 1000),
                name: name,
                category: "General",
                metric: metric,
                target: "TBD",
                status: "Draft"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
            window.dispatchEvent(new Event('storage'));
            this.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.deleteKpi = function(id) {
        if(confirm("Remove this KPI target?")) {
            let kpis = getKpis().filter(k => k.id !== id);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
            window.dispatchEvent(new Event('storage'));
            this.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
        }
    };

})();