/**
 * Job Posting Management Submodule
 * Professional Vacancy Lifecycle Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    // Initial Data State - Mocking a Hospital Vacancy List
    let jobPostings = JSON.parse(localStorage.getItem('hospitalHrJobPostings')) || [
        { id: "JOB-2026-001", title: "Registered Nurse (ICU)", dept: "Nursing", type: "Full-time", apps: 12, status: "Active" },
        { id: "JOB-2026-002", title: "Medical Technologist", dept: "Laboratory", type: "Full-time", apps: 8, status: "Active" },
        { id: "JOB-2026-003", title: "HR Generalist", dept: "Human Resources", type: "Contract", apps: 25, status: "Closed" }
    ];

    window.HRSubmodules.renderJobPostingManagement = function (container) {
        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="mb-0 fw-bold"><i class="fas fa-briefcase text-primary me-2"></i>Job Vacancy Manager</h6>
                        <small class="text-muted">Currently managing ${jobPostings.filter(j => j.status === 'Active').length} active listings</small>
                    </div>
                    <button class="btn btn-primary btn-sm shadow-sm px-3" onclick="window.HRSubmodules.openNewJobModal()">
                        <i class="fas fa-plus-circle me-2"></i>Post New Opening
                    </button>
                </div>

                <div class="row g-3" id="jobGridContainer">
                    ${jobPostings.map(job => `
                        <div class="col-md-6 col-lg-4">
                            <div class="job-card p-3 border rounded-3 bg-white shadow-sm position-relative ${job.status === 'Closed' ? 'opacity-75' : ''}">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge ${job.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'}">
                                        ${job.status}
                                    </span>
                                    <div class="dropdown">
                                        <button class="btn btn-link btn-sm text-muted p-0" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></button>
                                        <ul class="dropdown-menu shadow-sm border-0">
                                            <li><a class="dropdown-item small" href="#" onclick="window.HRSubmodules.toggleJobStatus('${job.id}')">Toggle Status</a></li>
                                            <li><a class="dropdown-item small text-danger" href="#">Delete Post</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">${job.title}</h6>
                                <p class="text-muted extra-small mb-3"><i class="fas fa-hospital-alt me-1"></i>${job.dept} &bull; ${job.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <div class="text-center">
                                        <div class="fw-bold text-primary mb-0">${job.apps}</div>
                                        <div class="extra-small text-muted">Applicants</div>
                                    </div>
                                    <button class="btn btn-sm btn-light border px-3" style="font-size: 11px;">View Candidates</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.toggleJobStatus = function(id) {
        const job = jobPostings.find(j => j.id === id);
        if (job) {
            job.status = job.status === 'Active' ? 'Closed' : 'Active';
            this.syncJobData();
            this.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.syncJobData = function() {
        localStorage.setItem('hospitalHrJobPostings', JSON.stringify(jobPostings));
        // Update Dashboard Specific Key
        localStorage.setItem('hospitalHrActiveJobs', jobPostings.filter(j => j.status === 'Active').length);
        window.dispatchEvent(new Event('storage'));
    };

    window.HRSubmodules.openNewJobModal = function() {
        const title = prompt("Enter Job Title:");
        if (title) {
            const newJob = {
                id: "JOB-" + Date.now().toString().slice(-4),
                title: title,
                dept: "General Medicine",
                type: "Full-time",
                apps: 0,
                status: "Active"
            };
            jobPostings.unshift(newJob);
            this.syncJobData();
            this.renderJobPostingManagement(document.getElementById('roleModuleOverviewBody'));
        }
    };

})();