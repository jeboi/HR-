/**
 * Interview Logic
 * Assets: assets/js/modules/applicant-management/submodules/interview-scheduling.js
 */
(function () {
    'use strict';
    window.HRSubmodules = window.HRSubmodules || {};

    window.HRSubmodules.renderInterviewScheduling = function (container) {
        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="row">
                    <div class="col-md-4">
                        <div class="p-3 border rounded-3 bg-light mb-3">
                            <h6 class="fw-bold">Schedule New</h6>
                            <div class="mb-2">
                                <label class="extra-small fw-bold">Candidate</label>
                                <input type="text" id="intCandidate" class="form-control form-control-sm" placeholder="Name">
                            </div>
                            <div class="mb-2">
                                <label class="extra-small fw-bold">Time Slot</label>
                                <input type="datetime-local" id="intTime" class="form-control form-control-sm">
                            </div>
                            <button id="btnConfirmSchedule" class="btn btn-primary btn-sm w-100 mt-2">Book Interview</button>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="border rounded-3 bg-white p-3">
                            <h6 class="fw-bold mb-3">Today's Schedule</h6>
                            <div id="interviewList">
                                <div class="alert alert-info py-2 extra-small">No interviews scheduled for this time.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('btnConfirmSchedule').addEventListener('click', () => {
            const name = document.getElementById('intCandidate').value;
            const time = document.getElementById('intTime').value;

            if(!name || !time) {
                alert("Please fill in all fields.");
                return;
            }

            // Real-time Update Logic: Update Dashboard
            const count = parseInt(localStorage.getItem('hospitalHrPendingInterviews') || 0);
            localStorage.setItem('hospitalHrPendingInterviews', count + 1);
            
            // Trigger main.js Sync
            window.dispatchEvent(new Event('storage'));
            
            alert(`Interview confirmed for ${name} at ${time}. Dashboard updated.`);
            document.getElementById('intCandidate').value = '';
        });
    };
})();