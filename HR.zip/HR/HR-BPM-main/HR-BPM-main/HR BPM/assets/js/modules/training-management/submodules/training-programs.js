/**
 * Training Programs Submodule
 * Professional Strategic Initiative Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrTrainingPrograms';

    const getPrograms = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Training Initiatives
        return [
            { id: "PROG-001", name: "2024 Leadership Excellence", type: "Workshop Series", cohorts: 3, lead: "Dr. Elena Vance", status: "In Progress" },
            { id: "PROG-002", name: "Emergency Response Drill", type: "Simulation", cohorts: 12, lead: "Marcus Thorne", status: "Scheduled" },
            { id: "PROG-003", name: "Digital Records Migration", type: "Technical", cohorts: 5, lead: "IT Dept", status: "Completed" }
        ];
    };

    window.HRSubmodules.renderTrainingPrograms = function (container) {
        const programs = getPrograms();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-chalkboard-user text-info me-2"></i>Strategic Training Initiatives</h6>
                        <small class="text-muted">High-level developmental programs and institutional workshops</small>
                    </div>
                    <button class="btn btn-info btn-sm text-white rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.initiateNewProgram()">
                        <i class="fas fa-rocket me-1"></i> New Initiative
                    </button>
                </div>

                <div class="row g-4">
                    ${programs.map(prog => `
                        <div class="col-xl-4 col-md-6">
                            <div class="program-card border rounded-4 bg-white shadow-sm h-100 position-relative overflow-hidden">
                                <div class="program-type-tag">${prog.type}</div>
                                <div class="p-4 pt-5">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h6 class="fw-bold text-dark mb-0 pe-2" style="line-height: 1.4; min-height: 44px;">${prog.name}</h6>
                                        <span class="badge ${getStatusBadgeClass(prog.status)}">${prog.status}</span>
                                    </div>
                                    
                                    <div class="program-meta-grid border-top pt-3 mt-2">
                                        <div class="row text-center">
                                            <div class="col-6 border-end">
                                                <div class="extra-small text-muted text-uppercase fw-bold">Cohorts</div>
                                                <div class="fw-bold text-primary">${prog.cohorts}</div>
                                            </div>
                                            <div class="col-6">
                                                <div class="extra-small text-muted text-uppercase fw-bold">Program Lead</div>
                                                <div class="small fw-semibold text-dark text-truncate px-1">${prog.lead}</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4 pt-2 d-flex gap-2">
                                        <button class="btn btn-light btn-sm flex-grow-1 border" onclick="alert('Program ID: ${prog.id}')">Details</button>
                                        <button class="btn btn-outline-info btn-sm flex-grow-1" onclick="alert('Viewing Cohorts...')">Cohorts</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    function getStatusBadgeClass(status) {
        switch(status) {
            case 'Completed': return 'bg-success-subtle text-success';
            case 'In Progress': return 'bg-info-subtle text-info';
            case 'Scheduled': return 'bg-warning-subtle text-warning';
            default: return 'bg-secondary-subtle text-secondary';
        }
    }

    window.HRSubmodules.initiateNewProgram = function() {
        const name = prompt("Program Name:");
        const type = prompt("Type (Workshop/Simulation/Series):");
        if (name && type) {
            let programs = getPrograms();
            programs.unshift({
                id: "PROG-" + Math.floor(100 + Math.random() * 900),
                name: name,
                type: type,
                cohorts: 1,
                lead: "Unassigned",
                status: "Scheduled"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(programs));
            // Triggers real-time dashboard update as defined in main.js
            window.dispatchEvent(new Event('storage'));
            this.renderTrainingPrograms(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();