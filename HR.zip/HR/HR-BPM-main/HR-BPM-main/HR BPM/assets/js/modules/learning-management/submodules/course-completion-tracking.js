/**
 * Course Completion Tracking Submodule
 * Official Records and Certification Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompletions';

    const getCompletions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Completion Records
        return [
            { id: "CERT-901", name: "Dr. Aris Thorne", course: "Advanced Life Support", date: "2026-02-10", grade: "98%", status: "Certified" },
            { id: "CERT-902", name: "Sarah Jenkins", course: "Patient Privacy & HIPAA", date: "2026-01-22", grade: "100%", status: "Certified" },
            { id: "CERT-903", name: "James Miller", course: "Radiology Safety", date: "2025-12-15", grade: "85%", status: "Expired" }
        ];
    };

    window.HRSubmodules.renderCourseCompletionTracking = function (container) {
        const data = getCompletions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-certificate text-success me-2"></i>Completion Registry</h6>
                        <small class="text-muted">Official log of hospital certifications and professional development</small>
                    </div>
                    <button class="btn btn-outline-success btn-sm rounded-pill px-3" onclick="window.HRSubmodules.recordNewCompletion()">
                        <i class="fas fa-file-signature me-1"></i> Record Completion
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-tracking-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Staff Member</th>
                                <th style="width: 30%">Course Title</th>
                                <th style="width: 15%">Grade</th>
                                <th style="width: 15%">Completion</th>
                                <th class="text-end pe-4" style="width: 15%">Credential</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-dark small">${item.course}</div>
                                    </td>
                                    <td>
                                        <span class="fw-bold ${parseInt(item.grade) >= 90 ? 'text-success' : 'text-primary'}">${item.grade}</span>
                                    </td>
                                    <td>
                                        <div class="small text-muted">${item.date}</div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="cert-status ${item.status.toLowerCase()}">${item.status}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.recordNewCompletion = function() {
        const name = prompt("Enter Staff Name:");
        const course = prompt("Course Completed:");
        const grade = prompt("Final Grade (e.g. 95%):");
        if (name && course) {
            let data = getCompletions();
            data.unshift({
                id: "CERT-" + Math.floor(1000 + Math.random() * 9000),
                name: name,
                course: course,
                date: new Date().toISOString().split('T')[0],
                grade: grade || "N/A",
                status: "Certified"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            window.dispatchEvent(new Event('storage')); // Notify Dashboard
            this.renderCourseCompletionTracking(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();