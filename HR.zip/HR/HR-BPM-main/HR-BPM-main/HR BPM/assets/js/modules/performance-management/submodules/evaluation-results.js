/**
 * Evaluation Results Submodule
 * Final performance reporting and history
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrEvalResults';

    const getResults = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical Staff Evaluation History
        return [
            { id: "RES-2026-001", name: "Dr. Aris Thorne", period: "Q1 2026", finalScore: 94, outcome: "Permanent", remark: "Exceptional clinical precision." },
            { id: "RES-2026-002", name: "Sarah Jenkins", period: "Q1 2026", finalScore: 78, outcome: "Extended", remark: "Requires more administrative focus." },
            { id: "RES-2026-003", name: "James Miller", period: "Q1 2026", finalScore: 82, outcome: "Permanent", remark: "Technical skills meet hospital standards." }
        ];
    };

    window.HRSubmodules.renderEvaluationResults = function (container) {
        const results = getResults();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm text-center">
                            <div class="text-muted small fw-bold text-uppercase">Avg. Hospital Score</div>
                            <h4 class="fw-bold text-primary mb-0">84.6%</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm text-center">
                            <div class="text-muted small fw-bold text-uppercase">Passing Rate</div>
                            <h4 class="fw-bold text-success mb-0">92%</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-3 border rounded-3 shadow-sm d-flex align-items-center justify-content-center">
                            <button class="btn btn-sm btn-outline-dark" onclick="window.print()">
                                <i class="fas fa-file-pdf me-2"></i>Export Reports
                            </button>
                        </div>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-result-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Employee Details</th>
                                <th style="width: 15%">Review Period</th>
                                <th style="width: 15%">Final Score</th>
                                <th style="width: 15%">Outcome</th>
                                <th class="pe-4" style="width: 30%">HR Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${results.map(res => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${res.name}</div>
                                        <div class="extra-small text-muted">${res.id}</div>
                                    </td>
                                    <td class="text-secondary small">${res.period}</td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="fw-bold me-2 ${res.finalScore >= 80 ? 'text-success' : 'text-warning'}">${res.finalScore}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="outcome-pill ${res.outcome.toLowerCase()}">${res.outcome}</span>
                                    </td>
                                    <td class="pe-4">
                                        <div class="remark-text" title="${res.remark}">${res.remark}</div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

})();