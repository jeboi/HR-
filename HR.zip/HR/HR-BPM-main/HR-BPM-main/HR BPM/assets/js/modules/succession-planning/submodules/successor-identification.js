/**
 * Successor Identification Submodule
 * Professional Talent Bench & Readiness Mapping
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrSuccessors';

    const getSuccessors = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Talent Bench Data
        return [
            { id: "TAL-01", name: "Dr. Sarah Chen", targetRole: "Chief Nursing Officer", readiness: "Ready Now", potential: "High", performance: "Exceeding" },
            { id: "TAL-02", name: "Robert Miller", targetRole: "IT Infrastructure Director", readiness: "1-2 Years", potential: "Medium", performance: "Consistent" },
            { id: "TAL-03", name: "Nurse Elena Rodriguez", targetRole: "Nursing Admin Manager", readiness: "Ready Now", potential: "High", performance: "Exceeding" }
        ];
    };

    window.HRSubmodules.renderSuccessorIdentification = function (container) {
        const successors = getSuccessors();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-graduate text-success me-2"></i>Talent Bench & Successor Pool</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Identifying Future Leadership Capacity</small>
                    </div>
                    <button class="btn btn-success btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.nominateSuccessor()">
                        <i class="fas fa-user-plus me-1"></i> Nominate Successor
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 custom-talent-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Candidate</th>
                                <th style="width: 25%">Target Role</th>
                                <th style="width: 15%">Readiness</th>
                                <th style="width: 15%">Potential</th>
                                <th class="text-end pe-4" style="width: 20%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${successors.map(person => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${person.name}</div>
                                        <div class="extra-small text-muted">Perf: ${person.performance}</div>
                                    </td>
                                    <td>
                                        <div class="small fw-semibold text-primary">${person.targetRole}</div>
                                    </td>
                                    <td>
                                        <span class="readiness-tag ${person.readiness.replace(/\s+/g, '-').toLowerCase()}">
                                            ${person.readiness}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="potential-bar flex-grow-1 me-2">
                                                <div class="potential-fill ${person.potential.toLowerCase()}" style="width: ${person.potential === 'High' ? '100%' : '60%'}"></div>
                                            </div>
                                            <span class="extra-small fw-bold">${person.potential}</span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="alert('Opening Development Plan for ${person.name}...')">
                                            <i class="fas fa-chart-line"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.nominateSuccessor = function() {
        const name = prompt("Candidate Name:");
        const role = prompt("Target Future Role:");
        if (name && role) {
            let successors = getSuccessors();
            successors.unshift({
                id: "TAL-" + Math.floor(10 + Math.random() * 89),
                name: name,
                targetRole: role,
                readiness: "Emergency Only",
                potential: "TBD",
                performance: "Under Review"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(successors));
            window.dispatchEvent(new Event('storage')); // Immediate Dashboard Update
            this.renderSuccessorIdentification(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();