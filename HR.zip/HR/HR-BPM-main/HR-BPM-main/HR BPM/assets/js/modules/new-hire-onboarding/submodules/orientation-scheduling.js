/**
 * Orientation Scheduling Submodule
 * Professional Induction & Training Coordinator
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrOrientations';

    const getSessions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Professional Orientation Schedule
        return [
            { id: "ORI-101", title: "General Hospital Induction", date: "2026-03-10", time: "09:00 AM", venue: "Main Conference Hall", facilitator: "Director Maria Santos", status: "Scheduled" },
            { id: "ORI-102", title: "Nurse Protocol Training", date: "2026-03-12", time: "01:30 PM", venue: "Training Room B", facilitator: "Head Nurse Sarah J.", status: "Confirmed" }
        ];
    };

    window.HRSubmodules.renderOrientationScheduling = function (container) {
        const sessions = getSessions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-calendar-alt text-primary me-2"></i>Induction Schedule</h6>
                        <small class="text-muted">Coordinate orientation dates for newly onboarded staff</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.addNewOrientation()">
                        <i class="fas fa-plus me-1"></i> Schedule Session
                    </button>
                </div>

                <div class="row g-3">
                    ${sessions.map(session => `
                        <div class="col-12">
                            <div class="orientation-card p-3 border rounded-3 bg-white shadow-sm">
                                <div class="row align-items-center">
                                    <div class="col-md-2 border-end text-center">
                                        <div class="fw-bold text-primary mb-0">${session.date.split('-')[2]} ${new Date(session.date).toLocaleString('default', { month: 'short' })}</div>
                                        <div class="small text-muted">${session.time}</div>
                                    </div>
                                    
                                    <div class="col-md-7 ps-md-4">
                                        <h6 class="fw-bold mb-1 text-dark">${session.title}</h6>
                                        <div class="d-flex gap-3 flex-wrap">
                                            <span class="small text-muted"><i class="fas fa-map-marker-alt me-1 text-danger"></i> ${session.venue}</span>
                                            <span class="small text-muted"><i class="fas fa-user-tie me-1 text-info"></i> ${session.facilitator}</span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3 text-end">
                                        <span class="badge-status ${session.status.toLowerCase()} mb-2 d-inline-block">${session.status}</span>
                                        <div class="d-flex justify-content-end gap-2">
                                            <button class="btn btn-xs btn-outline-secondary" onclick="alert('Sending Invite...')"><i class="fas fa-envelope"></i> Invite</button>
                                            <button class="btn btn-xs btn-outline-danger" onclick="window.HRSubmodules.deleteOrientation('${session.id}')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewOrientation = function() {
        const title = prompt("Orientation Title:");
        const date = prompt("Date (YYYY-MM-DD):");
        if (title && date) {
            let sessions = getSessions();
            sessions.push({
                id: "ORI-" + Math.floor(Math.random() * 900),
                title: title,
                date: date,
                time: "09:00 AM",
                venue: "To Be Announced",
                facilitator: "HR Coordinator",
                status: "Scheduled"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
            this.renderOrientationScheduling(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.deleteOrientation = function(id) {
        if(confirm("Cancel this session?")) {
            let sessions = getSessions().filter(s => s.id !== id);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
            this.renderOrientationScheduling(document.getElementById('roleModuleOverviewBody'));
        }
    };

})();