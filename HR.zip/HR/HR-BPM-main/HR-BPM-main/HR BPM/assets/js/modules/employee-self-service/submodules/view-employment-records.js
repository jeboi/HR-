window.HRSubmodules = window.HRSubmodules || {};

window.HRSubmodules.renderViewEmploymentRecords = function (container) {
    const employeeId = localStorage.getItem('hospitalHrEmployeeId') || "EMP-2024-001";
    const employees = JSON.parse(localStorage.getItem('hospitalHrHcmEmployees') || '[]');
    const user = employees.find(e => e.id === employeeId) || { name: "Employee", joined: "Jan 2024", role: "Staff" };

    // Mock history data - in a real app, this would come from a 'hospitalHrCareerHistory' key
    const history = [
        { date: user.joined, event: "Initial Hire", role: user.role, dept: "Onboarding" },
        { date: "Mar 2024", event: "Probation Completion", role: user.role, dept: "Medical Ops" },
        { date: "Current", event: "Active Duty", role: user.role, dept: "Medical Ops" }
    ];

    container.innerHTML = `
        <div class="records-module animate-fade-in">
            <div class="row g-4">
                <div class="col-xl-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                            <h6 class="mb-0 fw-bold text-dark">Career History Log</h6>
                            <button class="btn btn-sm btn-outline-primary" onclick="window.print()">
                                <i class="bi bi-printer me-1"></i> Export PDF
                            </button>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="ps-4 py-3 text-uppercase extra-small fw-bold">Date</th>
                                            <th class="py-3 text-uppercase extra-small fw-bold">Event</th>
                                            <th class="py-3 text-uppercase extra-small fw-bold">Designation</th>
                                            <th class="pe-4 py-3 text-uppercase extra-small fw-bold text-end">Department</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${history.map(item => `
                                            <tr>
                                                <td class="ps-4 small text-muted">${item.date}</td>
                                                <td><span class="fw-medium small">${item.event}</span></td>
                                                <td><span class="badge bg-blue-subtle text-primary border border-primary-subtle">${item.role}</span></td>
                                                <td class="pe-4 text-end small">${item.dept}</td>
                                            </tr>
                                        `).reverse().join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-body p-4 text-center">
                            <div class="avatar-circle mx-auto mb-3">
                                <i class="bi bi-shield-check text-primary fs-2"></i>
                            </div>
                            <h6 class="fw-bold mb-1">Employment Status</h6>
                            <p class="text-success small fw-medium mb-3">Verified & Active</p>
                            <hr class="my-3 opacity-50">
                            <div class="text-start">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted small">Total Tenure</span>
                                    <span class="small fw-bold">2.4 Years</span>
                                </div>
                                <div class="d-flex justify-content-between mb-0">
                                    <span class="text-muted small">Reporting Manager</span>
                                    <span class="small fw-bold text-primary">Dr. Sarah Smith</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm bg-dark text-white">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-2">
                                <i class="bi bi-clock-history me-2 text-warning"></i>
                                <h6 class="mb-0">Upcoming Review</h6>
                            </div>
                            <p class="extra-small opacity-75 mb-3">Your next performance appraisal is scheduled for:</p>
                            <h5 class="fw-bold mb-0">October 15, 2024</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
};