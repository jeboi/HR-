/**
 * Application Tracking Submodule
 * Pipeline View for HR Recruitment
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    // Data specifically scoped for tracking
    const trackingData = [
        { id: "APP-401", name: "Dr. Aris Thorne", role: "Chief Medical Officer", stage: "Interview", date: "2026-03-01", priority: "High" },
        { id: "APP-402", name: "Sarah Jenkins", role: "HR Specialist", stage: "Shortlisted", date: "2026-02-28", priority: "Medium" },
        { id: "APP-403", name: "Mark Vales", role: "Clinical Coordinator", stage: "New", date: "2026-03-04", priority: "Low" },
        { id: "APP-404", name: "Elena Rossi", role: "HR Manager", stage: "Offer", date: "2026-03-02", priority: "High" }
    ];

    window.HRSubmodules.renderApplicationTracking = function (container) {
        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="row g-3 mb-4">
                    ${['New', 'Shortlisted', 'Interview', 'Offer'].map(stage => `
                        <div class="col-md-3">
                            <div class="tracking-stats-card p-3 border rounded-3 bg-white shadow-sm">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted small fw-medium">${stage}</span>
                                    <span class="badge bg-primary-subtle text-primary rounded-pill">
                                        ${trackingData.filter(a => a.stage === stage).length}
                                    </span>
                                </div>
                                <h4 class="mt-2 mb-0 fw-bold">${stage === 'Offer' ? '2' : '5'}%</h4>
                                <div class="progress mt-2" style="height: 4px;">
                                    <div class="progress-bar" style="width: 45%"></div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>

                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-project-diagram me-2 text-primary"></i>Recruitment Pipeline</h6>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-secondary btn-sm" onclick="window.HRSubmodules.refreshTracking()">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                        <button class="btn btn-primary btn-sm px-3">Generate Report</button>
                    </div>
                </div>

                <div class="border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Candidate & ID</th>
                                <th>Position</th>
                                <th>Current Stage</th>
                                <th>Priority</th>
                                <th class="text-end pe-4">Pipeline Action</th>
                            </tr>
                        </thead>
                        <tbody id="trackingTableBody">
                            ${renderTrackingRows(trackingData)}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    function renderTrackingRows(data) {
        return data.map(app => `
            <tr>
                <td class="ps-4">
                    <div class="fw-bold text-dark">${app.name}</div>
                    <div class="text-muted extra-small">${app.id}</div>
                </td>
                <td><span class="small fw-medium">${app.role}</span></td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="stage-dot ${app.stage.toLowerCase()} me-2"></div>
                        <span class="small">${app.stage}</span>
                    </div>
                </td>
                <td>
                    <span class="priority-label ${app.priority.toLowerCase()}">${app.priority}</span>
                </td>
                <td class="text-end pe-4">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-light border btn-sm" title="Move Forward">
                            <i class="fas fa-arrow-right text-success"></i>
                        </button>
                        <button class="btn btn-light border btn-sm" title="Drop Application">
                            <i class="fas fa-times text-danger"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Real-time Update Listener (Sync with Dashboard)
    window.addEventListener('storage', function (event) {
        if (event.key === 'hospitalHrApplicationUpdate') {
            const container = document.getElementById('roleModuleOverviewBody');
            if (container && activeSubmoduleName === 'Application Tracking') {
                window.HRSubmodules.renderApplicationTracking(container);
            }
        }
    });

    window.HRSubmodules.refreshTracking = () => {
        const container = document.getElementById('roleModuleOverviewBody');
        window.HRSubmodules.renderApplicationTracking(container);
    };

})();

/**
 * Applicant & Tracking Logic
 * Assets: assets/js/modules/applicant-management/submodules/application-tracking.js
 */
(function () {
    'use strict';
    window.HRSubmodules = window.HRSubmodules || {};

    // Internal state management
    let hrCandidates = JSON.parse(localStorage.getItem('hrCandidates')) || [
        { id: "APP-001", name: "Clarice Starling", role: "HR Generalist", stage: "New", email: "c.starling@hospital.com", rating: 4 },
        { id: "APP-002", name: "Harvey Specter", role: "Recruitment Lead", stage: "Interview", email: "h.specter@hospital.com", rating: 5 }
    ];

    const saveAndSync = () => {
        localStorage.setItem('hrCandidates', JSON.stringify(hrCandidates));
        // Update the dashboard counter specifically
        localStorage.setItem('hospitalHrPendingApps', hrCandidates.filter(c => c.stage === 'New').length);
        window.dispatchEvent(new Event('storage'));
    };

    window.HRSubmodules.renderApplicationTracking = function (container) {
        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between mb-3">
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary active">All Candidates</button>
                        <button class="btn btn-sm btn-outline-primary">Pipeline View</button>
                    </div>
                    <div class="d-flex gap-2">
                         <input type="text" id="trackSearch" class="form-control form-control-sm" placeholder="Quick search...">
                    </div>
                </div>
                
                <div class="table-responsive border rounded-3 bg-white">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Candidate</th>
                                <th>Stage</th>
                                <th>Rating</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="trackingBody">
                            ${renderRows(hrCandidates)}
                        </tbody>
                    </table>
                </div>
            </div>
        `;

        setupListeners();
    };

    function renderRows(data) {
        return data.map(app => `
            <tr>
                <td>
                    <div class="fw-bold">${app.name}</div>
                    <div class="extra-small text-muted">${app.role}</div>
                </td>
                <td>
                    <select class="form-select form-select-sm stage-select" data-id="${app.id}">
                        ${['New', 'Shortlisted', 'Interview', 'Offer', 'Hired'].map(s => 
                            `<option value="${s}" ${app.stage === s ? 'selected' : ''}>${s}</option>`
                        ).join('')}
                    </select>
                </td>
                <td>${'<i class="fas fa-star text-warning"></i>'.repeat(app.rating)}</td>
                <td class="text-end">
                    <button class="btn btn-sm btn-light border move-btn" data-id="${app.id}" title="Promote Stage">
                        <i class="fas fa-chevron-right text-primary"></i>
                    </button>
                    <button class="btn btn-sm btn-light border delete-btn" data-id="${app.id}">
                        <i class="fas fa-trash text-danger"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    function setupListeners() {
        // Handle Stage Changes
        document.querySelectorAll('.stage-select').forEach(sel => {
            sel.addEventListener('change', (e) => {
                const id = e.target.dataset.id;
                const candidate = hrCandidates.find(c => c.id === id);
                candidate.stage = e.target.value;
                saveAndSync();
            });
        });

        // Handle Deletion
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = btn.dataset.id;
                hrCandidates = hrCandidates.filter(c => c.id !== id);
                saveAndSync();
                window.HRSubmodules.renderApplicationTracking(document.getElementById('roleModuleOverviewBody'));
            });
        });
    }
})();