/**
 * Position Planning Submodule
 * Professional Strategic Succession Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrPositionPlanning';

    const getPositions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Professional Position Data
        return [
            { id: "POS-101", title: "Chief Nursing Officer", department: "Nursing Admin", risk: "High", bench: 2, status: "Critical" },
            { id: "POS-102", title: "Head of Radiology", department: "Diagnostic", risk: "Medium", bench: 3, status: "Stable" },
            { id: "POS-103", title: "IT Infrastructure Director", department: "IT", risk: "High", bench: 1, status: "Vulnerable" }
        ];
    };

    window.HRSubmodules.renderPositionPlanning = function (container) {
        const positions = getPositions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-sitemap text-primary me-2"></i>Position & Bench Strength Planning</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Succession Strategy for Critical Roles</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.addNewPositionPlan()">
                        <i class="fas fa-plus-circle me-1"></i> Add Position Plan
                    </button>
                </div>

                <div class="row g-4">
                    ${positions.map(pos => `
                        <div class="col-xl-4 col-md-6">
                            <div class="position-card border rounded-4 bg-white shadow-sm h-100 overflow-hidden">
                                <div class="p-4">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h6 class="fw-bold text-dark mb-1">${pos.title}</h6>
                                            <span class="badge bg-light text-muted border extra-small">${pos.department}</span>
                                        </div>
                                        <span class="status-indicator ${pos.status.toLowerCase()}">${pos.status}</span>
                                    </div>
                                    
                                    <div class="planning-stats border-top pt-3 mt-3">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="text-muted extra-small text-uppercase fw-bold">Departure Risk</div>
                                                <div class="fw-bold ${pos.risk === 'High' ? 'text-danger' : 'text-warning'}">${pos.risk}</div>
                                            </div>
                                            <div class="col-6 border-start">
                                                <div class="text-muted extra-small text-uppercase fw-bold">Successors</div>
                                                <div class="fw-bold text-primary">${pos.bench} Ready</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4 d-grid gap-2">
                                        <button class="btn btn-outline-primary btn-sm" onclick="alert('Viewing potential successors for ${pos.title}...')">
                                            <i class="fas fa-users-viewfinder me-1"></i> Manage Bench
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewPositionPlan = function() {
        const title = prompt("Enter Position Title:");
        const dept = prompt("Department:");
        if (title && dept) {
            let positions = getPositions();
            positions.unshift({
                id: "POS-" + Math.floor(100 + Math.random() * 900),
                title: title,
                department: dept,
                risk: "Medium",
                bench: 0,
                status: "Review Required"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(positions));
            window.dispatchEvent(new Event('storage')); // Notify Dashboard
            this.renderPositionPlanning(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();