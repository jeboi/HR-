/**
 * Applicant List Submodule
 * Scoped: Human Resources Department
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    window.HRSubmodules.renderApplicantList = function (container) {
        const hrApplicants = [
            { id: "HR-2026-001", name: "Clarice Starling", role: "HR Generalist", date: "Mar 01, 2026", status: "New", email: "c.starling@hospital.com", exp: "5 years" },
            { id: "HR-2026-002", name: "Harvey Specter", role: "Recruitment Lead", date: "Feb 28, 2026", status: "Interview", email: "h.specter@hospital.com", exp: "8 years" },
            { id: "HR-2026-003", name: "Donna Paulsen", role: "Benefits Admin", date: "Feb 25, 2026", status: "Shortlisted", email: "d.paulsen@hospital.com", exp: "10 years" },
            { id: "HR-2026-004", name: "Mike Ross", role: "HR Coordinator", date: "Mar 02, 2026", status: "New", email: "m.ross@hospital.com", exp: "2 years" }
        ];

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4">
                    <div class="d-flex gap-2">
                        <div class="search-wrapper">
                            <i class="fas fa-search search-icon"></i>
                            <input type="text" id="hrAppSearch" class="form-control form-control-sm ps-5" placeholder="Search by name or role..." style="width: 300px;">
                        </div>
                        <select class="form-select form-select-sm" id="hrStatusFilter" style="width: 150px;">
                            <option value="all">All Statuses</option>
                            <option value="New">New</option>
                            <option value="Interview">Interviewing</option>
                            <option value="Shortlisted">Shortlisted</option>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-sm px-3">
                        <i class="fas fa-user-plus me-2"></i>External Hire
                    </button>
                </div>

                <div class="border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Candidate Information</th>
                                <th>Position Applied</th>
                                <th>Experience</th>
                                <th>Application Date</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Management</th>
                            </tr>
                        </thead>
                        <tbody id="hrApplicantTableBody">
                            ${generateRows(hrApplicants)}
                        </tbody>
                    </table>
                </div>
            </div>
        `;

        // Interaction Logic
        const searchInput = document.getElementById('hrAppSearch');
        const filterSelect = document.getElementById('hrStatusFilter');

        const updateTable = () => {
            const term = searchInput.value.toLowerCase();
            const status = filterSelect.value;
            const filtered = hrApplicants.filter(a => {
                const matchName = a.name.toLowerCase().includes(term) || a.role.toLowerCase().includes(term);
                const matchStatus = status === 'all' || a.status === status;
                return matchName && matchStatus;
            });
            document.getElementById('hrApplicantTableBody').innerHTML = generateRows(filtered);
        };

        searchInput.addEventListener('input', updateTable);
        filterSelect.addEventListener('change', updateTable);
    };

    function generateRows(data) {
        if (data.length === 0) return '<tr><td colspan="6" class="text-center py-5 text-muted">No candidates match your criteria</td></tr>';
        
        return data.map(app => `
            <tr>
                <td class="ps-4">
                    <div class="d-flex align-items-center">
                        <div class="applicant-init-avatar me-3">${app.name.charAt(0)}</div>
                        <div>
                            <div class="fw-semibold text-dark mb-0">${app.name}</div>
                            <div class="text-muted extra-small">${app.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="text-dark fw-medium">${app.role}</span></td>
                <td><span class="text-muted small">${app.exp}</span></td>
                <td class="text-muted small">${app.date}</td>
                <td>${getStatusBadge(app.status)}</td>
                <td class="text-end pe-4">
                    <button class="btn btn-icon-sm me-1" title="View Profile"><i class="fas fa-file-invoice text-primary"></i></button>
                    <button class="btn btn-icon-sm" title="Schedule"><i class="fas fa-calendar-alt text-success"></i></button>
                </td>
            </tr>
        `).join('');
    }

    function getStatusBadge(status) {
        const colors = {
            'New': 'bg-info-subtle text-info',
            'Interview': 'bg-warning-subtle text-warning',
            'Shortlisted': 'bg-success-subtle text-success'
        };
        return `<span class="badge ${colors[status] || 'bg-light'} border-0 px-2 py-1">${status}</span>`;
    }
})();