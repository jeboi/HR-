window.HRSubmodules = window.HRSubmodules || {};

window.HRSubmodules.renderSubmitRequests = function (container) {
    const employeeId = localStorage.getItem('hospitalHrEmployeeId') || "EMP-2024-001";
    
    container.innerHTML = `
        <div class="request-module animate-fade-in">
            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white py-3 border-bottom">
                            <h6 class="mb-0 fw-bold"><i class="bi bi-send me-2 text-primary"></i>New Request</h6>
                        </div>
                        <div class="card-body p-4">
                            <form id="hr-request-form">
                                <div class="row g-3">
                                    <div class="col-md-12">
                                        <label class="form-label small fw-semibold">REQUEST TYPE</label>
                                        <select class="form-select border-light-subtle py-2" id="req-type" required>
                                            <option value="Leave Application">Leave Application (Vacation/Sick)</option>
                                            <option value="Resource Requisition">Resource Requisition (Equipment/Supplies)</option>
                                            <option value="Schedule Change">Schedule / Shift Change</option>
                                            <option value="Maintenance">Facility Maintenance</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label small fw-semibold">PRIORITY</label>
                                        <div class="d-flex gap-2">
                                            <input type="radio" class="btn-check" name="priority" id="prio-low" value="Normal" checked>
                                            <label class="btn btn-outline-secondary btn-sm w-100" for="prio-low">Normal</label>
                                            
                                            <input type="radio" class="btn-check" name="priority" id="prio-high" value="Urgent">
                                            <label class="btn btn-outline-danger btn-sm w-100" for="prio-high">Urgent</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label small fw-semibold">EFFECTIVE DATE</label>
                                        <input type="date" class="form-control border-light-subtle py-2" id="req-date" required>
                                    </div>

                                    <div class="col-12">
                                        <label class="form-label small fw-semibold">REASON / DESCRIPTION</label>
                                        <textarea class="form-control border-light-subtle" id="req-desc" rows="4" placeholder="Please provide detailed information regarding your request..." required></textarea>
                                    </div>

                                    <div class="col-12 pt-3">
                                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">
                                            Submit Request to HR
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="card border-0 bg-primary text-white shadow-sm mb-4">
                        <div class="card-body p-4">
                            <h6><i class="bi bi-info-circle me-2"></i>Submission Policy</h6>
                            <p class="small mb-0 opacity-75">Requests are processed within 24-48 business hours. Urgent requests will be flagged immediately to Department Heads.</p>
                        </div>
                    </div>
                    
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white py-3 border-bottom">
                            <h6 class="mb-0 fw-bold">Recent Submissions</h6>
                        </div>
                        <div id="mini-request-history" class="card-body p-0">
                            </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    const updateMiniHistory = () => {
        const activities = JSON.parse(localStorage.getItem('hospitalHrRecentActivities') || '[]');
        const historyContainer = document.getElementById('mini-request-history');
        const myRequests = activities.filter(a => a.user.includes(employeeId)).slice(0, 3);

        if (myRequests.length === 0) {
            historyContainer.innerHTML = `<p class="text-center py-4 text-muted small">No recent requests found.</p>`;
            return;
        }

        historyContainer.innerHTML = myRequests.map(req => `
            <div class="p-3 border-bottom border-light">
                <div class="d-flex justify-content-between mb-1">
                    <span class="small fw-bold">${req.action}</span>
                    <span class="badge bg-light text-dark extra-small">${req.time}</span>
                </div>
                <p class="extra-small text-muted mb-0">Status: <span class="text-warning">Pending Review</span></p>
            </div>
        `).join('');
    };

    updateMiniHistory();

    const form = document.getElementById('hr-request-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const type = document.getElementById('req-type').value;
        const prio = form.querySelector('input[name="priority"]:checked').value;
        
        // 1. Create Activity Object
        const newActivity = {
            id: Date.now(),
            user: employeeId,
            action: `${type} Filed (${prio})`,
            time: "Just now",
            type: prio === 'Urgent' ? 'danger' : 'primary'
        };

        // 2. Push to Recent Activities (Dashboard Sync)
        const activities = JSON.parse(localStorage.getItem('hospitalHrRecentActivities') || '[]');
        activities.unshift(newActivity); // Add to top
        localStorage.setItem('hospitalHrRecentActivities', JSON.stringify(activities.slice(0, 10)));

        // 3. Feedback and Reset
        alert(`Request ${type} has been submitted successfully!`);
        renderInlineSubmoduleContent('Submit Requests'); // Refresh view
    });
};