/**
 * Certifications Submodule
 * Professional License & Board Credential Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrLicenseVault';

    const getCertifications = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Medical License Data
        return [
            { id: "LIC-7701", name: "Dr. Aris Thorne", type: "Medical Board License", issued: "2024-05-20", expiry: "2027-05-20", status: "Active" },
            { id: "LIC-8820", name: "Sarah Jenkins", type: "Registered Nurse (RN)", issued: "2023-11-10", expiry: "2026-11-10", status: "Active" },
            { id: "LIC-4412", name: "James Miller", type: "Radiology Tech Cert", issued: "2021-01-05", expiry: "2024-01-05", status: "Expired" }
        ];
    };

    window.HRSubmodules.renderCertifications = function (container) {
        const certs = getCertifications();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-id-card text-primary me-2"></i>Credential Vault</h6>
                        <small class="text-muted">Monitoring professional licenses and board certifications</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.registerNewLicense()">
                        <i class="fas fa-plus me-1"></i> Register License
                    </button>
                </div>

                <div class="row g-3">
                    ${certs.map(cert => `
                        <div class="col-xl-4 col-md-6">
                            <div class="cert-card bg-white border rounded-4 shadow-sm p-4 h-100 position-relative overflow-hidden">
                                <div class="cert-status-stripe ${cert.status.toLowerCase()}"></div>
                                <div class="d-flex justify-content-between mb-3">
                                    <span class="extra-small text-muted fw-bold">REF: ${cert.id}</span>
                                    <span class="badge ${cert.status === 'Active' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} rounded-pill" style="font-size: 9px;">${cert.status}</span>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">${cert.name}</h6>
                                <p class="text-primary small fw-semibold mb-4">${cert.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded-3">
                                    <div class="text-center flex-grow-1">
                                        <div class="extra-small text-muted">ISSUED</div>
                                        <div class="small fw-bold text-dark">${cert.issued}</div>
                                    </div>
                                    <div class="border-start mx-2" style="height: 20px;"></div>
                                    <div class="text-center flex-grow-1">
                                        <div class="extra-small text-muted">EXPIRY</div>
                                        <div class="small fw-bold ${cert.status === 'Expired' ? 'text-danger' : 'text-dark'}">${cert.expiry}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.registerNewLicense = function() {
        const name = prompt("Professional Name:");
        const type = prompt("License Type (e.g., Medical Board, RN):");
        const expiry = prompt("Expiry Date (YYYY-MM-DD):");
        
        if (name && type && expiry) {
            let certs = getCertifications();
            certs.unshift({
                id: "LIC-" + Math.floor(1000 + Math.random() * 9000),
                name: name,
                type: type,
                issued: new Date().toISOString().split('T')[0],
                expiry: expiry,
                status: new Date(expiry) > new Date() ? "Active" : "Expired"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(certs));
            window.dispatchEvent(new Event('storage'));
            this.renderCertifications(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();