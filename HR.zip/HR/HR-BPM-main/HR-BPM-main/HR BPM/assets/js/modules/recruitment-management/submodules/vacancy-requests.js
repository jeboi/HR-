/**
 * Vacancy Requests Submodule
 * Professional Staff Requisition Workflow
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrVacancyRequests';

    const getRequests = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        return [
            { id: "REQ-2026-001", position: "Senior Pharmacist", dept: "Pharmacy", urgency: "High", status: "Pending", date: "2026-03-04" },
            { id: "REQ-2026-002", position: "General Surgeon", dept: "Surgical", urgency: "Medium", status: "Approved", date: "2026-03-02" }
        ];
    };

    window.HRSubmodules.renderVacancyRequests = function (container) {
        const requests = getRequests();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-header-container d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3">
                    <div class="header-info">
                        <h6 class="fw-bold text-dark mb-0">Staff Requisitions</h6>
                        <p class="text-muted small mb-0">Review and manage departmental hiring requests</p>
                    </div>
                    <button class="btn btn-primary btn-sm px-4 shadow-sm" onclick="window.HRSubmodules.openRequestModal()">
                        <i class="fas fa-plus me-2"></i>New Request
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 custom-req-table">
                        <thead>
                            <tr>
                                <th class="ps-4" style="width: 15%">ID</th>
                                <th style="width: 35%">Position Details</th>
                                <th style="width: 20%">Urgency</th>
                                <th style="width: 15%">Status</th>
                                <th class="text-end pe-4" style="width: 15%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${requests.map(req => `
                                <tr>
                                    <td class="ps-4 font-monospace text-primary fw-bold small">${req.id}</td>
                                    <td>
                                        <div class="text-truncate fw-bold" title="${req.position}">${req.position}</div>
                                        <div class="text-muted small">${req.dept}</div>
                                    </td>
                                    <td>
                                        <span class="urgency-label ${req.urgency.toLowerCase()}">${req.urgency}</span>
                                    </td>
                                    <td>
                                        <span class="badge ${getStatusClass(req.status)}">${req.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-1">
                                            ${req.status === 'Pending' ? `
                                                <button class="btn btn-action btn-approve" onclick="window.HRSubmodules.updateRequestStatus('${req.id}', 'Approved')">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                                <button class="btn btn-action btn-reject" onclick="window.HRSubmodules.updateRequestStatus('${req.id}', 'Rejected')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            ` : `
                                                <span class="text-muted small fst-italic">Logged</span>
                                            `}
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    function getStatusClass(status) {
        if (status === 'Approved') return 'bg-success-subtle text-success border border-success-subtle';
        if (status === 'Rejected') return 'bg-danger-subtle text-danger border border-danger-subtle';
        return 'bg-warning-subtle text-warning border border-warning-subtle';
    }

    window.HRSubmodules.updateRequestStatus = function(id, newStatus) {
        let requests = getRequests();
        const idx = requests.findIndex(r => r.id === id);
        if (idx !== -1) {
            requests[idx].status = newStatus;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
            window.dispatchEvent(new Event('storage'));
            this.renderVacancyRequests(document.getElementById('roleModuleOverviewBody'));
        }
    };

    window.HRSubmodules.openRequestModal = function() {
        const pos = prompt("Enter Position Name:");
        const dep = prompt("Enter Department:");
        if (pos && dep) {
            let requests = getRequests();
            requests.unshift({
                id: "REQ-" + Math.floor(1000 + Math.random() * 9000),
                position: pos,
                dept: dep,
                urgency: "Medium",
                status: "Pending",
                date: new Date().toLocaleDateString()
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
            window.dispatchEvent(new Event('storage'));
            this.renderVacancyRequests(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();