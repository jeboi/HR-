/**
 * Course Catalog Submodule
 * Professional L&D Training Hub
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCourses';

    const getCourses = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Hospital Courses
        return [
            { id: "CRS-101", title: "Advanced Life Support (ALS)", category: "Clinical", duration: "16 Hours", status: "Active", icon: "fa-heart-pulse", color: "#dc3545" },
            { id: "CRS-102", title: "Patient Privacy & HIPAA", category: "Compliance", duration: "4 Hours", status: "Mandatory", icon: "fa-shield-halved", color: "#0d6efd" },
            { id: "CRS-103", title: "Nurse Leadership 101", category: "Management", duration: "20 Hours", status: "Active", icon: "fa-users-gear", color: "#198754" }
        ];
    };

    window.HRSubmodules.renderCourseCatalog = function (container) {
        const courses = getCourses();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-book-open text-primary me-2"></i>Course Catalog</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Continuing Professional Development</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.addNewCourse()">
                        <i class="fas fa-plus-circle me-1"></i> Add New Course
                    </button>
                </div>

                <div class="row g-4">
                    ${courses.map(course => `
                        <div class="col-xl-4 col-md-6">
                            <div class="course-card border rounded-4 bg-white shadow-sm overflow-hidden h-100 d-flex flex-column">
                                <div class="course-header p-4 text-center" style="background-color: ${course.color}08;">
                                    <div class="course-icon-circle mb-3" style="background-color: ${course.color}15; color: ${course.color};">
                                        <i class="fas ${course.icon} fa-xl"></i>
                                    </div>
                                    <span class="badge rounded-pill mb-2 ${course.status === 'Mandatory' ? 'bg-danger' : 'bg-primary-subtle text-primary'}" style="font-size: 9px;">
                                        ${course.status}
                                    </span>
                                    <h6 class="fw-bold text-dark mb-0 px-2">${course.title}</h6>
                                </div>
                                <div class="course-body p-3 flex-grow-1 border-top">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted small"><i class="far fa-folder me-1"></i> ${course.category}</span>
                                        <span class="text-muted small"><i class="far fa-clock me-1"></i> ${course.duration}</span>
                                    </div>
                                    <div class="extra-small text-muted mb-3">Course ID: ${course.id}</div>
                                    <button class="btn btn-outline-primary btn-sm w-100 rounded-3" onclick="alert('Module: Enrollment System coming soon!')">Manage Enrollment</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewCourse = function() {
        const title = prompt("Course Title:");
        const category = prompt("Category (Clinical/Admin/Compliance):");
        if (title && category) {
            let courses = getCourses();
            courses.unshift({
                id: "CRS-" + Math.floor(100 + Math.random() * 900),
                title: title,
                category: category,
                duration: "TBD",
                status: "Active",
                icon: "fa-graduation-cap",
                color: "#6f42c1"
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(courses));
            window.dispatchEvent(new Event('storage')); // Update Dashboard
            this.renderCourseCatalog(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();