/**
 * Training Attendance Submodule
 * Professional Participation & Roll-call Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrAttendance';

    const getAttendance = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Baseline Attendance Records
        return [
            { id: "ATT-001", name: "Dr. Aris Thorne", session: "Advanced Life Support Prep", date: "2024-06-15", status: "Present", timeIn: "08:55 AM" },
            { id: "ATT-002", name: "Sarah Jenkins", session: "Advanced Life Support Prep", date: "2024-06-15", status: "Excused", timeIn: "-" },
            { id: "ATT-003", name: "James Miller", session: "Cybersecurity Protocol", date: "2024-06-20", status: "Absent", timeIn: "-" }
        ];
    };

    window.HRSubmodules.renderTrainingAttendance = function (container) {
        const records = getAttendance();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-check text-success me-2"></i>Live Session Attendance</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Daily Participation Tracking</small>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.exportAttendance()">
                            <i class="fas fa-file-export me-1"></i> Export
                        </button>
                        <button class="btn btn-success btn-sm rounded-pill px-3" onclick="window.HRSubmodules.markAttendance()">
                            <i class="fas fa-check-double me-1"></i> Mark Attendance
                        </button>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-attendance-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Attendee</th>
                                <th style="width: 30%">Session Title</th>
                                <th style="width: 15%">Check-In</th>
                                <th style="width: 15%">Status</th>
                                <th class="text-end pe-4" style="width: 15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${records.map(record => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${record.name}</div>
                                        <div class="extra-small text-muted">Ref: ${record.id}</div>
                                    </td>
                                    <td>
                                        <div class="small text-dark fw-medium text-truncate" style="max-width: 200px;">${record.session}</div>
                                        <div class="extra-small text-muted">${record.date}</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border extra-small">${record.timeIn}</span>
                                    </td>
                                    <td>
                                        <span class="attendance-pill ${record.status.toLowerCase()}">${record.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-link text-primary p-0" onclick="alert('Editing ${record.id}...')">Edit</button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.markAttendance = function() {
        const name = prompt("Attendee Name:");
        const session = prompt("Session Name:");
        if (name && session) {
            let records = getAttendance();
            records.unshift({
                id: "ATT-" + Math.floor(100 + Math.random() * 899),
                name: name,
                session: session,
                date: new Date().toISOString().split('T')[0],
                status: "Present",
                timeIn: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
            window.dispatchEvent(new Event('storage')); // Sync to Dashboard
            this.renderTrainingAttendance(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();