/**
 * Recognition History Submodule
 * Comprehensive Archive of Staff Achievements
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrRecognitions';

    const getHistory = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    };

    window.HRSubmodules.renderRecognitionHistory = function (container) {
        const history = getHistory();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-history text-info me-2"></i>Achievement Archive</h6>
                        <small class="text-muted">Historical log of all departmental and institutional awards</small>
                    </div>
                    <div class="search-box-sm">
                        <input type="text" class="form-control form-control-sm" placeholder="Search recipient..." id="historySearch">
                    </div>
                </div>

                ${history.length === 0 ? `
                    <div class="text-center p-5 bg-white border rounded-3">
                        <i class="fas fa-folder-open fa-3x text-light mb-3"></i>
                        <p class="text-muted">No historical records found.</p>
                    </div>
                ` : `
                    <div class="timeline-container">
                        ${history.map((item, index) => `
                            <div class="timeline-item d-flex mb-4">
                                <div class="timeline-date-col text-end pe-4 pt-1">
                                    <div class="fw-bold text-dark small">${item.date}</div>
                                    <div class="extra-small text-muted">Ref: ${item.id}</div>
                                </div>
                                <div class="timeline-marker-col position-relative px-3">
                                    <div class="timeline-line"></div>
                                    <div class="timeline-dot" style="background-color: ${item.color || '#0d6efd'}"></div>
                                </div>
                                <div class="timeline-content-col flex-grow-1 bg-white p-3 border rounded-3 shadow-sm">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold text-primary mb-1">${item.award}</h6>
                                        <i class="fas fa-medal text-warning"></i>
                                    </div>
                                    <div class="text-dark fw-medium mb-1">${item.name}</div>
                                    <p class="text-muted extra-small mb-0">Officially recorded in the Institutional Merit Registry.</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
            </div>
        `;
    };

})();