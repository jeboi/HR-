/**
 * Training Evaluation Submodule
 * Professional Feedback & Quality Metrics
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrEvaluations';

    const getEvaluations = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Feedback Data
        return [
            { id: "EVL-501", course: "Advanced Life Support", staff: "Dr. Aris Thorne", rating: 5, comment: "Excellent hands-on simulation.", date: "2024-06-16" },
            { id: "EVL-502", course: "HIPAA Compliance", staff: "Sarah Jenkins", rating: 3, comment: "A bit long, but informative.", date: "2024-06-15" },
            { id: "EVL-503", course: "Emergency Response", staff: "James Miller", rating: 4, comment: "Very practical for night shifts.", date: "2024-06-14" }
        ];
    };

    window.HRSubmodules.renderTrainingEvaluation = function (container) {
        const evals = getEvaluations();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-star-half-stroke text-warning me-2"></i>Training Quality Feedback</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Post-session Staff Evaluations</small>
                    </div>
                    <button class="btn btn-warning btn-sm text-white rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.submitNewEvaluation()">
                        <i class="fas fa-pen-nib me-1"></i> New Evaluation
                    </button>
                </div>

                <div class="row g-3">
                    ${evals.map(evalItem => `
                        <div class="col-xl-6 col-md-12">
                            <div class="eval-card bg-white border rounded-4 p-3 shadow-sm h-100">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <div class="fw-bold text-dark small">${evalItem.course}</div>
                                        <div class="extra-small text-muted">${evalItem.staff} • ${evalItem.date}</div>
                                    </div>
                                    <div class="rating-stars text-warning small">
                                        ${Array(5).fill(0).map((_, i) => `<i class="${i < evalItem.rating ? 'fas' : 'far'} fa-star"></i>`).join('')}
                                    </div>
                                </div>
                                <div class="eval-comment bg-light p-2 rounded-3 mt-2">
                                    <p class="mb-0 text-muted italic small font-serif">"${evalItem.comment}"</p>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.submitNewEvaluation = function() {
        const course = prompt("Course Name:");
        const rating = prompt("Rating (1-5):");
        const comment = prompt("Feedback Comment:");
        
        if (course && rating) {
            let evals = getEvaluations();
            evals.unshift({
                id: "EVL-" + Math.floor(500 + Math.random() * 499),
                course: course,
                staff: "Current User",
                rating: parseInt(rating) || 5,
                comment: comment || "No comments provided.",
                date: new Date().toISOString().split('T')[0]
            });
            localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
            window.dispatchEvent(new Event('storage'));
            this.renderTrainingEvaluation(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();