/**
 * Candidate Shortlisting Submodule
 * Professional Evaluation & Selection UI
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hrCandidates'; // Connecting to existing candidate pool

    // Internal Helper: Get candidates that are in 'New' or 'Shortlisted' status
    const getCandidates = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [
            { id: "APP-101", name: "John Doe", role: "Critical Care Nurse", score: 85, stage: "New" },
            { id: "APP-102", name: "Jane Smith", role: "Radiology Tech", score: 92, stage: "Shortlisted" },
            { id: "APP-103", name: "Robert Ross", role: "Medical Admin", score: 78, stage: "New" }
        ];
    };

    window.HRSubmodules.renderCandidateShortlisting = function (container) {
        const candidates = getCandidates();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div class="header-text">
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-check text-primary me-2"></i>Shortlist Management</h6>
                        <small class="text-muted">Evaluate and promote top-tier medical talent</small>
                    </div>
                    <div class="header-stats d-flex gap-3">
                        <div class="text-end border-end pe-3">
                            <div class="fw-bold text-primary small">${candidates.length}</div>
                            <div class="text-muted" style="font-size: 10px;">TOTAL POOL</div>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold text-success small">${candidates.filter(c => c.stage === 'Shortlisted').length}</div>
                            <div class="text-muted" style="font-size: 10px;">SHORTLISTED</div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 shortlist-table">
                        <thead>
                            <tr>
                                <th class="ps-4">Candidate Profile</th>
                                <th>Match Score</th>
                                <th>Current Status</th>
                                <th class="text-end pe-4">Selection</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${candidates.map(can => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-truncate" style="max-width: 250px;">${can.name}</div>
                                        <div class="text-muted small">${can.role}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress flex-grow-1" style="height: 6px; max-width: 100px;">
                                                <div class="progress-bar bg-primary" style="width: ${can.score}%"></div>
                                            </div>
                                            <span class="fw-bold small">${can.score}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge-custom ${can.stage.toLowerCase()}">${can.stage}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            ${can.stage !== 'Shortlisted' ? `
                                                <button class="btn btn-sm btn-outline-primary px-3 rounded-pill" onclick="window.HRSubmodules.updateShortlistStatus('${can.id}', 'Shortlisted')">
                                                    Shortlist
                                                </button>
                                            ` : `
                                                <button class="btn btn-sm btn-success px-3 rounded-pill" onclick="window.HRSubmodules.updateShortlistStatus('${can.id}', 'New')">
                                                    <i class="fas fa-check me-1"></i> Added
                                                </button>
                                            `}
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateShortlistStatus = function(id, newStage) {
        let candidates = getCandidates();
        const index = candidates.findIndex(c => c.id === id);
        if (index !== -1) {
            candidates[index].stage = newStage;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(candidates));
            
            // Broadcast for real-time dashboard updates
            window.dispatchEvent(new Event('storage'));
            
            // Refresh view
            this.renderCandidateShortlisting(document.getElementById('roleModuleOverviewBody'));
        }
    };
})();