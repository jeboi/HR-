/**
 * Probation Evaluation Submodule
 * Handles performance review for new medical and admin staff
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrProbationEvals';

    const getEvals = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Mock Data for Probationary Period
        return [
            { id: "EVL-901", name: "Dr. Aris Thorne", role: "Resident Physician", score: 92, status: "Recommended", date: "2026-03-05" },
            { id: "EVL-902", name: "Sarah Jenkins", role: "Head Nurse", score: 45, status: "Under Review", date: "2026-03-06" },
            { id: "EVL-903", name: "James Miller", role: "Radiology Tech", score: 0, status: "Pending", date: "-" }
        ];
    };

    window.HRSubmodules.renderProbationEvaluation = function (container) {
        const evals = getEvals();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-clipboard-check text-primary me-2"></i>Probationary Performance</h6>
                        <small class="text-muted">Monitor and evaluate new hire progress for regularization</small>
                    </div>
                    <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.addNewEvaluation()">
                        <i class="fas fa-user-plus me-1"></i> Start Evaluation
                    </button>
                </div>

                <div class="row g-3">
                    ${evals.map(evalItem => `
                        <div class="col-xl-4 col-md-6">
                            <div class="eval-card p-3 border rounded-3 bg-white h-100 shadow-sm">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark">${evalItem.name}</h6>
                                        <small class="text-primary">${evalItem.role}</small>
                                    </div>
                                    <span class="badge-eval ${evalItem.status.replace(/\s+/g, '-').toLowerCase()}">${evalItem.status}</span>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="extra-small text-muted">Performance Score</span>
                                        <span class="extra-small fw-bold">${evalItem.score}%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar ${evalItem.score >= 75 ? 'bg-success' : 'bg-warning'}" 
                                             role="progressbar" style="width: ${evalItem.score}%"></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="text-muted extra-small">Last Updated: ${evalItem.date}</span>
                                    <div class="btn-group">
                                        <button class="btn btn-xs btn-outline-secondary" onclick="window.HRSubmodules.updateScore('${evalItem.id}')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        ${evalItem.score >= 80 && evalItem.status !== 'Recommended' ? 
                                            `<button class="btn btn-xs btn-success ms-1" onclick="window.HRSubmodules.finalizeEval('${evalItem.id}', 'Recommended')">Approve</button>` : ''
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateScore = function(id) {
        const newScore = prompt("Enter Performance Score (0-100):");
        if (newScore !== null) {
            let evals = getEvals();
            const idx = evals.findIndex(e => e.id === id);
            if (idx !== -1) {
                evals[idx].score = parseInt(newScore);
                evals[idx].status = evals[idx].score >= 75 ? "Under Review" : "Pending";
                evals[idx].date = new Date().toLocaleDateString();
                localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
                window.dispatchEvent(new Event('storage')); // Sync Dashboard
                this.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
            }
        }
    };

    window.HRSubmodules.finalizeEval = function(id, status) {
        let evals = getEvals();
        const idx = evals.findIndex(e => e.id === id);
        if (idx !== -1) {
            evals[idx].status = status;
            evals[idx].date = new Date().toLocaleDateString();
            localStorage.setItem(STORAGE_KEY, JSON.stringify(evals));
            window.dispatchEvent(new Event('storage'));
            this.renderProbationEvaluation(document.getElementById('roleModuleOverviewBody'));
        }
    };

})();